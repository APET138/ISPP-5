jQuery.bootstrapLoading = {
  defaults: {
    lines: 10,
    length: 10,
    width: 3,
    radius: 10,
    scale: 1,
    corners: 1,
    color: '#000',
    fadeColor: 'transparent',
    animation: 'spinner-line-fade-default',
    rotate: 0,
    direction: 1,
    speed: 1,
    zIndex: 2e9,
    top: '50%',
    left: '50%',
    shadow: '0 0 1px transparent',
    loadingTips: '',
  },
  init(opts) {
    var style = document.createElement('style');
    style.innerHTML = '@keyframes spinner-line-fade-more {0%,100% {opacity: 0; /* minimum opacity */}1% {opacity: 1;}}@keyframes spinner-line-fade-quick {0%,39%,100% {opacity: 0.25; /* minimum opacity */}40% {opacity: 1;}}@keyframes spinner-line-fade-default {0%,100% {opacity: 0.22; /* minimum opacity */}1% {opacity: 1;}}@keyframes spinner-line-shrink {0%,25%,100% {/* minimum scale and opacity */transform: scale(0.5);opacity: 0.25;}26% {transform: scale(1);opacity: 1;}}';
    document.head.appendChild(style);
    this.spin(opts);
  },
  spin(opts) {
    if (opts === void 0) {
      opts = {};
    }
    this.opts = Object.assign(this.defaults, opts);
    this.stop();
    this.el = this.createMain();
    document.body.appendChild(this.el)
    return this;
  },
  /**
   * Stops and removes the Spinner.
   * Stopped spinners may be reused by calling spin() again.
   */
  stop() {
    if (this.el) {
      if (typeof requestAnimationFrame !== 'undefined') {
        cancelAnimationFrame(this.animateId);
      } else {
        clearTimeout(this.animateId);
      }
      if (this.el.parentNode) {
        this.el.parentNode.removeChild(this.el);
      }
      this.el = undefined;
    }
    return this;
  },
  createMain() {
    var div = document.createElement('div');
    div.className = 'loadingBackground';
    div.setAttribute('role', 'progressbar');
    this.css(div, {
      position: 'fixed',
      width: '100vw',
      height: '100vh',
      zIndex: this.opts.zIndex,
      left: 0,
      top: 0,
      background: 'rgba(0,0,0,.1)'
    });
    var container = document.createElement('div');
    container.className = 'loadingContainer';
    this.css(container, {
      position: 'absolute',
      width: 0,
      left: this.opts.left,
      top: this.opts.top,
      transform: "scale(" + this.opts.scale + ")",
    })
    div.appendChild(container);
    this.drawLines(container, this.opts);
    if (this.opts.loadingTips != void 0) {
      var textContainer = document.createElement('div');
      this.css(textContainer, {
        position: 'absolute',
        width: 0,
        left: this.opts.left,
        top: 'calc(' + this.opts.top + ' + ' + (this.opts.length + 2) * 2 + 'px)',
        transform: 'scale(' + this.opts.scale + ')',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center'
      })
      var text = document.createElement('span');
      text.innerHTML = this.opts.loadingTips;
      textContainer.appendChild(text);
      div.appendChild(textContainer);
    }
    return div;
  },
  /**
   * Sets multiple style properties at once.
   */
  css(el, props) {
    for (var prop in props) {
      el.style[prop] = props[prop];
    }
    return el;
  },
  /**
* Returns the line color from the given string or array.
*/
  getColor(color, idx) {
    return typeof color == 'string' ? color : color[idx % color.length];
  },
  /**
  * Internal method that draws the individual lines.
  */
  drawLines(el, opts) {
    var that = this;
    var borderRadius = (Math.round(opts.corners * opts.width * 500) / 1000) + 'px';
    var shadow = 'none';
    if (opts.shadow === true) {
      shadow = '0 2px 4px #000'; // default shadow
    } else if (typeof opts.shadow === 'string') {
      shadow = opts.shadow;
    }
    var shadows = this.parseBoxShadow(shadow);
    for (var i = 0; i < opts.lines; i++) {
      var degrees = ~~(360 / opts.lines * i + opts.rotate);
      var backgroundLine = this.css(document.createElement('div'), {
        position: 'absolute',
        top: -opts.width / 2 + "px",
        width: (opts.length + opts.width) + 'px',
        height: opts.width + 'px',
        background: that.getColor(opts.fadeColor, i),
        borderRadius: borderRadius,
        transformOrigin: 'left',
        transform: "rotate(" + degrees + "deg) translateX(" + opts.radius + "px)",
      });
      var delay = i * opts.direction / opts.lines / opts.speed;
      delay -= 1 / opts.speed; // so initial animation state will include trail
      var line = this.css(document.createElement('div'), {
        width: '100%',
        height: '100%',
        background: that.getColor(opts.color, i),
        borderRadius: borderRadius,
        boxShadow: that.normalizeShadow(shadows, degrees),
        animation: 1 / opts.speed + "s linear " + delay + "s infinite " + opts.animation,
      });
      backgroundLine.appendChild(line);
      el.appendChild(backgroundLine);
    }
  },
  parseBoxShadow(boxShadow) {
    var regex = /^\s*([a-zA-Z]+\s+)?(-?\d+(\.\d+)?)([a-zA-Z]*)\s+(-?\d+(\.\d+)?)([a-zA-Z]*)(.*)$/;
    var shadows = [];
    for (var _i = 0, _a = boxShadow.split(','); _i < _a.length; _i++) {
      var shadow = _a[_i];
      var matches = shadow.match(regex);
      if (matches === null) {
        continue; // invalid syntax
      }
      var x = +matches[2];
      var y = +matches[5];
      var xUnits = matches[4];
      var yUnits = matches[7];
      if (x === 0 && !xUnits) {
        xUnits = yUnits;
      }
      if (y === 0 && !yUnits) {
        yUnits = xUnits;
      }
      if (xUnits !== yUnits) {
        continue; // units must match to use as coordinates
      }
      shadows.push({
        prefix: matches[1] || '',
        x: x,
        y: y,
        xUnits: xUnits,
        yUnits: yUnits,
        end: matches[8],
      });
    }
    return shadows;
  },
  /**
  * Modify box-shadow x/y offsets to counteract rotation
  */
  normalizeShadow(shadows, degrees) {
    var normalized = [];
    for (var _i = 0, shadows_1 = shadows; _i < shadows_1.length; _i++) {
      var shadow = shadows_1[_i];
      var xy = this.convertOffset(shadow.x, shadow.y, degrees);
      normalized.push(shadow.prefix + xy[0] + shadow.xUnits + ' ' + xy[1] + shadow.yUnits + shadow.end);
    }
    return normalized.join(', ');
  },
  convertOffset(x, y, degrees) {
    var radians = degrees * Math.PI / 180;
    var sin = Math.sin(radians);
    var cos = Math.cos(radians);
    return [
      Math.round((x * cos + y * sin) * 1000) / 1000,
      Math.round((-x * sin + y * cos) * 1000) / 1000,
    ];
  }
}
$.bootstrapLoading.init();