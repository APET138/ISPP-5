const baseUrl = '/diagram/static/graphApp/common';
const appName = window.parent.o.AppName.toLowerCase();
const appUrl = '/diagram/static/graphApp/' + appName + 'App';
(function () {
  const cssUrls = [
    '/dist/app.min.css?v=20230926',
    '/iconfont/iconfont.css',
    // '/lib/modal.css',
    '/lib/dropdown2.css',
    '/lib/colorpickermodal.css'];
  const jsUrls = [
    '/lib/mxClient.min.js',
    '/lib/jquery-3.6.0.min.js',
    '/lib/$.ld.js',
    '/lib/pako.min.js',
    '/lib/sanitizer.min.js',
    // '/lib/dropdown.js',
    // '/lib/modal.js',
    '/lib/vue.min.js',
    // '/lib/colorpickermodal.js',
    '/lib/cpm.js',
    '/components/header.js',
    '/components/maincontent.js',
    '/components/diagramPanel.js',
    '/components/stylePanel.js',
    '/components/shapePanel.js',
    '/components/textPanel.js',
    '/components/format.js',
    '/components/toolbar.js',
    '/dist/app.min.js?v=20240221'
  ]
  const titleApp = ['floorplans', 'electrical', 'network', 'bpmn', 'uml']
  var head = document.getElementsByTagName('head')[0];
  for (let i = 0; i < cssUrls.length; i++) {
    addLink(baseUrl + cssUrls[i]);
  }
  for (let i = 0; i < jsUrls.length; i++) {
    addScript(baseUrl + jsUrls[i])
  }
  if (titleApp.includes(appName)) {
    var style = document.createElement('style');
    style.style.type = 'text/css';
    head.appendChild(style);
    let ruler = '.title1 { background-color: #f0f0f0; } .search-box { display: flex; align-items: center; width: 100%; height: 32px; border: 2px solid #3690c8; border-radius: 10px; padding: 0 10px; margin: 10px 0; } #searchInput::placeholder { color: #ccc; } .search-box input { flex: auto; border: none; outline: none; font-size: 16px; color: #333; background: transparent; min-width: 20px; } .search-box svg { width: 20px; height: 20px; fill: #ccc; display: flex; } .clear-btn { width: 20px; height: 20px; margin-left: 10px; cursor: pointer; display: flex; align-items: center; justify-content: center; } .clear-btn svg { width: 100%; height: 100%; fill: #ccc; } .search-btn { display: flex; align-items: center; justify-content: center; color: #333; cursor: pointer; border: none; background: transparent; margin-left: 10px; padding: 0; position: relative; font-size: 14px; } .search-btn::before { content: ""; display: block; position: absolute; top: 50%; left: -5px; transform: translateY(-50%); width: 1px; height: 14px; background-color: #ccc; }';
    style.appendChild(document.createTextNode(ruler));
  }
  function addLink(url) {
    var linkTag = document.createElement('link');
    linkTag.type = 'text/css';
    linkTag.rel = 'stylesheet';
    linkTag.href = url;
    head.appendChild(linkTag);
  }
  function addScript(url) {
    document.write('<script type="text/javascript" src="' + url + '"></script>')
  }
})()
