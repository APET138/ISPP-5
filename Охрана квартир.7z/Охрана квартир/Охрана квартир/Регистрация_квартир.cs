﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Охрана_квартир
{
    public partial class Регистрация_квартир : Form
    {
        public Регистрация_квартир()
        {
            InitializeComponent();
        }
        Bitmap bmp;
        int check, check1;string iD;
        private int a = 1, n, m, l,j,b;
        Point mouse;
        private void НаличиеБалкона_CheckedChanged(object sender, EventArgs e)
        {
            if (НаличиеБалкона.Checked == true)
            {
                check = 1;
                ТипБалкона.Visible = true;
                ПолеТипБалкона.Visible = true;
            }
            else if (НаличиеБалкона.Checked == false)
            {
                check = 0;
                ТипБалкона.Visible = false;
                ПолеТипБалкона.Visible = false;
            }
        }
        public void Referral(string id)
        {
            iD = id;
        }
        private void ПолеПланКвартиры_Click(object sender, EventArgs e)
        {
            //Вставить картинку из проводника
            ВставкаКартинки.Filter = "Image files (*.BMP, *.JPG, " + "*.GIF, *.PNG)|*.bmp;*.jpg;*.gif;*.png";
            if (ВставкаКартинки.ShowDialog() == DialogResult.OK)
            {
                Image image = Image.FromFile(ВставкаКартинки.FileName);
                int width = ПолеПланКвартиры.Width;
                int height = ПолеПланКвартиры.Height;
                bmp = new Bitmap(image, width, height);
                ПолеПланКвартиры.Image = bmp;
                Надпись2.Text = ВставкаКартинки.FileName;
            }
        }
        private void Регистрация_квартир_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet._Flat_House". При необходимости она может быть перемещена или удалена.
            this.flat_HouseTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet._Flat_House);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet.Contract". При необходимости она может быть перемещена или удалена.
            this.contractTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet.Contract);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet.Settlement". При необходимости она может быть перемещена или удалена.
            this.settlementTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet.Settlement);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet.House". При необходимости она может быть перемещена или удалена.
            this.houseTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet.House);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet.Flat". При необходимости она может быть перемещена или удалена.
            this.flatTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet.Flat);
            Надпись1.Text = "Шаг 1: Введите данные о квартире";
            ToolTip tt = new ToolTip();
            tt.SetToolTip(Выйти, "Закрыть");
            this.Size = new Size(334, 436);
            a = 1;
            Page(a);
            НаличиеБалкона.Checked = false;
            ТипБалкона.Visible = false;
            ПолеТипБалкона.Visible = false;
            for (int i = 0; i < ТаблицаКвартира.RowCount; i++)
            {
                n = int.Parse(ТаблицаКвартира[0, i].Value.ToString());
            }
            for (int i = 0; i < ТаблицаДом.RowCount; i++)
            {
                m = int.Parse(ТаблицаДом[0, i].Value.ToString());
            }
            for (int i = 0; i < ТаблицаSettlement.RowCount; i++)
            {
                l = int.Parse(ТаблицаSettlement[0, i].Value.ToString());
            }
            for (int i = 0; i < ТаблицаДоговор.RowCount; i++)
            {
                j = int.Parse(ТаблицаДоговор[0, i].Value.ToString());
            }
            for (int i = 0; i < ТаблицаFlatHouse.RowCount; i++)
            {
                b = int.Parse(ТаблицаFlatHouse[0, i].Value.ToString());
            }
        }

        private void Выйти_Click(object sender, EventArgs e)
        {
            //Закрыть форму
            this.Close();
        }
        
        private void Page(int a)
        {
            if (a == 1)
            {
                Назад.Enabled = false;
                Квартира.Visible = true;
                Дом.Visible = false;
                Договор.Visible = false;
                Квартира.Location = new Point(12, 62);
                Надпись1.Text = "Шаг 1: Введите данные о квартире";
                Далее.Text = "Далее";
            }
            if (a == 2)
            {
                Назад.Enabled = true;
                Квартира.Visible = false;
                Дом.Visible = true;
                Договор.Visible = false;
                Дом.Location = new Point(12, 62);
                Надпись1.Text = "Шаг 2: Введите данные о доме, \nв которой находится квартира";
                Далее.Text = "Далее";
            }
            if (a == 3)
            {
                Назад.Enabled = true;
                Квартира.Visible = false;
                Дом.Visible = false;
                Договор.Visible= true;
                Договор.Location = new Point(12, 62);
                Надпись1.Text = "Шаг 3: Введите время договора";
                Далее.Text = "Оформить";
            }
        }
        private void Далее_Click(object sender, EventArgs e)
        {
            if (Далее.Text == "Оформить")
            {
                if (ПолеАдресКвартиры.Text == "" || ПолеЭтажКвартиры.Text == "" || ПолеТипКвартирнойДвери.Text == "" || ПолеПланКвартиры.ImageLocation == "" || ПолеТипДома.Text == "" || ПолеЭтажейВДоме.Text == "" || ПолеДатаНачала.Text == "" || ПолеДатаОкончание.Text == "" || ПолеПлата.Text == "")
                {
                    MessageBox.Show("Заполните все поля, чтобы зарегестрировать квартиру");
                }
                else
                {
                    if (ПолеДатаНачала.Value.Month == ПолеДатаОкончание.Value.Month)
                    {
                        MessageBox.Show("Зарегестрировать квартиру можно минимально на месяц");
                    }
                    else
                    {
                        n = n + 1;
                        m = m + 1;
                        l = l + 1;
                        j = j + 1;
                        b = b + 1;
                        using (SqlConnection sqlConnect = new SqlConnection("Data Source=sql;Initial Catalog = УП_ПМ_01_Неверов_ДС; Integrated Security = True"))
                        {
                            try
                            {
                                SqlDataAdapter info1 = new SqlDataAdapter($"INSERT INTO [Flat] (FlatID,AddressFlat,Floor,TypeDoor,Balcony,TypeBalcony,FlatPlan)VALUES('{n}','{ПолеАдресКвартиры.Text}','{ПолеЭтажКвартиры.Text}','{ПолеТипКвартирнойДвери.Text}','{check}','{ПолеТипБалкона.Text}','{Надпись2.Text}');", sqlConnect);
                                SqlDataAdapter info2 = new SqlDataAdapter($"INSERT INTO [House] (HouseID,Floors,[Key],TypeHouse)VALUES('{m}','{ПолеЭтажейВДоме.Text}','{check1}','{ПолеТипДома.Text}');", sqlConnect);
                                SqlDataAdapter info3 = new SqlDataAdapter($"INSERT INTO [Settlement] (SettlementID,FlatID,Registr)VALUES('{l}','{n}','{iD}');", sqlConnect);
                                SqlDataAdapter info4 = new SqlDataAdapter($"INSERT INTO [Flat-House] ([Flat-HouseID],FlatID,HouseID)VALUES('{b}','{n}','{m}');", sqlConnect);
                                SqlDataAdapter info5 = new SqlDataAdapter($"INSERT INTO [Contract] (TreatyID,SettlementID,DateStart,StopDate,Cost)VALUES('{j}','{l}','{ПолеДатаНачала.Text}','{ПолеДатаОкончание.Text}','{ПолеПлата.Text}');", sqlConnect);
                                DataTable dt1 = new DataTable();
                                DataTable dt2 = new DataTable();
                                DataTable dt3 = new DataTable();
                                DataTable dt4 = new DataTable();
                                DataTable dt5 = new DataTable();
                                info1.Fill(dt1);
                                info2.Fill(dt2);
                                info3.Fill(dt3);
                                info4.Fill(dt4);
                                info5.Fill(dt5);
                                MessageBox.Show("Квартира была оформленна");
                            }
                            catch { }
                        }
                    }
                }
                
            }
            else
            {
                a++;
                Page(a);
            }
        }

        private void Назад_Click(object sender, EventArgs e)
        {
            a--;
            Page(a);
            if (a < 1)
            {
                a = 1;
            }
        }

        private void ПолеЭтажейВДоме_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= '0') && (e.KeyChar <= '9') || (e.KeyChar == (char)Keys.Back))
            {

            }
            else
            {
                e.KeyChar -= e.KeyChar;
            }
        }

        private void ПолеДатаОкончание_CloseUp(object sender, EventArgs e)
        {
            if (ПолеДатаОкончание.Value.Year >= ПолеДатаНачала.Value.Year&& ПолеДатаОкончание.Value.Month > ПолеДатаНачала.Value.Month)
            {
                //ПолеПлата.Text = "30000";
                ПолеПлата.Text = Convert.ToString(30000 * (ПолеДатаОкончание.Value.Month - ПолеДатаНачала.Value.Month));
            }
            else
            {
                ПолеПлата.Text = "";
            }
        }

        private void ПолеДатаНачала_CloseUp(object sender, EventArgs e)
        {
            if (ПолеДатаОкончание.Value.Year >= ПолеДатаНачала.Value.Year && ПолеДатаОкончание.Value.Month > ПолеДатаНачала.Value.Month)
            {
                //ПолеПлата.Text = "30000";
                ПолеПлата.Text = Convert.ToString(30000 * (ПолеДатаОкончание.Value.Month - ПолеДатаНачала.Value.Month));
            }
            else
            {
                ПолеПлата.Text = "";
            }
        }

        private void ПолеТипКвартирнойДвери_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar -= e.KeyChar;
        }

        private void ПолеТипБалкона_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar -= e.KeyChar;
        }

        private void ПолеТипДома_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar -= e.KeyChar;
        }

        private void ПолеПлата_KeyPress(object sender, KeyPressEventArgs e)
        {
            //Ввод только цифр
            if ((e.KeyChar >= '0') && (e.KeyChar <= '9') || (e.KeyChar == (char)Keys.Back))
            {

            }
            else
            {
                e.KeyChar -= e.KeyChar;
            }
        }

        private void Регистрация_квартир_MouseMove(object sender, MouseEventArgs e)
        {
            //передвигает форму по тому как движется мышка по экрану
            if (e.Button == MouseButtons.Left)
            {
                Left += e.X - mouse.X;
                Top += e.Y - mouse.Y;
            }
        }

        private void ПолеЭтажКвартиры_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                ПолеТипКвартирнойДвери.Focus();
            }
            if ((e.KeyChar >= '0') && (e.KeyChar <= '9') || (e.KeyChar == (char)Keys.Back))
            {

            }
            else
            {
                e.KeyChar -= e.KeyChar;
            }
        }

        private void ПолеАдресКвартиры_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                ПолеЭтажКвартиры.Focus();
            }
        }

        private void Регистрация_квартир_MouseDown(object sender, MouseEventArgs e)
        {
            //отпеделяет точку где была эажата клавиша мыши на форме
            mouse = new Point(e.X, e.Y);
        }

        private void КодовыйЗамок_CheckedChanged(object sender, EventArgs e)
        {
            if (НаличиеБалкона.Checked == true)
            {
                check1 = 1;
            }
            else if (НаличиеБалкона.Checked == false)
            {
                check1 = 0;
            }
        }
    }
}
