﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Охрана_квартир
{
    public partial class Администратор : Form
    {
        public Администратор()
        {
            InitializeComponent();
        }
         public int c;
         private Bitmap bmp;
        int i, index,v,g,y;
        Point mouse;
        private void Администратор_Load(object sender, EventArgs e)
        { 
            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet.Flat". При необходимости она может быть перемещена или удалена.
            this.flatTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet.Flat);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet.Settlement". При необходимости она может быть перемещена или удалена.
            this.settlementTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet.Settlement);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet.User". При необходимости она может быть перемещена или удалена.
            this.userTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet.User);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet.Prolonging". При необходимости она может быть перемещена или удалена.
            this.prolongingTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet.Prolonging);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet.House". При необходимости она может быть перемещена или удалена.
            this.houseTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet.House);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet._Flat_House". При необходимости она может быть перемещена или удалена.
            this.flat_HouseTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet._Flat_House);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet.Calling". При необходимости она может быть перемещена или удалена.
            this.callingTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet.Calling);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet.Contract". При необходимости она может быть перемещена или удалена.
            this.contractTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet.Contract);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet.Client". При необходимости она может быть перемещена или удалена.
            this.clientTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet.Client);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet.Capture". При необходимости она может быть перемещена или удалена.
            this.captureTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet.Capture);
            ToolTip tt = new ToolTip();//Данные строки позволяют показывать сплывающую подсказку
            tt.SetToolTip(ПолеПоиск, "Введите значение, которое хотите найти в таблице");
            tt.SetToolTip(УдалитьЗапись, "Удаление выделенной строки");
            tt.SetToolTip(ДобавитьЗапись, "Добавить строку");
            tt.SetToolTip(СледующаяЗапись, "Следующая строка");
            tt.SetToolTip(ОбновлениеЗаписей, "Обновить данные");
            tt.SetToolTip(ПредыдущаяЗапись, "Предыдущая строка");
            tt.SetToolTip(Выход, "Закрыть");
            c = 0;
            Table(0);
            Надпись1.Visible = true;
            Надпись2.Visible = true;
            Надпись3.Visible = true;
            Надпись4.Visible = true;
            Надпись5.Visible = true;
            Надпись6.Visible = true;
            Надпись7.Visible = false;
            Надпись1.Text = ТаблицаАдминистратор.Columns[0].HeaderText;
            Надпись2.Text = ТаблицаАдминистратор.Columns[1].HeaderText;
            Надпись3.Text = ТаблицаАдминистратор.Columns[2].HeaderText;
            Надпись4.Text = ТаблицаАдминистратор.Columns[3].HeaderText;
            Надпись5.Text = ТаблицаАдминистратор.Columns[4].HeaderText;
            Надпись6.Text = ТаблицаАдминистратор.Columns[5].HeaderText;
            Клиент.Visible = true;
            Квартира.Visible = false;
            Дом.Visible = false;
            КвартираДом.Visible = false;
            Заселение.Visible = false;
            Договор.Visible = false;
            Продление.Visible = false;
            ГруппаЗаквата.Visible = false;
            Вызов.Visible = false;
            Пользователь.Visible = false;
            //dataGridView1.AllowUserToAddRows = false;
            Выход.Location = new Point(664, -1);
            ПолеПланКвартиры.Visible = false;
            this.Size = new Size(688, 340);
        }
        
        public void Права(string b)
        {
            //Данный метод определяет кто защел на форму Администратор или Оператор
            Доступ.Text = b;
            if (Доступ.Text == "Админ")
            {
                user.Visible = true;
                Формы.Visible = true;
            }
            else
            {
                user.Visible = false;
                Формы.Visible = false;
            }
        }
        private void Table (int c)
        {
            //Данный метод нужен для присваивания к dataGridView1 таблицы из базы данных
            using (SqlConnection sqlConnect = new SqlConnection("Data Source=sql;Initial Catalog = уП_ПМ_01_Неверов_ДС; Integrated Security = True"))
            {
                switch (c)
                {
                    case 0:
                        ТаблицаАдминистратор.DataSource = clientBindingSource;
                        break;
                    case 1:
                        ТаблицаАдминистратор.DataSource = flatBindingSource;
                        break;
                    case 2:
                        ТаблицаАдминистратор.DataSource = houseBindingSource;
                        break;
                    case 3:
                        ТаблицаАдминистратор.DataSource = flatHouseBindingSource;
                        break;
                    case 4:
                        ТаблицаАдминистратор.DataSource = settlementBindingSource;
                        break;
                    case 5:
                        ТаблицаАдминистратор.DataSource = contractBindingSource;
                        break;
                    case 6:
                        ТаблицаАдминистратор.DataSource = prolongingBindingSource;
                        break;
                    case 7:
                        ТаблицаАдминистратор.DataSource = captureBindingSource;
                        break;
                    case 8:
                        ТаблицаАдминистратор.DataSource = callingBindingSource;
                        break;
                    case 11:
                        ТаблицаАдминистратор.DataSource = userBindingSource;
                        break;

                }
            }
        }

        private void user_Click(object sender, EventArgs e)
        {
            c = 11;
            Table(c);
            Надпись1.Text = ТаблицаАдминистратор.Columns[0].HeaderText;
            Надпись2.Text = ТаблицаАдминистратор.Columns[1].HeaderText;
            Надпись3.Text = ТаблицаАдминистратор.Columns[2].HeaderText;
            Надпись4.Text = ТаблицаАдминистратор.Columns[3].HeaderText;
            Клиент.Visible = false;
            Квартира.Visible = false;
            Дом.Visible = false;
            КвартираДом.Visible = false;
            Заселение.Visible = false;
            Договор.Visible = false;
            Продление.Visible = false;
            ГруппаЗаквата.Visible = false;
            Вызов.Visible = false;
            Пользователь.Visible =true;
            this.Size = new Size(688, 340);
            Выход.Location = new Point(664, -1);
            Пользователь.Location = new Point(567, 26);
            Надпись4.Visible = true;
            Надпись6.Visible = false;
            Надпись5.Visible = false;
            Надпись7.Visible = false;
            ПолеПраваДоступа.Text = НадписьПраваДоступа.Text;
        }

        private void формаГостя_Click(object sender, EventArgs e)
        {
            //открытие формы регистрация
            Регистрация us = new Регистрация();
            us.Show();
            us.Dostup("Админ");
        }

        private void формаКомандира_Click(object sender, EventArgs e)
        {
            //открытие формы командира
            Командир com = new Командир();
            com.Show();
            com.Dostup("Админ");
        }

        private void client_Click(object sender, EventArgs e)
        {
            c = 0;
            Table(c);
            Надпись1.Text = ТаблицаАдминистратор.Columns[0].HeaderText;
            Надпись2.Text = ТаблицаАдминистратор.Columns[1].HeaderText;
            Надпись3.Text = ТаблицаАдминистратор.Columns[2].HeaderText;
            Надпись4.Text = ТаблицаАдминистратор.Columns[3].HeaderText;
            Надпись5.Text = ТаблицаАдминистратор.Columns[4].HeaderText;
            Надпись6.Text = ТаблицаАдминистратор.Columns[5].HeaderText;
            Выход.Location = new Point(664, -1);
            ПолеПланКвартиры.Visible = false;
            Клиент.Visible = true;
            Клиент.Location = new Point(567, 26);
            Квартира.Visible = false;
            Дом.Visible = false;
            this.Size = new Size(688, 340);
            КвартираДом.Visible = false;
            Заселение.Visible = false;
            Договор.Visible = false;
            Продление.Visible = false;
            ГруппаЗаквата.Visible = false;
            Вызов.Visible = false;
            Пользователь.Visible = false;
            Надпись6.Visible = true;
            Надпись5.Visible = true;
            Надпись4.Visible = true;
            Надпись7.Visible = false;
        }

        private void flat_Click(object sender, EventArgs e)
        {
            c = 1;
            Table(c);
            PlanFlat.Text = ТаблицаАдминистратор.Columns[6].HeaderText;
            Надпись1.Text = ТаблицаАдминистратор.Columns[0].HeaderText;
            Надпись2.Text = ТаблицаАдминистратор.Columns[1].HeaderText;
            Надпись3.Text = ТаблицаАдминистратор.Columns[2].HeaderText;
            Надпись4.Text = ТаблицаАдминистратор.Columns[3].HeaderText;
            Надпись5.Text = ТаблицаАдминистратор.Columns[4].HeaderText;
            Надпись6.Text = ТаблицаАдминистратор.Columns[5].HeaderText;
            Выход.Location = new Point(839, -1);
            ПолеПланКвартиры.Visible = true;
            Клиент.Visible = false;
            Квартира.Visible = true;
            Квартира.Location = new Point(567, 26);
            Дом.Visible = false;
            КвартираДом.Visible = false;
            Заселение.Visible = false;
            Договор.Visible = false;
            Продление.Visible = false;
            ГруппаЗаквата.Visible = false;
            Вызов.Visible = false;
            Пользователь.Visible = false;
            Надпись4.Visible = true;
            Надпись5.Visible = true;
            Надпись7.Visible = false;
            this.Size = new Size(863, 340);
            ПолеТипБалкона.Text = НадписьТипБалкона.Text;
            ПолеТипДвери.Text = НадписьТипДвери.Text;
        }

        private void house_Click(object sender, EventArgs e)
        {
            c = 2;
            Table(c);
            Надпись1.Text = ТаблицаАдминистратор.Columns[0].HeaderText;
            Надпись2.Text = ТаблицаАдминистратор.Columns[1].HeaderText;
            Надпись3.Text = ТаблицаАдминистратор.Columns[2].HeaderText;
            Надпись4.Text = ТаблицаАдминистратор.Columns[3].HeaderText;
            Выход.Location = new Point(664, -1);
            ПолеПланКвартиры.Visible = false;
            Клиент.Visible = false;
            Квартира.Visible = false;
            Дом.Visible = true;
            Дом.Location = new Point(567, 26);
            КвартираДом.Visible = false;
            Заселение.Visible = false;
            Договор.Visible = false;
            Продление.Visible = false;
            ГруппаЗаквата.Visible = false;
            Вызов.Visible = false;
            Пользователь.Visible = false;
            Надпись4.Visible = true;
            Надпись6.Visible = false;
            Надпись5.Visible = false;
            Надпись7.Visible = false;
            this.Size = new Size(688, 340);
            ПолеТипДома.Text = НадписьТипДома.Text;
        }

        private void flatHouse_Click(object sender, EventArgs e)
        {
            c = 3;
            Table(c);
            Надпись1.Text = ТаблицаАдминистратор.Columns[0].HeaderText;
            Надпись2.Text = ТаблицаАдминистратор.Columns[1].HeaderText;
            Надпись3.Text = ТаблицаАдминистратор.Columns[2].HeaderText;
            Надпись6.Visible = false;
            Надпись5.Visible = false;
            Надпись4.Visible = false;
            Надпись7.Visible = false;
            Выход.Location = new Point(664, -1);
            Клиент.Visible = false;
            Квартира.Visible = false;
            Дом.Visible = false;
            КвартираДом.Visible = true;
            КвартираДом.Location = new Point(567, 26);
            Заселение.Visible = false;
            Договор.Visible = false;
            Продление.Visible = false;
            ГруппаЗаквата.Visible = false;
            Вызов.Visible = false;
            Пользователь.Visible = false;
            ПолеПланКвартиры.Visible = false;
            this.Size = new Size(688, 340);
        }

        private void settlement_Click(object sender, EventArgs e)
        {
            c = 4;
            Table(c);
            Надпись1.Text = ТаблицаАдминистратор.Columns[0].HeaderText;
            Надпись2.Text = ТаблицаАдминистратор.Columns[1].HeaderText;
            Надпись3.Text = ТаблицаАдминистратор.Columns[2].HeaderText;
            Выход.Location = new Point(664, -1);
            ПолеПланКвартиры.Visible = false;
            Клиент.Visible = false;
            Квартира.Visible = false;
            Дом.Visible = false;
            КвартираДом.Visible = false;
            Заселение.Visible = true;
            Заселение.Location = new Point(567, 26);
            Договор.Visible = false;
            Продление.Visible = false;
            ГруппаЗаквата.Visible = false;
            Вызов.Visible = false;
            Пользователь.Visible = false;
            Надпись6.Visible = false;
            Надпись5.Visible = false;
            Надпись4.Visible = false;
            Надпись7.Visible = false;
            this.Size = new Size(688, 340);
        }

        private void contract_Click(object sender, EventArgs e)
        {
            c = 5;
            Table(c);
            Надпись1.Text = ТаблицаАдминистратор.Columns[0].HeaderText;
            Надпись2.Text = ТаблицаАдминистратор.Columns[1].HeaderText;
            Надпись3.Text = ТаблицаАдминистратор.Columns[2].HeaderText;
            Надпись4.Text = ТаблицаАдминистратор.Columns[3].HeaderText;
            Надпись5.Text = ТаблицаАдминистратор.Columns[4].HeaderText;
            Выход.Location = new Point(664, -1);
            ПолеПланКвартиры.Visible = true;
            Клиент.Visible = false;
            Квартира.Visible = false;
            Дом.Visible = false;
            КвартираДом.Visible = false;
            Заселение.Visible = false;
            Договор.Visible = true;
            Договор.Location = new Point(567, 26);
            Продление.Visible = false;
            ГруппаЗаквата.Visible = false;
            Вызов.Visible = false;
            Пользователь.Visible = false;
            Надпись6.Visible = false;
            Надпись5.Visible = true;
            Надпись4.Visible = true;
            Надпись7.Visible = false;
            this.Size = new Size(688, 340);
        }

        private void prolonging_Click(object sender, EventArgs e)
        {
            c = 6;
            Table(c);
            Надпись1.Text = ТаблицаАдминистратор.Columns[0].HeaderText;
            Надпись2.Text = ТаблицаАдминистратор.Columns[1].HeaderText;
            Надпись3.Text = ТаблицаАдминистратор.Columns[2].HeaderText;
            Надпись4.Text = ТаблицаАдминистратор.Columns[3].HeaderText;
            Выход.Location = new Point(664, -1);
            ПолеПланКвартиры.Visible = false;
            Клиент.Visible = false;
            Квартира.Visible = false;
            Дом.Visible = false;
            КвартираДом.Visible = false;
            Заселение.Visible = false;
            Договор.Visible = false;
            Продление.Visible = true;
            Продление.Location = new Point(567, 26);
            ГруппаЗаквата.Visible = false;
            Вызов.Visible = false;
            Пользователь.Visible = false;
            Надпись4.Visible = true;
            Надпись6.Visible = false;
            Надпись5.Visible = false;
            Надпись7.Visible = false;
            this.Size = new Size(688, 340);
        }

        private void capture_Click(object sender, EventArgs e)
        {
            c = 7;
            Table(c);
            Надпись1.Text = ТаблицаАдминистратор.Columns[0].HeaderText;
            Надпись2.Text = ТаблицаАдминистратор.Columns[1].HeaderText;
            Надпись3.Text = ТаблицаАдминистратор.Columns[2].HeaderText;
            Надпись4.Text = ТаблицаАдминистратор.Columns[3].HeaderText;
            Надпись5.Text = ТаблицаАдминистратор.Columns[4].HeaderText;
            Выход.Location = new Point(664, -1);
            ПолеПланКвартиры.Visible = false;
            Клиент.Visible = false;
            Квартира.Visible = false;
            Дом.Visible = false;
            КвартираДом.Visible = false;
            Заселение.Visible = false;
            Договор.Visible = false;
            Продление.Visible = false;
            ГруппаЗаквата.Visible = true;
            ГруппаЗаквата.Location = new Point(567, 26);
            Вызов.Visible = false;
            Пользователь.Visible = false;
            Надпись6.Visible = false;
            Надпись5.Visible = true;
            Надпись4.Visible = true;
            Надпись7.Visible = false;
            this.Size = new Size(688, 340);
        }
        private void Выход_Click(object sender, EventArgs e)
        {
            //Выход из прилдожения
            Application.Exit();
        }

        private void вернутьсяКАвторизации_Click(object sender, EventArgs e)
        {
            //Переход на форму авторизации
            Авторизация ав = new Авторизация();
            Hide();
            ав.Show();
        }

        private void выйтиИзПриложения_Click_1(object sender, EventArgs e)
        {
            //Выход из приложения
            Application.Exit();
        }

        private void обновить_Click(object sender, EventArgs e)
        {//обновлени тыблиц базы данных
            switch (c)
            {
                case 0:clientTableAdapter.Update(уП_ПМ_01_Неверов_ДСDataSet.Client); break;
                case 1:flatTableAdapter.Update(уП_ПМ_01_Неверов_ДСDataSet.Flat); break;
                case 2:houseTableAdapter.Update(уП_ПМ_01_Неверов_ДСDataSet.House);  break;
                case 3:flat_HouseTableAdapter.Update(уП_ПМ_01_Неверов_ДСDataSet._Flat_House);  break;
                case 4:settlementTableAdapter.Update(уП_ПМ_01_Неверов_ДСDataSet.Settlement); break;
                case 5:contractTableAdapter.Update(уП_ПМ_01_Неверов_ДСDataSet.Contract); break;
                case 6:prolongingTableAdapter.Update(уП_ПМ_01_Неверов_ДСDataSet.Prolonging); break;
                case 7:captureTableAdapter.Update(уП_ПМ_01_Неверов_ДСDataSet.Capture);break;
                case 8:callingTableAdapter.Update(уП_ПМ_01_Неверов_ДСDataSet.Calling);break;
                case 11:userTableAdapter.Update(уП_ПМ_01_Неверов_ДСDataSet.User); break;
            }
        }

        private void calling_Click(object sender, EventArgs e)
        {
            c = 8;
            Table(c);
            Надпись1.Text = ТаблицаАдминистратор.Columns[0].HeaderText;
            Надпись2.Text = ТаблицаАдминистратор.Columns[1].HeaderText;
            Надпись3.Text = ТаблицаАдминистратор.Columns[2].HeaderText;
            Надпись4.Text = ТаблицаАдминистратор.Columns[3].HeaderText;
            Надпись5.Text = ТаблицаАдминистратор.Columns[4].HeaderText;
            Надпись6.Text = ТаблицаАдминистратор.Columns[5].HeaderText;
            Надпись7.Text = ТаблицаАдминистратор.Columns[6].HeaderText;
            Выход.Location = new Point(664, -1);
            ПолеПланКвартиры.Visible = false;
            Клиент.Visible = false;
            Квартира.Visible = false;
            Дом.Visible = false;
            КвартираДом.Visible = false;
            Заселение.Visible = false;
            Договор.Visible = false;
            Продление.Visible = false;
            ГруппаЗаквата.Visible = false;
            Вызов.Visible = true;
            Вызов.Location = new Point(567, 26);
            Пользователь.Visible = false;
            Надпись7.Visible = true; 
            Надпись6.Visible = true;
            Надпись5.Visible = true;
            Надпись4.Visible = true;
            Надпись7.Visible = true;
            this.Size = new Size(688, 340);
        }
        private void ПредыдущаяЗапись_Click(object sender, EventArgs e)
        {
            //Переход на предыдущую строку
            i = ТаблицаАдминистратор.RowCount;
             index = ТаблицаАдминистратор.CurrentRow.Index;
            if (index<=0)
            {
                ТаблицаАдминистратор.CurrentCell = ТаблицаАдминистратор[0, i-1];
            }
            else
            {
                ТаблицаАдминистратор.Rows[index].Selected = true;
                ТаблицаАдминистратор.CurrentCell = ТаблицаАдминистратор[0, index - 1];
            }
            ПолеПраваДоступа.Text = НадписьПраваДоступа.Text;
            ПолеТипБалкона.Text = НадписьТипБалкона.Text;
            ПолеТипДвери.Text = НадписьТипДвери.Text;
            ПолеТипДома.Text = НадписьТипДома.Text;
        }
        
        private void СледующаяЗапись_Click(object sender, EventArgs e)
        {
            //Переход на следующую строку
            i = ТаблицаАдминистратор.RowCount;
            index = ТаблицаАдминистратор.CurrentRow.Index;
            if (index >= (i - 1))
            {
                ТаблицаАдминистратор.CurrentCell = ТаблицаАдминистратор[0,0];
            }
            else
            {
                ТаблицаАдминистратор.Rows[index].Selected = true;
                ТаблицаАдминистратор.CurrentCell = ТаблицаАдминистратор[0, index + 1];
            }
            ПолеПраваДоступа.Text = НадписьПраваДоступа.Text;
            ПолеТипБалкона.Text = НадписьТипБалкона.Text;
            ПолеТипДвери.Text = НадписьТипДвери.Text;
            ПолеТипДома.Text = НадписьТипДома.Text;
        }

        private void ДобавитьЗапись_Click(object sender, EventArgs e)
        {
            //Добавление строки
            switch (c)
            {
                case 0:
                    using (SqlConnection sqlConnect = new SqlConnection("Data Source=sql;Initial Catalog = УП_ПМ_01_Неверов_ДС; Integrated Security = True"))
                    {
                        DataSet dt = new DataSet();
                        SqlDataAdapter da = new SqlDataAdapter();
                        da = new SqlDataAdapter($"INSERT INTO [Client] VALUES ('{ПолеКодКлиента.Text}','{ПолеФамилия.Text}','{ПолеИмя.Text}','{ПолеОтчество.Text}','{ПолеАдрес.Text}','{ПолеТелефон.Text}');", sqlConnect);
                        da.Fill(dt);
                        ПолеКодКлиента.Text = "";
                        ПолеФамилия.Text = "";
                        ПолеИмя.Text = "";
                        ПолеОтчество.Text = "";
                        ПолеАдрес.Text = "";
                        ПолеТелефон.Text = "";
                    }
                    break;
                case 1:
                    using (SqlConnection sqlConnect = new SqlConnection("Data Source=sql;Initial Catalog = УП_ПМ_01_Неверов_ДС; Integrated Security = True"))
                    {
                        DataSet dt = new DataSet();
                        SqlDataAdapter da = new SqlDataAdapter();
                        da = new SqlDataAdapter($"INSERT INTO [Flat] VALUES ('{ПолеКодКвартиры.Text}','{ПолеАдресКвартиры.Text}','{ПолеЭтажКвартиры.Text}','{ПолеТипДвери.Text}','{ЕстьБалкон.Text}','{ПолеТипБалкона.Text}','{Plan.Text}');", sqlConnect);
                        da.Fill(dt);
                        ПолеКодКлиента.Text = "";
                        ПолеФамилия.Text = "";
                        ПолеИмя.Text = "";
                        ПолеОтчество.Text = "";
                        ПолеАдрес.Text = "";
                        ПолеТелефон.Text = "";
                    }
                    break;
                case 2:
                    using (SqlConnection sqlConnect = new SqlConnection("Data Source=sql;Initial Catalog = УП_ПМ_01_Неверов_ДС; Integrated Security = True"))
                    {
                        DataSet dt = new DataSet();
                        SqlDataAdapter da = new SqlDataAdapter();
                        da = new SqlDataAdapter($"INSERT INTO [House] VALUES ('{ПолеКодДома.Text}','{ПолеЭтажейВДоме.Text}','{y}','{ПолеТипДома.Text}');", sqlConnect);
                        da.Fill(dt);
                        ПолеКодДома.Text = "";
                        ПолеЭтажейВДоме.Text = "";
                        ЕстьЗамок.Checked = false;
                        ПолеТипДома.Text = "";
                    }
                    break;
                case 3:
                    using (SqlConnection sqlConnect = new SqlConnection("Data Source=sql;Initial Catalog = УП_ПМ_01_Неверов_ДС; Integrated Security = True"))
                    {
                        DataSet dt = new DataSet();
                        SqlDataAdapter da = new SqlDataAdapter();
                        da = new SqlDataAdapter($"INSERT INTO [Flat-House] VALUES ('{ПолеКодКвартираДом.Text}','{ПолеКодКвартиры2.Text}','{ПолеКодДома2.Text}');", sqlConnect);
                        da.Fill(dt);
                        ПолеКодКвартираДом.Text = "";
                        ПолеКодКвартиры2.Text = "";
                        ПолеКодДома2.Text = "";
                    }
                    break;
                case 4:
                    using (SqlConnection sqlConnect = new SqlConnection("Data Source=sql;Initial Catalog = УП_ПМ_01_Неверов_ДС; Integrated Security = True"))
                    {
                        DataSet dt = new DataSet();
                        SqlDataAdapter da = new SqlDataAdapter();
                        da = new SqlDataAdapter($"INSERT INTO [Settlement] VALUES ('{ПолеКодЗаселения.Text}','{ПолеКодКвартиры3.Text}','{ПолеКодКлиента2.Text}');", sqlConnect);
                        da.Fill(dt);
                        ПолеКодЗаселения.Text = "";
                        ПолеКодКвартиры3.Text = "";
                        ПолеКодКлиента2.Text = "";
                    }
                    break;
                case 5:
                    using (SqlConnection sqlConnect = new SqlConnection("Data Source=sql;Initial Catalog = УП_ПМ_01_Неверов_ДС; Integrated Security = True"))
                    {
                        DataSet dt = new DataSet();
                        SqlDataAdapter da = new SqlDataAdapter();
                        da = new SqlDataAdapter($"INSERT INTO [Contract] VALUES ('{ПолеКодДоговора.Text}','{ПолеКодЗаселения2.Text}','{ПолеДатаНачала.Text}','{ПолеДатаОкончание.Text}','{ПолеПлата.Text}');", sqlConnect);
                        da.Fill(dt);
                        ПолеКодДоговора.Text = "";
                        ПолеКодЗаселения2.Text = "";
                        ПолеДатаНачала.Text = "";
                        ПолеДатаОкончание.Text = "";
                        ПолеПлата.Text = "";
                    }
                    break;
                case 6:
                    using (SqlConnection sqlConnect = new SqlConnection("Data Source=sql;Initial Catalog = УП_ПМ_01_Неверов_ДС; Integrated Security = True"))
                    {
                        DataSet dt = new DataSet();
                        SqlDataAdapter da = new SqlDataAdapter();
                        da = new SqlDataAdapter($"INSERT INTO [Prolonging] VALUES ('{ПолеКодПродление.Text}','{ПолеКодДоговора2.Text}','{ПолеДатаПродление.Text}','{ПолеКоммент.Text}');", sqlConnect);
                        da.Fill(dt);
                        ПолеКодПродление.Text = "";
                        ПолеКодДоговора2.Text = "";
                        ПолеДатаПродление.Text = "";
                        ПолеКоммент.Text = "";
                    }
                    break;
                case 7:
                    using (SqlConnection sqlConnect = new SqlConnection("Data Source=sql;Initial Catalog = УП_ПМ_01_Неверов_ДС; Integrated Security = True"))
                    {
                        DataSet dt = new DataSet();
                        SqlDataAdapter da = new SqlDataAdapter();
                        da = new SqlDataAdapter($"INSERT INTO [Capture] VALUES ('{ПолеКодГруппыЗахвата.Text}','{ПолеНомерЭкипажа.Text}','{ПолеКомандирЭкипажа.Text}','{ПолеАвтомобиль.Text}','{ПолеДокумент.Text}');", sqlConnect);
                        da.Fill(dt);
                        ПолеКодГруппыЗахвата.Text = "";
                        ПолеНомерЭкипажа.Text = "";
                        ПолеКомандирЭкипажа.Text = "";
                        ПолеАвтомобиль.Text = "";
                        ПолеДокумент.Text = "";
                    }
                    break;
                case 8:
                    using (SqlConnection sqlConnect = new SqlConnection("Data Source=sql;Initial Catalog = УП_ПМ_01_Неверов_ДС; Integrated Security = True"))
                    {
                        DataSet dt = new DataSet();
                        SqlDataAdapter da = new SqlDataAdapter();
                        da = new SqlDataAdapter($"INSERT INTO [Calling] VALUES ('{ПолеКодВызова.Text}','{ПолеКодДоговора3.Text}','{ПолеКодГруппыЗахвата2.Text}','{ПолеДатаВызова.Text}','{v}','{ПолеШтраф.Text}','{ПолеКомпенсация.Text}');", sqlConnect);
                        da.Fill(dt);
                        ПолеКодВызова.Text = "";
                        ПолеКодДоговора3.Text = "";
                        ПолеКодГруппыЗахвата2.Text = "";
                        ПолеДатаВызова.Text = "";
                        ЛожныйВызов.Checked = false;
                        ПолеШтраф.Text = "";
                        ПолеКомпенсация.Text = "";
                    }
                    break;
                case 11:
                    using (SqlConnection sqlConnect = new SqlConnection("Data Source=sql;Initial Catalog = УП_ПМ_01_Неверов_ДС; Integrated Security = True"))
                    {
                        DataSet dt = new DataSet();
                        SqlDataAdapter da = new SqlDataAdapter();
                        da = new SqlDataAdapter($"INSERT INTO [User] VALUES ('{ПолеЛогин.Text}','{ПолеПароль.Text}','{ПолеПраваДоступа.Text}','{ПолеКодКлиента3.Text}');", sqlConnect);
                        da.Fill(dt);
                        ПолеЛогин.Text = "";
                        ПолеПароль.Text = "";
                        ПолеКодКлиента3.Text = "";
                        ПолеПраваДоступа.Text = "";
                    }
                    break;
            }
        }

        private void УдалитьЗапись_Click(object sender, EventArgs e)
        {
            //удаление выделенный строки
            for (int i = 0; i < ТаблицаАдминистратор.RowCount; i++)
            {
                if (ТаблицаАдминистратор.Rows[i].Cells[0].Selected == true)
                {
                    ТаблицаАдминистратор.Rows.RemoveAt(i);
                }
            }
        }
        private void ПолеПланКвартиры_Click(object sender, EventArgs e)
        {
            //открытие проводника для вставки картинки в pictureBox6 по нажатию на pictureBox6
            ВставкаКартинки.Filter = "Image files (*.BMP, *.JPG, " + "*.GIF, *.PNG)|*.bmp;*.jpg;*.gif;*.png";
            if (ВставкаКартинки.ShowDialog() == DialogResult.OK)
            {
                Image image = Image.FromFile(ВставкаКартинки.FileName);
                int width = ПолеПланКвартиры.Width;
                int height = ПолеПланКвартиры.Height;
                bmp = new Bitmap(image, width, height);
                ПолеПланКвартиры.Image = bmp;
                Plan.Text = ВставкаКартинки.FileName;
            }
        }

        private void ПолеПоиск_TextChanged(object sender, EventArgs e)
        {
            //Поиск строк 
            for (int i = 0; i < ТаблицаАдминистратор.RowCount; i++)
            {
                ТаблицаАдминистратор.Rows[i].Selected = false;
                for (int j = 0; j < ТаблицаАдминистратор.ColumnCount; j++)
                {
                    if (ТаблицаАдминистратор.Rows[i].Cells[j].Value != null)
                    {
                        if (ТаблицаАдминистратор.Rows[i].Cells[j].Value.ToString().Contains(ПолеПоиск.Text))
                        {
                            ТаблицаАдминистратор.Rows[i].Selected = true;
                            break;
                        }
                    }
                }
            }
        }

        private void ТаблицаАдминистратор_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            //вставка картинки при фокусе на строки таблицы
            ПолеПланКвартиры.ImageLocation = Plan.Text;
        }

        private void ЕстьБалкон_CheckedChanged(object sender, EventArgs e)
        {
            if (ЕстьБалкон.Checked == true)
            {
                g = 1;
                ПолеТипБалкона.Visible = true;
                Надпись6.Visible = true;
            }
            else if (ЕстьБалкон.Checked == false)
            {
                g = 0;
                ПолеТипБалкона.Visible = false;
                Надпись6.Visible = false;
            }
        }

        private void ЕстьЗамок_CheckedChanged(object sender, EventArgs e)
        {
            if (ЕстьЗамок.Checked == true)
            {
                y = 1;
            }
            else if (ЕстьЗамок.Checked == false)
            {
                y = 0;
            }
        }

        private void ПолеПраваДоступа_SelectedIndexChanged(object sender, EventArgs e)
        {
            НадписьПраваДоступа.Text = ПолеПраваДоступа.Text;
        }

        private void ПолеТипДома_SelectedIndexChanged(object sender, EventArgs e)
        {
            НадписьТипДома.Text = ПолеТипДома.Text;
        }
        
        private void Администратор_MouseDown(object sender, MouseEventArgs e)
        {
            //отпеделяет точку где была эажата клавиша мыши на форме
            mouse = new Point(e.X, e.Y);
        }

        private void Администратор_MouseMove(object sender, MouseEventArgs e)
        {
            //передвигает форму по тому как движется мышка по экрану
            if (e.Button == MouseButtons.Left)
            {
                Left += e.X - mouse.X;
                Top += e.Y - mouse.Y;
            }
        }

        private void ПолеТипДвери_SelectedIndexChanged(object sender, EventArgs e)
        {
            НадписьТипДвери.Text = ПолеТипДвери.Text;
        }

        private void ПолеТипБалкона_SelectedIndexChanged(object sender, EventArgs e)
        {
            НадписьТипБалкона.Text = ПолеТипБалкона.Text;
        }

        private void ПолеКодКлиента_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                ПолеФамилия.Focus();
            }
            if ((e.KeyChar >='0')&&(e.KeyChar <= '9')||(e.KeyChar==(char)Keys.Back))
            {

            }
            else
            {
                e.KeyChar -= e.KeyChar;
            }
        }

        private void ПолеФамилия_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                ПолеИмя.Focus();
            }
        }

        private void ПолеИмя_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                ПолеОтчество.Focus();
            }
        }

        private void ПолеОтчество_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                ПолеАдрес.Focus();
            }
        }

        private void ПолеАдрес_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                ПолеТелефон.Focus();
            }
        }

        private void ПолеКодАдресКвартиры_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                ПолеАдресКвартиры.Focus();
            }
            if ((e.KeyChar >= '0') && (e.KeyChar <= '9') || (e.KeyChar == (char)Keys.Back))
            {

            }
            else
            {
                e.KeyChar -= e.KeyChar;
            }
        }

        private void ПолеАдресКвартиры_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                ПолеЭтажКвартиры.Focus();
            }
        }

        private void ПолеЭтажКвартиры_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                ПолеТипДвери.Focus();
            }
            if ((e.KeyChar >= '0') && (e.KeyChar <= '9') || (e.KeyChar == (char)Keys.Back))
            {

            }
            else
            {
                e.KeyChar -= e.KeyChar;
            }
        }

        private void ПолеКодКвартираДом_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                ПолеКодКвартиры2.Focus();
            }
            if ((e.KeyChar >= '0') && (e.KeyChar <= '9') || (e.KeyChar == (char)Keys.Back))
            {

            }
            else
            {
                e.KeyChar -= e.KeyChar;
            }
        }

        private void ПолеКодКвартиры2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                ПолеКодДома2.Focus();
            }
            if ((e.KeyChar >= '0') && (e.KeyChar <= '9') || (e.KeyChar == (char)Keys.Back))
            {

            }
            else
            {
                e.KeyChar -= e.KeyChar;
            }
        }

        private void ПолеКодДома_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                ПолеЭтажейВДоме.Focus();
            }
            if ((e.KeyChar >= '0') && (e.KeyChar <= '9') || (e.KeyChar == (char)Keys.Back))
            {

            }
            else
            {
                e.KeyChar -= e.KeyChar;
            }
        }

        private void ПолеЭтажейВДоме_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= '0') && (e.KeyChar <= '9') || (e.KeyChar == (char)Keys.Back))
            {

            }
            else
            {
                e.KeyChar -= e.KeyChar;
            }
        }

        private void ПолеКодКлиента2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= '0') && (e.KeyChar <= '9') || (e.KeyChar == (char)Keys.Back))
            {

            }
            else
            {
                e.KeyChar -= e.KeyChar;
            }
        }

        private void ПолеКодЗаселения_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                ПолеКодКвартиры3.Focus();
            }
            if ((e.KeyChar >= '0') && (e.KeyChar <= '9') || (e.KeyChar == (char)Keys.Back))
            {

            }
            else
            {
                e.KeyChar -= e.KeyChar;
            }
        }

        private void ПолеКодКвартиры3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                ПолеКодКлиента2.Focus();
            }
            if ((e.KeyChar >= '0') && (e.KeyChar <= '9') || (e.KeyChar == (char)Keys.Back))
            {

            }
            else
            {
                e.KeyChar -= e.KeyChar;
            }
        }

        private void ПолеКодДоговора_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                ПолеКодЗаселения2.Focus();
            }
            if ((e.KeyChar >= '0') && (e.KeyChar <= '9') || (e.KeyChar == (char)Keys.Back))
            {

            }
            else
            {
                e.KeyChar -= e.KeyChar;
            }
        }

        private void ПолеКодЗаселения2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                ПолеДатаНачала.Focus();
            }
            if ((e.KeyChar >= '0') && (e.KeyChar <= '9') || (e.KeyChar == (char)Keys.Back))
            {

            }
            else
            {
                e.KeyChar -= e.KeyChar;
            }
        }

        private void ПолеДатаНачала_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                ПолеДатаОкончание.Focus();
            }
        }

        private void ПолеДатаОкончание_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                ПолеПлата.Focus();
            }
        }

        private void ПолеКодПродление_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                ПолеКодДоговора2.Focus();
            }
            if ((e.KeyChar >= '0') && (e.KeyChar <= '9') || (e.KeyChar == (char)Keys.Back))
            {

            }
            else
            {
                e.KeyChar -= e.KeyChar;
            }
        }

        private void ПолеКодДоговора2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                ПолеДатаПродление.Focus();
            }
            if ((e.KeyChar >= '0') && (e.KeyChar <= '9') || (e.KeyChar == (char)Keys.Back))
            {

            }
            else
            {
                e.KeyChar -= e.KeyChar;
            }
        }

        private void ПолеДатаПродление_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                ПолеКоммент.Focus();
            }
        }

        private void ПолеКодГруппыЗахвата_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                ПолеНомерЭкипажа.Focus();
            }
            if ((e.KeyChar >= '0') && (e.KeyChar <= '9') || (e.KeyChar == (char)Keys.Back))
            {

            }
            else
            {
                e.KeyChar -= e.KeyChar;
            }
        }

        private void ПолеНомерЭкипажа_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                ПолеКомандирЭкипажа.Focus();
            }
            if ((e.KeyChar >= '0') && (e.KeyChar <= '9') || (e.KeyChar == (char)Keys.Back))
            {

            }
            else
            {
                e.KeyChar -= e.KeyChar;
            }
        }

        private void ПолеКомандирЭкипажа_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                ПолеАвтомобиль.Focus();
            }
        }

        private void ПолеАвтомобиль_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                ПолеДокумент.Focus();
            }
        }

        private void ПолеКодВызова_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                ПолеКодДоговора3.Focus();
            }
            if ((e.KeyChar >= '0') && (e.KeyChar <= '9') || (e.KeyChar == (char)Keys.Back))
            {

            }
            else
            {
                e.KeyChar -= e.KeyChar;
            }
        }

        private void ПолеКодДоговора3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                ПолеКодГруппыЗахвата2.Focus();
            }
            if ((e.KeyChar >= '0') && (e.KeyChar <= '9') || (e.KeyChar == (char)Keys.Back))
            {

            }
            else
            {
                e.KeyChar -= e.KeyChar;
            }
        }

        private void ПолеКодГруппыВызова_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                ПолеДатаВызова.Focus();
            }
            if ((e.KeyChar >= '0') && (e.KeyChar <= '9') || (e.KeyChar == (char)Keys.Back))
            {

            }
            else
            {
                e.KeyChar -= e.KeyChar;
            }
        }

        private void ПолеШтраф_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                ПолеКомпенсация.Focus();
            }
            if ((e.KeyChar >= '0') && (e.KeyChar <= '9') || (e.KeyChar == (char)Keys.Back))
            {

            }
            else
            {
                e.KeyChar -= e.KeyChar;
            }
        }

        private void ПолеЛогин_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                ПолеПароль.Focus();
            }
        }

        private void ПолеПароль_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                ПолеПраваДоступа.Focus();
            }
        }

        private void ПолеПраваДоступа_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                ПолеКодКлиента3.Focus();
            }
        }

        private void ПолеКодКлиента3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= '0') && (e.KeyChar <= '9') || (e.KeyChar == (char)Keys.Back))
            {

            }
            else
            {
                e.KeyChar -= e.KeyChar;
            }
        }

        private void формаКП_Click(object sender, EventArgs e)
        {
            //Переход на форму конечного пользователя
            КП rg = new КП();
            rg.Show();
            rg.Dostup("Админ");
        }

        private void ОбновлениеЗаписей_Click(object sender, EventArgs e)
        {
            //обновление таблиц базы данных
            switch (c)
            {
                case 0: clientTableAdapter.Update(уП_ПМ_01_Неверов_ДСDataSet.Client); break;
                case 1: flatTableAdapter.Update(уП_ПМ_01_Неверов_ДСDataSet.Flat); break;
                case 2: houseTableAdapter.Update(уП_ПМ_01_Неверов_ДСDataSet.House); break;
                case 3: flat_HouseTableAdapter.Update(уП_ПМ_01_Неверов_ДСDataSet._Flat_House); break;
                case 4: settlementTableAdapter.Update(уП_ПМ_01_Неверов_ДСDataSet.Settlement); break;
                case 5: contractTableAdapter.Update(уП_ПМ_01_Неверов_ДСDataSet.Contract); break;
                case 6: prolongingTableAdapter.Update(уП_ПМ_01_Неверов_ДСDataSet.Prolonging); break;
                case 7: captureTableAdapter.Update(уП_ПМ_01_Неверов_ДСDataSet.Capture); break;
                case 8: callingTableAdapter.Update(уП_ПМ_01_Неверов_ДСDataSet.Calling); break;
                case 11: userTableAdapter.Update(уП_ПМ_01_Неверов_ДСDataSet.User); break;
            }
        }

        private void ПерваяЗапись_Click(object sender, EventArgs e)
        {
            //переход на первую строку таблицы
            ТаблицаАдминистратор.CurrentCell = ТаблицаАдминистратор[0, 0];
            ПолеПраваДоступа.Text = НадписьПраваДоступа.Text;
            ПолеТипБалкона.Text = НадписьТипБалкона.Text;
            ПолеТипДвери.Text = НадписьТипДвери.Text;
            ПолеТипДома.Text = НадписьТипДома.Text;
        }

        private void ПоследняяЗапись_Click(object sender, EventArgs e)
        {
            //переход на последную строку таблицы
            ТаблицаАдминистратор.ClearSelection(); //снять выделение всех выбранных ячеек
            index = ТаблицаАдминистратор.Rows.Count - 1; // индекс последней строки
            ТаблицаАдминистратор.Rows[index].Selected = true; // выделить нужную строку
            ТаблицаАдминистратор.CurrentCell = ТаблицаАдминистратор[0, index];
            ПолеПраваДоступа.Text = НадписьПраваДоступа.Text;
            ПолеТипБалкона.Text = НадписьТипБалкона.Text;
            ПолеТипДвери.Text = НадписьТипДвери.Text;
            ПолеТипДома.Text = НадписьТипДома.Text;
        }
        
        private void ЛожныйВызов_CheckedChanged(object sender, EventArgs e)
        {
            if (ЛожныйВызов.Checked == true)
            {
                v = 1;
            }
            else if (ЛожныйВызов.Checked == false)
            {
                v = 0;
            }
        }
    }
}
