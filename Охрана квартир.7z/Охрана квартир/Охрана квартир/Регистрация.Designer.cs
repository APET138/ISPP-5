﻿namespace Охрана_квартир
{
    partial class Регистрация
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Регистрация));
            this.ДанныеКлиента = new System.Windows.Forms.GroupBox();
            this.ПолеТелефон = new System.Windows.Forms.MaskedTextBox();
            this.ПолеПароль = new System.Windows.Forms.TextBox();
            this.Пароль = new System.Windows.Forms.Label();
            this.ПолеЛогин = new System.Windows.Forms.TextBox();
            this.Логин = new System.Windows.Forms.Label();
            this.Телефон = new System.Windows.Forms.Label();
            this.ПолеАдрес = new System.Windows.Forms.TextBox();
            this.Адрес = new System.Windows.Forms.Label();
            this.ПолеОтчество = new System.Windows.Forms.TextBox();
            this.Отчество = new System.Windows.Forms.Label();
            this.ПолеИмя = new System.Windows.Forms.TextBox();
            this.Имя = new System.Windows.Forms.Label();
            this.ПолеФамилия = new System.Windows.Forms.TextBox();
            this.Фамилия = new System.Windows.Forms.Label();
            this.Зарегистрироваться = new System.Windows.Forms.Button();
            this.Надпись = new System.Windows.Forms.Label();
            this.НадписьРегистрация = new System.Windows.Forms.Label();
            this.Выйти = new System.Windows.Forms.PictureBox();
            this.Вернуться = new System.Windows.Forms.PictureBox();
            this.уП_ПМ_01_Неверов_ДСDataSet1 = new Охрана_квартир.УП_ПМ_01_Неверов_ДСDataSet();
            this.bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.clientTableAdapter1 = new Охрана_квартир.УП_ПМ_01_Неверов_ДСDataSetTableAdapters.ClientTableAdapter();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ТаблицаКлиент = new System.Windows.Forms.DataGridView();
            this.ДанныеКлиента.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Выйти)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Вернуться)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.уП_ПМ_01_Неверов_ДСDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ТаблицаКлиент)).BeginInit();
            this.SuspendLayout();
            // 
            // ДанныеКлиента
            // 
            this.ДанныеКлиента.Controls.Add(this.ПолеТелефон);
            this.ДанныеКлиента.Controls.Add(this.ПолеПароль);
            this.ДанныеКлиента.Controls.Add(this.Пароль);
            this.ДанныеКлиента.Controls.Add(this.ПолеЛогин);
            this.ДанныеКлиента.Controls.Add(this.Логин);
            this.ДанныеКлиента.Controls.Add(this.Телефон);
            this.ДанныеКлиента.Controls.Add(this.ПолеАдрес);
            this.ДанныеКлиента.Controls.Add(this.Адрес);
            this.ДанныеКлиента.Controls.Add(this.ПолеОтчество);
            this.ДанныеКлиента.Controls.Add(this.Отчество);
            this.ДанныеКлиента.Controls.Add(this.ПолеИмя);
            this.ДанныеКлиента.Controls.Add(this.Имя);
            this.ДанныеКлиента.Controls.Add(this.ПолеФамилия);
            this.ДанныеКлиента.Controls.Add(this.Фамилия);
            this.ДанныеКлиента.Location = new System.Drawing.Point(12, 107);
            this.ДанныеКлиента.Name = "ДанныеКлиента";
            this.ДанныеКлиента.Size = new System.Drawing.Size(300, 225);
            this.ДанныеКлиента.TabIndex = 1;
            this.ДанныеКлиента.TabStop = false;
            // 
            // ПолеТелефон
            // 
            this.ПолеТелефон.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ПолеТелефон.Location = new System.Drawing.Point(164, 32);
            this.ПолеТелефон.Mask = "9990000000";
            this.ПолеТелефон.Name = "ПолеТелефон";
            this.ПолеТелефон.ShortcutsEnabled = false;
            this.ПолеТелефон.Size = new System.Drawing.Size(129, 26);
            this.ПолеТелефон.TabIndex = 14;
            this.ПолеТелефон.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ПолеТелефон_KeyPress);
            // 
            // ПолеПароль
            // 
            this.ПолеПароль.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ПолеПароль.Location = new System.Drawing.Point(164, 132);
            this.ПолеПароль.MaxLength = 40;
            this.ПолеПароль.Name = "ПолеПароль";
            this.ПолеПароль.ShortcutsEnabled = false;
            this.ПолеПароль.Size = new System.Drawing.Size(129, 26);
            this.ПолеПароль.TabIndex = 13;
            this.ПолеПароль.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ПолеПароль_KeyPress);
            // 
            // Пароль
            // 
            this.Пароль.AutoSize = true;
            this.Пароль.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Пароль.Location = new System.Drawing.Point(167, 110);
            this.Пароль.Name = "Пароль";
            this.Пароль.Size = new System.Drawing.Size(71, 20);
            this.Пароль.TabIndex = 12;
            this.Пароль.Text = "Пароль:";
            // 
            // ПолеЛогин
            // 
            this.ПолеЛогин.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ПолеЛогин.Location = new System.Drawing.Point(164, 82);
            this.ПолеЛогин.MaxLength = 40;
            this.ПолеЛогин.Name = "ПолеЛогин";
            this.ПолеЛогин.ShortcutsEnabled = false;
            this.ПолеЛогин.Size = new System.Drawing.Size(129, 26);
            this.ПолеЛогин.TabIndex = 11;
            this.ПолеЛогин.TextChanged += new System.EventHandler(this.ПолеЛогин_TextChanged);
            this.ПолеЛогин.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ПолеЛогин_KeyPress);
            // 
            // Логин
            // 
            this.Логин.AutoSize = true;
            this.Логин.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Логин.Location = new System.Drawing.Point(167, 60);
            this.Логин.Name = "Логин";
            this.Логин.Size = new System.Drawing.Size(59, 20);
            this.Логин.TabIndex = 10;
            this.Логин.Text = "Логин:";
            // 
            // Телефон
            // 
            this.Телефон.AutoSize = true;
            this.Телефон.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Телефон.Location = new System.Drawing.Point(167, 10);
            this.Телефон.Name = "Телефон";
            this.Телефон.Size = new System.Drawing.Size(83, 20);
            this.Телефон.TabIndex = 8;
            this.Телефон.Text = "Телефон:";
            // 
            // ПолеАдрес
            // 
            this.ПолеАдрес.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ПолеАдрес.Location = new System.Drawing.Point(6, 182);
            this.ПолеАдрес.MaxLength = 60;
            this.ПолеАдрес.Name = "ПолеАдрес";
            this.ПолеАдрес.ShortcutsEnabled = false;
            this.ПолеАдрес.Size = new System.Drawing.Size(129, 26);
            this.ПолеАдрес.TabIndex = 7;
            this.ПолеАдрес.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ПолеАдрес_KeyPress);
            // 
            // Адрес
            // 
            this.Адрес.AutoSize = true;
            this.Адрес.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Адрес.Location = new System.Drawing.Point(9, 160);
            this.Адрес.Name = "Адрес";
            this.Адрес.Size = new System.Drawing.Size(61, 20);
            this.Адрес.TabIndex = 6;
            this.Адрес.Text = "Адрес:";
            // 
            // ПолеОтчество
            // 
            this.ПолеОтчество.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ПолеОтчество.Location = new System.Drawing.Point(6, 132);
            this.ПолеОтчество.MaxLength = 60;
            this.ПолеОтчество.Name = "ПолеОтчество";
            this.ПолеОтчество.ShortcutsEnabled = false;
            this.ПолеОтчество.Size = new System.Drawing.Size(129, 26);
            this.ПолеОтчество.TabIndex = 5;
            this.ПолеОтчество.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ПолеОтчество_KeyPress);
            // 
            // Отчество
            // 
            this.Отчество.AutoSize = true;
            this.Отчество.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Отчество.Location = new System.Drawing.Point(9, 110);
            this.Отчество.Name = "Отчество";
            this.Отчество.Size = new System.Drawing.Size(87, 20);
            this.Отчество.TabIndex = 4;
            this.Отчество.Text = "Отчество:";
            // 
            // ПолеИмя
            // 
            this.ПолеИмя.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ПолеИмя.Location = new System.Drawing.Point(6, 82);
            this.ПолеИмя.MaxLength = 60;
            this.ПолеИмя.Name = "ПолеИмя";
            this.ПолеИмя.ShortcutsEnabled = false;
            this.ПолеИмя.Size = new System.Drawing.Size(129, 26);
            this.ПолеИмя.TabIndex = 3;
            this.ПолеИмя.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ПолеИмя_KeyPress);
            // 
            // Имя
            // 
            this.Имя.AutoSize = true;
            this.Имя.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Имя.Location = new System.Drawing.Point(9, 60);
            this.Имя.Name = "Имя";
            this.Имя.Size = new System.Drawing.Size(44, 20);
            this.Имя.TabIndex = 2;
            this.Имя.Text = "Имя:";
            // 
            // ПолеФамилия
            // 
            this.ПолеФамилия.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ПолеФамилия.Location = new System.Drawing.Point(6, 32);
            this.ПолеФамилия.MaxLength = 60;
            this.ПолеФамилия.Name = "ПолеФамилия";
            this.ПолеФамилия.ShortcutsEnabled = false;
            this.ПолеФамилия.Size = new System.Drawing.Size(129, 26);
            this.ПолеФамилия.TabIndex = 1;
            this.ПолеФамилия.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ПолеФамилия_KeyPress);
            // 
            // Фамилия
            // 
            this.Фамилия.AutoSize = true;
            this.Фамилия.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Фамилия.Location = new System.Drawing.Point(9, 10);
            this.Фамилия.Name = "Фамилия";
            this.Фамилия.Size = new System.Drawing.Size(85, 20);
            this.Фамилия.TabIndex = 0;
            this.Фамилия.Text = "Фамилия:";
            // 
            // Зарегистрироваться
            // 
            this.Зарегистрироваться.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Зарегистрироваться.Location = new System.Drawing.Point(56, 338);
            this.Зарегистрироваться.Name = "Зарегистрироваться";
            this.Зарегистрироваться.Size = new System.Drawing.Size(213, 30);
            this.Зарегистрироваться.TabIndex = 2;
            this.Зарегистрироваться.Text = "Зарегистрироваться";
            this.Зарегистрироваться.UseVisualStyleBackColor = true;
            this.Зарегистрироваться.Click += new System.EventHandler(this.Зарегистрироваться_Click);
            // 
            // Надпись
            // 
            this.Надпись.AutoSize = true;
            this.Надпись.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Надпись.Location = new System.Drawing.Point(13, 80);
            this.Надпись.Name = "Надпись";
            this.Надпись.Size = new System.Drawing.Size(0, 20);
            this.Надпись.TabIndex = 23;
            // 
            // НадписьРегистрация
            // 
            this.НадписьРегистрация.AutoSize = true;
            this.НадписьРегистрация.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.НадписьРегистрация.Location = new System.Drawing.Point(55, 29);
            this.НадписьРегистрация.Name = "НадписьРегистрация";
            this.НадписьРегистрация.Size = new System.Drawing.Size(253, 37);
            this.НадписьРегистрация.TabIndex = 24;
            this.НадписьРегистрация.Text = "РЕГИСТРАЦИЯ";
            // 
            // Выйти
            // 
            this.Выйти.Image = ((System.Drawing.Image)(resources.GetObject("Выйти.Image")));
            this.Выйти.Location = new System.Drawing.Point(302, -1);
            this.Выйти.Name = "Выйти";
            this.Выйти.Size = new System.Drawing.Size(24, 24);
            this.Выйти.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Выйти.TabIndex = 26;
            this.Выйти.TabStop = false;
            this.Выйти.Click += new System.EventHandler(this.Выйти_Click);
            // 
            // Вернуться
            // 
            this.Вернуться.Image = ((System.Drawing.Image)(resources.GetObject("Вернуться.Image")));
            this.Вернуться.Location = new System.Drawing.Point(272, -1);
            this.Вернуться.Name = "Вернуться";
            this.Вернуться.Size = new System.Drawing.Size(24, 24);
            this.Вернуться.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Вернуться.TabIndex = 27;
            this.Вернуться.TabStop = false;
            this.Вернуться.Click += new System.EventHandler(this.Вернуться_Click);
            // 
            // уП_ПМ_01_Неверов_ДСDataSet1
            // 
            this.уП_ПМ_01_Неверов_ДСDataSet1.DataSetName = "УП_ПМ_01_Неверов_ДСDataSet";
            this.уП_ПМ_01_Неверов_ДСDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // bindingSource1
            // 
            this.bindingSource1.DataMember = "Client";
            this.bindingSource1.DataSource = this.уП_ПМ_01_Неверов_ДСDataSet1;
            // 
            // clientTableAdapter1
            // 
            this.clientTableAdapter1.ClearBeforeFill = true;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "Phone";
            this.dataGridViewTextBoxColumn6.HeaderText = "Phone";
            this.dataGridViewTextBoxColumn6.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            this.dataGridViewTextBoxColumn6.Width = 125;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "Address";
            this.dataGridViewTextBoxColumn5.HeaderText = "Address";
            this.dataGridViewTextBoxColumn5.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.Width = 125;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "ThirdName";
            this.dataGridViewTextBoxColumn4.HeaderText = "ThirdName";
            this.dataGridViewTextBoxColumn4.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.Width = 125;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "FirstName";
            this.dataGridViewTextBoxColumn3.HeaderText = "FirstName";
            this.dataGridViewTextBoxColumn3.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.Width = 125;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "SecondName";
            this.dataGridViewTextBoxColumn2.HeaderText = "SecondName";
            this.dataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Width = 125;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Registr";
            this.dataGridViewTextBoxColumn1.HeaderText = "Registr";
            this.dataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 125;
            // 
            // ТаблицаКлиент
            // 
            this.ТаблицаКлиент.AllowUserToAddRows = false;
            this.ТаблицаКлиент.AllowUserToDeleteRows = false;
            this.ТаблицаКлиент.AutoGenerateColumns = false;
            this.ТаблицаКлиент.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ТаблицаКлиент.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6});
            this.ТаблицаКлиент.DataSource = this.bindingSource1;
            this.ТаблицаКлиент.Location = new System.Drawing.Point(403, 56);
            this.ТаблицаКлиент.Name = "ТаблицаКлиент";
            this.ТаблицаКлиент.ReadOnly = true;
            this.ТаблицаКлиент.RowHeadersWidth = 51;
            this.ТаблицаКлиент.Size = new System.Drawing.Size(240, 150);
            this.ТаблицаКлиент.TabIndex = 28;
            // 
            // Регистрация
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(213)))), ((int)(((byte)(213)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(327, 375);
            this.Controls.Add(this.ТаблицаКлиент);
            this.Controls.Add(this.Вернуться);
            this.Controls.Add(this.Выйти);
            this.Controls.Add(this.НадписьРегистрация);
            this.Controls.Add(this.ДанныеКлиента);
            this.Controls.Add(this.Надпись);
            this.Controls.Add(this.Зарегистрироваться);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Регистрация";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Регистрация";
            this.Load += new System.EventHandler(this.Регистрация_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Регистрация_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Регистрация_MouseMove);
            this.ДанныеКлиента.ResumeLayout(false);
            this.ДанныеКлиента.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Выйти)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Вернуться)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.уП_ПМ_01_Неверов_ДСDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ТаблицаКлиент)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.GroupBox ДанныеКлиента;
        private System.Windows.Forms.Button Зарегистрироваться;
        private System.Windows.Forms.Label Телефон;
        private System.Windows.Forms.TextBox ПолеАдрес;
        private System.Windows.Forms.Label Адрес;
        private System.Windows.Forms.TextBox ПолеОтчество;
        private System.Windows.Forms.Label Отчество;
        private System.Windows.Forms.TextBox ПолеИмя;
        private System.Windows.Forms.Label Имя;
        private System.Windows.Forms.TextBox ПолеФамилия;
        private System.Windows.Forms.Label Фамилия;
        private System.Windows.Forms.TextBox ПолеПароль;
        private System.Windows.Forms.Label Пароль;
        private System.Windows.Forms.TextBox ПолеЛогин;
        private System.Windows.Forms.Label Логин;
        private System.Windows.Forms.Label Надпись;
        private System.Windows.Forms.MaskedTextBox ПолеТелефон;
        private System.Windows.Forms.Label НадписьРегистрация;
        private System.Windows.Forms.PictureBox Выйти;
        private System.Windows.Forms.PictureBox Вернуться;
        private System.Windows.Forms.DataGridView dataGridView1;
        private УП_ПМ_01_Неверов_ДСDataSet уП_ПМ_01_Неверов_ДСDataSet;
        private System.Windows.Forms.BindingSource clientBindingSource;
        private УП_ПМ_01_Неверов_ДСDataSetTableAdapters.ClientTableAdapter clientTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn registrDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn secondNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn firstNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn thirdNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn addressDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn phoneDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource clientBindingSource1;
        private System.Windows.Forms.BindingSource уППМ01НеверовДСDataSet2BindingSource;
       
        private System.Windows.Forms.BindingSource уППМ01НеверовДСDataSetBindingSource;
        private УП_ПМ_01_Неверов_ДСDataSet уП_ПМ_01_Неверов_ДСDataSet1;
        private System.Windows.Forms.BindingSource bindingSource1;
        private УП_ПМ_01_Неверов_ДСDataSetTableAdapters.ClientTableAdapter clientTableAdapter1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridView ТаблицаКлиент;
    }
}