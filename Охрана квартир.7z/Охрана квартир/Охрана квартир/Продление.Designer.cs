﻿namespace Охрана_квартир
{
    partial class Продление
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Продление));
            this.Выйти = new System.Windows.Forms.PictureBox();
            this.ТаблицаПродление = new System.Windows.Forms.DataGridView();
            this.prolongingIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.treatyIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.prolongDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.commentDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.prolongingBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.уП_ПМ_01_Неверов_ДСDataSet = new Охрана_квартир.УП_ПМ_01_Неверов_ДСDataSet();
            this.ПолеАдрес = new System.Windows.Forms.ComboBox();
            this.ПолеКоммент = new System.Windows.Forms.TextBox();
            this.АдресКвартиры = new System.Windows.Forms.Label();
            this.ДатаПродления = new System.Windows.Forms.Label();
            this.ДопУсловия = new System.Windows.Forms.Label();
            this.Продлить = new System.Windows.Forms.Button();
            this.ДействиеДоговора = new System.Windows.Forms.Label();
            this.ТаблицаДоговор = new System.Windows.Forms.DataGridView();
            this.registrDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.addressFlatDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.treatyIDDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dateStartDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.stopDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.адресдоговорBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.ДатаНачала = new System.Windows.Forms.Label();
            this.ДатаОкончания = new System.Windows.Forms.Label();
            this.prolongingTableAdapter = new Охрана_квартир.УП_ПМ_01_Неверов_ДСDataSetTableAdapters.ProlongingTableAdapter();
            this.клиентпродлениеBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.clientBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.clientTableAdapter = new Охрана_квартир.УП_ПМ_01_Неверов_ДСDataSetTableAdapters.ClientTableAdapter();
            this.адрес_договорTableAdapter = new Охрана_квартир.УП_ПМ_01_Неверов_ДСDataSetTableAdapters.Адрес_договорTableAdapter();
            this.ПолеДатаПродление = new System.Windows.Forms.DateTimePicker();
            this.ПолеДатаНачала = new System.Windows.Forms.DateTimePicker();
            this.ПолеДатаОкончание = new System.Windows.Forms.DateTimePicker();
            ((System.ComponentModel.ISupportInitialize)(this.Выйти)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ТаблицаПродление)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.prolongingBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.уП_ПМ_01_Неверов_ДСDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ТаблицаДоговор)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.адресдоговорBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.клиентпродлениеBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.clientBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // Выйти
            // 
            this.Выйти.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(111)))), ((int)(((byte)(210)))), ((int)(((byte)(221)))));
            this.Выйти.Image = ((System.Drawing.Image)(resources.GetObject("Выйти.Image")));
            this.Выйти.Location = new System.Drawing.Point(273, -1);
            this.Выйти.Name = "Выйти";
            this.Выйти.Size = new System.Drawing.Size(24, 24);
            this.Выйти.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Выйти.TabIndex = 28;
            this.Выйти.TabStop = false;
            this.Выйти.Click += new System.EventHandler(this.Выйти_Click);
            // 
            // ТаблицаПродление
            // 
            this.ТаблицаПродление.AllowUserToAddRows = false;
            this.ТаблицаПродление.AllowUserToDeleteRows = false;
            this.ТаблицаПродление.AutoGenerateColumns = false;
            this.ТаблицаПродление.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ТаблицаПродление.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.prolongingIDDataGridViewTextBoxColumn,
            this.treatyIDDataGridViewTextBoxColumn,
            this.prolongDataGridViewTextBoxColumn,
            this.commentDataGridViewTextBoxColumn});
            this.ТаблицаПродление.DataSource = this.prolongingBindingSource;
            this.ТаблицаПродление.Location = new System.Drawing.Point(324, 26);
            this.ТаблицаПродление.Name = "ТаблицаПродление";
            this.ТаблицаПродление.ReadOnly = true;
            this.ТаблицаПродление.Size = new System.Drawing.Size(447, 150);
            this.ТаблицаПродление.TabIndex = 29;
            this.ТаблицаПродление.Visible = false;
            // 
            // prolongingIDDataGridViewTextBoxColumn
            // 
            this.prolongingIDDataGridViewTextBoxColumn.DataPropertyName = "ProlongingID";
            this.prolongingIDDataGridViewTextBoxColumn.HeaderText = "ProlongingID";
            this.prolongingIDDataGridViewTextBoxColumn.Name = "prolongingIDDataGridViewTextBoxColumn";
            this.prolongingIDDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // treatyIDDataGridViewTextBoxColumn
            // 
            this.treatyIDDataGridViewTextBoxColumn.DataPropertyName = "TreatyID";
            this.treatyIDDataGridViewTextBoxColumn.HeaderText = "TreatyID";
            this.treatyIDDataGridViewTextBoxColumn.Name = "treatyIDDataGridViewTextBoxColumn";
            this.treatyIDDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // prolongDataGridViewTextBoxColumn
            // 
            this.prolongDataGridViewTextBoxColumn.DataPropertyName = "Prolong";
            this.prolongDataGridViewTextBoxColumn.HeaderText = "Prolong";
            this.prolongDataGridViewTextBoxColumn.Name = "prolongDataGridViewTextBoxColumn";
            this.prolongDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // commentDataGridViewTextBoxColumn
            // 
            this.commentDataGridViewTextBoxColumn.DataPropertyName = "Comment";
            this.commentDataGridViewTextBoxColumn.HeaderText = "Comment";
            this.commentDataGridViewTextBoxColumn.Name = "commentDataGridViewTextBoxColumn";
            this.commentDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // prolongingBindingSource
            // 
            this.prolongingBindingSource.DataMember = "Prolonging";
            this.prolongingBindingSource.DataSource = this.уП_ПМ_01_Неверов_ДСDataSet;
            // 
            // уП_ПМ_01_Неверов_ДСDataSet
            // 
            this.уП_ПМ_01_Неверов_ДСDataSet.DataSetName = "УП_ПМ_01_Неверов_ДСDataSet";
            this.уП_ПМ_01_Неверов_ДСDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // ПолеАдрес
            // 
            this.ПолеАдрес.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ПолеАдрес.FormattingEnabled = true;
            this.ПолеАдрес.Location = new System.Drawing.Point(13, 59);
            this.ПолеАдрес.Name = "ПолеАдрес";
            this.ПолеАдрес.Size = new System.Drawing.Size(271, 28);
            this.ПолеАдрес.TabIndex = 30;
            // 
            // ПолеКоммент
            // 
            this.ПолеКоммент.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ПолеКоммент.Location = new System.Drawing.Point(12, 239);
            this.ПолеКоммент.Multiline = true;
            this.ПолеКоммент.Name = "ПолеКоммент";
            this.ПолеКоммент.Size = new System.Drawing.Size(272, 116);
            this.ПолеКоммент.TabIndex = 32;
            // 
            // АдресКвартиры
            // 
            this.АдресКвартиры.AutoSize = true;
            this.АдресКвартиры.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.АдресКвартиры.Location = new System.Drawing.Point(10, 36);
            this.АдресКвартиры.Name = "АдресКвартиры";
            this.АдресКвартиры.Size = new System.Drawing.Size(216, 20);
            this.АдресКвартиры.TabIndex = 33;
            this.АдресКвартиры.Text = "Выберите адрес квартиры:";
            // 
            // ДатаПродления
            // 
            this.ДатаПродления.AutoSize = true;
            this.ДатаПродления.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ДатаПродления.Location = new System.Drawing.Point(12, 153);
            this.ДатаПродления.Name = "ДатаПродления";
            this.ДатаПродления.Size = new System.Drawing.Size(115, 20);
            this.ДатаПродления.TabIndex = 34;
            this.ДатаПродления.Text = "Продлить до:";
            // 
            // ДопУсловия
            // 
            this.ДопУсловия.AutoSize = true;
            this.ДопУсловия.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ДопУсловия.Location = new System.Drawing.Point(12, 216);
            this.ДопУсловия.Name = "ДопУсловия";
            this.ДопУсловия.Size = new System.Drawing.Size(211, 20);
            this.ДопУсловия.TabIndex = 35;
            this.ДопУсловия.Text = "Дополнительные условия:";
            // 
            // Продлить
            // 
            this.Продлить.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Продлить.Location = new System.Drawing.Point(65, 361);
            this.Продлить.Name = "Продлить";
            this.Продлить.Size = new System.Drawing.Size(173, 28);
            this.Продлить.TabIndex = 36;
            this.Продлить.Text = "Продлить договор";
            this.Продлить.UseVisualStyleBackColor = true;
            this.Продлить.Click += new System.EventHandler(this.Продлить_Click);
            // 
            // ДействиеДоговора
            // 
            this.ДействиеДоговора.AutoSize = true;
            this.ДействиеДоговора.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ДействиеДоговора.Location = new System.Drawing.Point(10, 90);
            this.ДействиеДоговора.Name = "ДействиеДоговора";
            this.ДействиеДоговора.Size = new System.Drawing.Size(163, 20);
            this.ДействиеДоговора.TabIndex = 38;
            this.ДействиеДоговора.Text = "Действие договора:";
            // 
            // ТаблицаДоговор
            // 
            this.ТаблицаДоговор.AllowUserToAddRows = false;
            this.ТаблицаДоговор.AllowUserToDeleteRows = false;
            this.ТаблицаДоговор.AutoGenerateColumns = false;
            this.ТаблицаДоговор.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ТаблицаДоговор.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.registrDataGridViewTextBoxColumn,
            this.addressFlatDataGridViewTextBoxColumn,
            this.treatyIDDataGridViewTextBoxColumn1,
            this.dateStartDataGridViewTextBoxColumn,
            this.stopDateDataGridViewTextBoxColumn});
            this.ТаблицаДоговор.DataSource = this.адресдоговорBindingSource;
            this.ТаблицаДоговор.Location = new System.Drawing.Point(301, 205);
            this.ТаблицаДоговор.Name = "ТаблицаДоговор";
            this.ТаблицаДоговор.ReadOnly = true;
            this.ТаблицаДоговор.Size = new System.Drawing.Size(493, 150);
            this.ТаблицаДоговор.TabIndex = 41;
            this.ТаблицаДоговор.Visible = false;
            // 
            // registrDataGridViewTextBoxColumn
            // 
            this.registrDataGridViewTextBoxColumn.DataPropertyName = "Registr";
            this.registrDataGridViewTextBoxColumn.HeaderText = "Registr";
            this.registrDataGridViewTextBoxColumn.Name = "registrDataGridViewTextBoxColumn";
            this.registrDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // addressFlatDataGridViewTextBoxColumn
            // 
            this.addressFlatDataGridViewTextBoxColumn.DataPropertyName = "AddressFlat";
            this.addressFlatDataGridViewTextBoxColumn.HeaderText = "AddressFlat";
            this.addressFlatDataGridViewTextBoxColumn.Name = "addressFlatDataGridViewTextBoxColumn";
            this.addressFlatDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // treatyIDDataGridViewTextBoxColumn1
            // 
            this.treatyIDDataGridViewTextBoxColumn1.DataPropertyName = "TreatyID";
            this.treatyIDDataGridViewTextBoxColumn1.HeaderText = "TreatyID";
            this.treatyIDDataGridViewTextBoxColumn1.Name = "treatyIDDataGridViewTextBoxColumn1";
            this.treatyIDDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dateStartDataGridViewTextBoxColumn
            // 
            this.dateStartDataGridViewTextBoxColumn.DataPropertyName = "DateStart";
            this.dateStartDataGridViewTextBoxColumn.HeaderText = "DateStart";
            this.dateStartDataGridViewTextBoxColumn.Name = "dateStartDataGridViewTextBoxColumn";
            this.dateStartDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // stopDateDataGridViewTextBoxColumn
            // 
            this.stopDateDataGridViewTextBoxColumn.DataPropertyName = "StopDate";
            this.stopDateDataGridViewTextBoxColumn.HeaderText = "StopDate";
            this.stopDateDataGridViewTextBoxColumn.Name = "stopDateDataGridViewTextBoxColumn";
            this.stopDateDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // адресдоговорBindingSource
            // 
            this.адресдоговорBindingSource.DataMember = "Адрес-договор";
            this.адресдоговорBindingSource.DataSource = this.уП_ПМ_01_Неверов_ДСDataSet;
            // 
            // ДатаНачала
            // 
            this.ДатаНачала.AutoSize = true;
            this.ДатаНачала.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ДатаНачала.Location = new System.Drawing.Point(14, 116);
            this.ДатаНачала.Name = "ДатаНачала";
            this.ДатаНачала.Size = new System.Drawing.Size(17, 20);
            this.ДатаНачала.TabIndex = 42;
            this.ДатаНачала.Text = "с";
            // 
            // ДатаОкончания
            // 
            this.ДатаОкончания.AutoSize = true;
            this.ДатаОкончания.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ДатаОкончания.Location = new System.Drawing.Point(147, 116);
            this.ДатаОкончания.Name = "ДатаОкончания";
            this.ДатаОкончания.Size = new System.Drawing.Size(29, 20);
            this.ДатаОкончания.TabIndex = 43;
            this.ДатаОкончания.Text = "до";
            // 
            // prolongingTableAdapter
            // 
            this.prolongingTableAdapter.ClearBeforeFill = true;
            // 
            // клиентпродлениеBindingSource
            // 
            this.клиентпродлениеBindingSource.DataSource = this.уП_ПМ_01_Неверов_ДСDataSet;
            this.клиентпродлениеBindingSource.Position = 0;
            // 
            // clientBindingSource
            // 
            this.clientBindingSource.DataMember = "Client";
            this.clientBindingSource.DataSource = this.уП_ПМ_01_Неверов_ДСDataSet;
            // 
            // clientTableAdapter
            // 
            this.clientTableAdapter.ClearBeforeFill = true;
            // 
            // адрес_договорTableAdapter
            // 
            this.адрес_договорTableAdapter.ClearBeforeFill = true;
            // 
            // ПолеДатаПродление
            // 
            this.ПолеДатаПродление.Font = new System.Drawing.Font("Arial", 12F);
            this.ПолеДатаПродление.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.ПолеДатаПродление.Location = new System.Drawing.Point(14, 176);
            this.ПолеДатаПродление.Name = "ПолеДатаПродление";
            this.ПолеДатаПродление.Size = new System.Drawing.Size(125, 26);
            this.ПолеДатаПродление.TabIndex = 44;
            // 
            // ПолеДатаНачала
            // 
            this.ПолеДатаНачала.Enabled = false;
            this.ПолеДатаНачала.Font = new System.Drawing.Font("Arial", 12F);
            this.ПолеДатаНачала.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.ПолеДатаНачала.Location = new System.Drawing.Point(37, 116);
            this.ПолеДатаНачала.Name = "ПолеДатаНачала";
            this.ПолеДатаНачала.Size = new System.Drawing.Size(102, 26);
            this.ПолеДатаНачала.TabIndex = 45;
            this.ПолеДатаНачала.TabStop = false;
            // 
            // ПолеДатаОкончание
            // 
            this.ПолеДатаОкончание.Enabled = false;
            this.ПолеДатаОкончание.Font = new System.Drawing.Font("Arial", 12F);
            this.ПолеДатаОкончание.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.ПолеДатаОкончание.Location = new System.Drawing.Point(182, 116);
            this.ПолеДатаОкончание.Name = "ПолеДатаОкончание";
            this.ПолеДатаОкончание.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ПолеДатаОкончание.Size = new System.Drawing.Size(102, 26);
            this.ПолеДатаОкончание.TabIndex = 46;
            this.ПолеДатаОкончание.TabStop = false;
            // 
            // Продление
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(111)))), ((int)(((byte)(210)))), ((int)(((byte)(221)))));
            this.ClientSize = new System.Drawing.Size(299, 400);
            this.Controls.Add(this.ПолеДатаОкончание);
            this.Controls.Add(this.ПолеДатаНачала);
            this.Controls.Add(this.ПолеДатаПродление);
            this.Controls.Add(this.ДатаОкончания);
            this.Controls.Add(this.ДатаНачала);
            this.Controls.Add(this.ТаблицаДоговор);
            this.Controls.Add(this.ДействиеДоговора);
            this.Controls.Add(this.Продлить);
            this.Controls.Add(this.ДопУсловия);
            this.Controls.Add(this.ДатаПродления);
            this.Controls.Add(this.АдресКвартиры);
            this.Controls.Add(this.ПолеКоммент);
            this.Controls.Add(this.ПолеАдрес);
            this.Controls.Add(this.ТаблицаПродление);
            this.Controls.Add(this.Выйти);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Продление";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Продление_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Продление_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Продление_MouseMove);
            ((System.ComponentModel.ISupportInitialize)(this.Выйти)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ТаблицаПродление)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.prolongingBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.уП_ПМ_01_Неверов_ДСDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ТаблицаДоговор)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.адресдоговорBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.клиентпродлениеBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.clientBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox Выйти;
        private System.Windows.Forms.DataGridView ТаблицаПродление;
        private УП_ПМ_01_Неверов_ДСDataSet уП_ПМ_01_Неверов_ДСDataSet;
        private System.Windows.Forms.BindingSource prolongingBindingSource;
        private УП_ПМ_01_Неверов_ДСDataSetTableAdapters.ProlongingTableAdapter prolongingTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn prolongingIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn treatyIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn prolongDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn commentDataGridViewTextBoxColumn;
        private System.Windows.Forms.ComboBox ПолеАдрес;
        private System.Windows.Forms.TextBox ПолеКоммент;
        private System.Windows.Forms.Label АдресКвартиры;
        private System.Windows.Forms.Label ДатаПродления;
        private System.Windows.Forms.Label ДопУсловия;
        private System.Windows.Forms.Button Продлить;
        private System.Windows.Forms.Label ДействиеДоговора;
        private System.Windows.Forms.DataGridView ТаблицаДоговор;
        private System.Windows.Forms.Label ДатаНачала;
        private System.Windows.Forms.Label ДатаОкончания;
        private System.Windows.Forms.BindingSource клиентпродлениеBindingSource;
        private System.Windows.Forms.BindingSource clientBindingSource;
        private УП_ПМ_01_Неверов_ДСDataSetTableAdapters.ClientTableAdapter clientTableAdapter;
        private System.Windows.Forms.BindingSource адресдоговорBindingSource;
        private УП_ПМ_01_Неверов_ДСDataSetTableAdapters.Адрес_договорTableAdapter адрес_договорTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn registrDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn addressFlatDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn treatyIDDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dateStartDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn stopDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DateTimePicker ПолеДатаПродление;
        private System.Windows.Forms.DateTimePicker ПолеДатаНачала;
        private System.Windows.Forms.DateTimePicker ПолеДатаОкончание;
    }
}