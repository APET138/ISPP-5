﻿namespace Охрана_квартир
{
    partial class Регистрация_квартир
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Регистрация_квартир));
            this.Дом = new System.Windows.Forms.GroupBox();
            this.ПолеТипДома = new System.Windows.Forms.ComboBox();
            this.ТаблицаКвартира = new System.Windows.Forms.DataGridView();
            this.flatIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.addressFlatDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.floorDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.typeDoorDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.balconyDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.typeBalconyDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.flatPlanDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.flatBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.уП_ПМ_01_Неверов_ДСDataSet = new Охрана_квартир.УП_ПМ_01_Неверов_ДСDataSet();
            this.ТаблицаSettlement = new System.Windows.Forms.DataGridView();
            this.settlementIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.flatIDDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.registrDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.settlementBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.КодовыйЗамок = new System.Windows.Forms.CheckBox();
            this.ТипДома = new System.Windows.Forms.Label();
            this.ПолеЭтажейВДоме = new System.Windows.Forms.TextBox();
            this.ЭтажейВДоме = new System.Windows.Forms.Label();
            this.Квартира = new System.Windows.Forms.GroupBox();
            this.Надпись2 = new System.Windows.Forms.Label();
            this.ПолеТипКвартирнойДвери = new System.Windows.Forms.ComboBox();
            this.ПолеТипБалкона = new System.Windows.Forms.ComboBox();
            this.ПланКвартиры = new System.Windows.Forms.Label();
            this.ПолеПланКвартиры = new System.Windows.Forms.PictureBox();
            this.ТипБалкона = new System.Windows.Forms.Label();
            this.ТипДвери = new System.Windows.Forms.Label();
            this.НаличиеБалкона = new System.Windows.Forms.CheckBox();
            this.ЭтажКвартиры = new System.Windows.Forms.Label();
            this.ПолеАдресКвартиры = new System.Windows.Forms.TextBox();
            this.ПолеЭтажКвартиры = new System.Windows.Forms.TextBox();
            this.АдресКвартиры = new System.Windows.Forms.Label();
            this.Далее = new System.Windows.Forms.Button();
            this.Назад = new System.Windows.Forms.Button();
            this.ВставкаКартинки = new System.Windows.Forms.OpenFileDialog();
            this.Выйти = new System.Windows.Forms.PictureBox();
            this.Надпись1 = new System.Windows.Forms.Label();
            this.Договор = new System.Windows.Forms.GroupBox();
            this.ТаблицаДом = new System.Windows.Forms.DataGridView();
            this.houseIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.floorsDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.keyDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.typeHouseDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.houseBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.ПолеПлата = new System.Windows.Forms.TextBox();
            this.Плата = new System.Windows.Forms.Label();
            this.ДатаНачало = new System.Windows.Forms.Label();
            this.ДатаОкончания = new System.Windows.Forms.Label();
            this.flatTableAdapter = new Охрана_квартир.УП_ПМ_01_Неверов_ДСDataSetTableAdapters.FlatTableAdapter();
            this.houseTableAdapter = new Охрана_квартир.УП_ПМ_01_Неверов_ДСDataSetTableAdapters.HouseTableAdapter();
            this.settlementTableAdapter = new Охрана_квартир.УП_ПМ_01_Неверов_ДСDataSetTableAdapters.SettlementTableAdapter();
            this.ТаблицаДоговор = new System.Windows.Forms.DataGridView();
            this.treatyIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.settlementIDDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dateStartDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.stopDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.costDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.contractBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.contractTableAdapter = new Охрана_квартир.УП_ПМ_01_Неверов_ДСDataSetTableAdapters.ContractTableAdapter();
            this.ТаблицаFlatHouse = new System.Windows.Forms.DataGridView();
            this.flatHouseIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.flatIDDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.houseIDDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.flatHouseBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.flat_HouseTableAdapter = new Охрана_квартир.УП_ПМ_01_Неверов_ДСDataSetTableAdapters.Flat_HouseTableAdapter();
            this.ПолеДатаНачала = new System.Windows.Forms.DateTimePicker();
            this.ПолеДатаОкончание = new System.Windows.Forms.DateTimePicker();
            this.Дом.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ТаблицаКвартира)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.flatBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.уП_ПМ_01_Неверов_ДСDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ТаблицаSettlement)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.settlementBindingSource)).BeginInit();
            this.Квартира.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ПолеПланКвартиры)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Выйти)).BeginInit();
            this.Договор.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ТаблицаДом)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.houseBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ТаблицаДоговор)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.contractBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ТаблицаFlatHouse)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.flatHouseBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // Дом
            // 
            this.Дом.Controls.Add(this.ПолеТипДома);
            this.Дом.Controls.Add(this.ТаблицаКвартира);
            this.Дом.Controls.Add(this.ТаблицаSettlement);
            this.Дом.Controls.Add(this.КодовыйЗамок);
            this.Дом.Controls.Add(this.ТипДома);
            this.Дом.Controls.Add(this.ПолеЭтажейВДоме);
            this.Дом.Controls.Add(this.ЭтажейВДоме);
            this.Дом.Location = new System.Drawing.Point(344, 62);
            this.Дом.Name = "Дом";
            this.Дом.Size = new System.Drawing.Size(310, 300);
            this.Дом.TabIndex = 24;
            this.Дом.TabStop = false;
            // 
            // ПолеТипДома
            // 
            this.ПолеТипДома.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ПолеТипДома.FormattingEnabled = true;
            this.ПолеТипДома.Items.AddRange(new object[] {
            "Кирпичный",
            "Панельный"});
            this.ПолеТипДома.Location = new System.Drawing.Point(87, 19);
            this.ПолеТипДома.Name = "ПолеТипДома";
            this.ПолеТипДома.Size = new System.Drawing.Size(211, 26);
            this.ПолеТипДома.TabIndex = 27;
            // 
            // ТаблицаКвартира
            // 
            this.ТаблицаКвартира.AllowUserToAddRows = false;
            this.ТаблицаКвартира.AllowUserToDeleteRows = false;
            this.ТаблицаКвартира.AutoGenerateColumns = false;
            this.ТаблицаКвартира.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ТаблицаКвартира.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.flatIDDataGridViewTextBoxColumn,
            this.addressFlatDataGridViewTextBoxColumn,
            this.floorDataGridViewTextBoxColumn,
            this.typeDoorDataGridViewTextBoxColumn,
            this.balconyDataGridViewCheckBoxColumn,
            this.typeBalconyDataGridViewTextBoxColumn,
            this.flatPlanDataGridViewTextBoxColumn});
            this.ТаблицаКвартира.DataSource = this.flatBindingSource;
            this.ТаблицаКвартира.Location = new System.Drawing.Point(10, 167);
            this.ТаблицаКвартира.Name = "ТаблицаКвартира";
            this.ТаблицаКвартира.ReadOnly = true;
            this.ТаблицаКвартира.RowHeadersWidth = 51;
            this.ТаблицаКвартира.Size = new System.Drawing.Size(101, 74);
            this.ТаблицаКвартира.TabIndex = 32;
            this.ТаблицаКвартира.Visible = false;
            // 
            // flatIDDataGridViewTextBoxColumn
            // 
            this.flatIDDataGridViewTextBoxColumn.DataPropertyName = "FlatID";
            this.flatIDDataGridViewTextBoxColumn.HeaderText = "FlatID";
            this.flatIDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.flatIDDataGridViewTextBoxColumn.Name = "flatIDDataGridViewTextBoxColumn";
            this.flatIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.flatIDDataGridViewTextBoxColumn.Width = 125;
            // 
            // addressFlatDataGridViewTextBoxColumn
            // 
            this.addressFlatDataGridViewTextBoxColumn.DataPropertyName = "AddressFlat";
            this.addressFlatDataGridViewTextBoxColumn.HeaderText = "AddressFlat";
            this.addressFlatDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.addressFlatDataGridViewTextBoxColumn.Name = "addressFlatDataGridViewTextBoxColumn";
            this.addressFlatDataGridViewTextBoxColumn.ReadOnly = true;
            this.addressFlatDataGridViewTextBoxColumn.Width = 125;
            // 
            // floorDataGridViewTextBoxColumn
            // 
            this.floorDataGridViewTextBoxColumn.DataPropertyName = "Floor";
            this.floorDataGridViewTextBoxColumn.HeaderText = "Floor";
            this.floorDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.floorDataGridViewTextBoxColumn.Name = "floorDataGridViewTextBoxColumn";
            this.floorDataGridViewTextBoxColumn.ReadOnly = true;
            this.floorDataGridViewTextBoxColumn.Width = 125;
            // 
            // typeDoorDataGridViewTextBoxColumn
            // 
            this.typeDoorDataGridViewTextBoxColumn.DataPropertyName = "TypeDoor";
            this.typeDoorDataGridViewTextBoxColumn.HeaderText = "TypeDoor";
            this.typeDoorDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.typeDoorDataGridViewTextBoxColumn.Name = "typeDoorDataGridViewTextBoxColumn";
            this.typeDoorDataGridViewTextBoxColumn.ReadOnly = true;
            this.typeDoorDataGridViewTextBoxColumn.Width = 125;
            // 
            // balconyDataGridViewCheckBoxColumn
            // 
            this.balconyDataGridViewCheckBoxColumn.DataPropertyName = "Balcony";
            this.balconyDataGridViewCheckBoxColumn.HeaderText = "Balcony";
            this.balconyDataGridViewCheckBoxColumn.MinimumWidth = 6;
            this.balconyDataGridViewCheckBoxColumn.Name = "balconyDataGridViewCheckBoxColumn";
            this.balconyDataGridViewCheckBoxColumn.ReadOnly = true;
            this.balconyDataGridViewCheckBoxColumn.Width = 125;
            // 
            // typeBalconyDataGridViewTextBoxColumn
            // 
            this.typeBalconyDataGridViewTextBoxColumn.DataPropertyName = "TypeBalcony";
            this.typeBalconyDataGridViewTextBoxColumn.HeaderText = "TypeBalcony";
            this.typeBalconyDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.typeBalconyDataGridViewTextBoxColumn.Name = "typeBalconyDataGridViewTextBoxColumn";
            this.typeBalconyDataGridViewTextBoxColumn.ReadOnly = true;
            this.typeBalconyDataGridViewTextBoxColumn.Width = 125;
            // 
            // flatPlanDataGridViewTextBoxColumn
            // 
            this.flatPlanDataGridViewTextBoxColumn.DataPropertyName = "FlatPlan";
            this.flatPlanDataGridViewTextBoxColumn.HeaderText = "FlatPlan";
            this.flatPlanDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.flatPlanDataGridViewTextBoxColumn.Name = "flatPlanDataGridViewTextBoxColumn";
            this.flatPlanDataGridViewTextBoxColumn.ReadOnly = true;
            this.flatPlanDataGridViewTextBoxColumn.Width = 125;
            // 
            // flatBindingSource
            // 
            this.flatBindingSource.DataMember = "Flat";
            this.flatBindingSource.DataSource = this.уП_ПМ_01_Неверов_ДСDataSet;
            // 
            // уП_ПМ_01_Неверов_ДСDataSet
            // 
            this.уП_ПМ_01_Неверов_ДСDataSet.DataSetName = "УП_ПМ_01_Неверов_ДСDataSet";
            this.уП_ПМ_01_Неверов_ДСDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // ТаблицаSettlement
            // 
            this.ТаблицаSettlement.AllowUserToAddRows = false;
            this.ТаблицаSettlement.AllowUserToDeleteRows = false;
            this.ТаблицаSettlement.AutoGenerateColumns = false;
            this.ТаблицаSettlement.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ТаблицаSettlement.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.settlementIDDataGridViewTextBoxColumn,
            this.flatIDDataGridViewTextBoxColumn2,
            this.registrDataGridViewTextBoxColumn});
            this.ТаблицаSettlement.DataSource = this.settlementBindingSource;
            this.ТаблицаSettlement.Location = new System.Drawing.Point(117, 162);
            this.ТаблицаSettlement.Name = "ТаблицаSettlement";
            this.ТаблицаSettlement.ReadOnly = true;
            this.ТаблицаSettlement.RowHeadersWidth = 51;
            this.ТаблицаSettlement.Size = new System.Drawing.Size(147, 62);
            this.ТаблицаSettlement.TabIndex = 33;
            this.ТаблицаSettlement.Visible = false;
            // 
            // settlementIDDataGridViewTextBoxColumn
            // 
            this.settlementIDDataGridViewTextBoxColumn.DataPropertyName = "SettlementID";
            this.settlementIDDataGridViewTextBoxColumn.HeaderText = "SettlementID";
            this.settlementIDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.settlementIDDataGridViewTextBoxColumn.Name = "settlementIDDataGridViewTextBoxColumn";
            this.settlementIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.settlementIDDataGridViewTextBoxColumn.Width = 125;
            // 
            // flatIDDataGridViewTextBoxColumn2
            // 
            this.flatIDDataGridViewTextBoxColumn2.DataPropertyName = "FlatID";
            this.flatIDDataGridViewTextBoxColumn2.HeaderText = "FlatID";
            this.flatIDDataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.flatIDDataGridViewTextBoxColumn2.Name = "flatIDDataGridViewTextBoxColumn2";
            this.flatIDDataGridViewTextBoxColumn2.ReadOnly = true;
            this.flatIDDataGridViewTextBoxColumn2.Width = 125;
            // 
            // registrDataGridViewTextBoxColumn
            // 
            this.registrDataGridViewTextBoxColumn.DataPropertyName = "Registr";
            this.registrDataGridViewTextBoxColumn.HeaderText = "Registr";
            this.registrDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.registrDataGridViewTextBoxColumn.Name = "registrDataGridViewTextBoxColumn";
            this.registrDataGridViewTextBoxColumn.ReadOnly = true;
            this.registrDataGridViewTextBoxColumn.Width = 125;
            // 
            // settlementBindingSource
            // 
            this.settlementBindingSource.DataMember = "Settlement";
            this.settlementBindingSource.DataSource = this.уП_ПМ_01_Неверов_ДСDataSet;
            // 
            // КодовыйЗамок
            // 
            this.КодовыйЗамок.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.КодовыйЗамок.Location = new System.Drawing.Point(4, 70);
            this.КодовыйЗамок.Name = "КодовыйЗамок";
            this.КодовыйЗамок.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.КодовыйЗамок.Size = new System.Drawing.Size(214, 44);
            this.КодовыйЗамок.TabIndex = 18;
            this.КодовыйЗамок.Text = "Наличие кодового замка на подъезде";
            this.КодовыйЗамок.UseVisualStyleBackColor = true;
            this.КодовыйЗамок.CheckedChanged += new System.EventHandler(this.КодовыйЗамок_CheckedChanged);
            // 
            // ТипДома
            // 
            this.ТипДома.AutoSize = true;
            this.ТипДома.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ТипДома.Location = new System.Drawing.Point(7, 21);
            this.ТипДома.Name = "ТипДома";
            this.ТипДома.Size = new System.Drawing.Size(78, 18);
            this.ТипДома.TabIndex = 14;
            this.ТипДома.Text = "Тип дома:";
            // 
            // ПолеЭтажейВДоме
            // 
            this.ПолеЭтажейВДоме.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ПолеЭтажейВДоме.Location = new System.Drawing.Point(136, 132);
            this.ПолеЭтажейВДоме.MaxLength = 2;
            this.ПолеЭтажейВДоме.Name = "ПолеЭтажейВДоме";
            this.ПолеЭтажейВДоме.Size = new System.Drawing.Size(55, 26);
            this.ПолеЭтажейВДоме.TabIndex = 11;
            this.ПолеЭтажейВДоме.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ПолеЭтажейВДоме_KeyPress);
            // 
            // ЭтажейВДоме
            // 
            this.ЭтажейВДоме.AutoSize = true;
            this.ЭтажейВДоме.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ЭтажейВДоме.Location = new System.Drawing.Point(7, 134);
            this.ЭтажейВДоме.Name = "ЭтажейВДоме";
            this.ЭтажейВДоме.Size = new System.Drawing.Size(122, 18);
            this.ЭтажейВДоме.TabIndex = 10;
            this.ЭтажейВДоме.Text = "Этажей в доме:";
            // 
            // Квартира
            // 
            this.Квартира.Controls.Add(this.Надпись2);
            this.Квартира.Controls.Add(this.ПолеТипКвартирнойДвери);
            this.Квартира.Controls.Add(this.ПолеТипБалкона);
            this.Квартира.Controls.Add(this.ПланКвартиры);
            this.Квартира.Controls.Add(this.ПолеПланКвартиры);
            this.Квартира.Controls.Add(this.ТипБалкона);
            this.Квартира.Controls.Add(this.ТипДвери);
            this.Квартира.Controls.Add(this.НаличиеБалкона);
            this.Квартира.Controls.Add(this.ЭтажКвартиры);
            this.Квартира.Controls.Add(this.ПолеАдресКвартиры);
            this.Квартира.Controls.Add(this.ПолеЭтажКвартиры);
            this.Квартира.Controls.Add(this.АдресКвартиры);
            this.Квартира.Location = new System.Drawing.Point(12, 62);
            this.Квартира.Name = "Квартира";
            this.Квартира.Size = new System.Drawing.Size(310, 300);
            this.Квартира.TabIndex = 27;
            this.Квартира.TabStop = false;
            // 
            // Надпись2
            // 
            this.Надпись2.AutoSize = true;
            this.Надпись2.Location = new System.Drawing.Point(149, 167);
            this.Надпись2.Name = "Надпись2";
            this.Надпись2.Size = new System.Drawing.Size(0, 13);
            this.Надпись2.TabIndex = 28;
            this.Надпись2.Visible = false;
            // 
            // ПолеТипКвартирнойДвери
            // 
            this.ПолеТипКвартирнойДвери.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ПолеТипКвартирнойДвери.FormattingEnabled = true;
            this.ПолеТипКвартирнойДвери.Items.AddRange(new object[] {
            "Металическая",
            "Деревянная",
            "Две двери"});
            this.ПолеТипКвартирнойДвери.Location = new System.Drawing.Point(80, 83);
            this.ПолеТипКвартирнойДвери.Name = "ПолеТипКвартирнойДвери";
            this.ПолеТипКвартирнойДвери.Size = new System.Drawing.Size(223, 26);
            this.ПолеТипКвартирнойДвери.TabIndex = 24;
            // 
            // ПолеТипБалкона
            // 
            this.ПолеТипБалкона.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ПолеТипБалкона.FormattingEnabled = true;
            this.ПолеТипБалкона.Items.AddRange(new object[] {
            "Отдельный",
            "Совмещенный"});
            this.ПолеТипБалкона.Location = new System.Drawing.Point(190, 132);
            this.ПолеТипБалкона.Name = "ПолеТипБалкона";
            this.ПолеТипБалкона.Size = new System.Drawing.Size(113, 26);
            this.ПолеТипБалкона.TabIndex = 23;
            // 
            // ПланКвартиры
            // 
            this.ПланКвартиры.AutoSize = true;
            this.ПланКвартиры.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ПланКвартиры.Location = new System.Drawing.Point(9, 162);
            this.ПланКвартиры.Name = "ПланКвартиры";
            this.ПланКвартиры.Size = new System.Drawing.Size(122, 18);
            this.ПланКвартиры.TabIndex = 22;
            this.ПланКвартиры.Text = "План квартиры:";
            // 
            // ПолеПланКвартиры
            // 
            this.ПолеПланКвартиры.BackColor = System.Drawing.SystemColors.Window;
            this.ПолеПланКвартиры.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ПолеПланКвартиры.Image = ((System.Drawing.Image)(resources.GetObject("ПолеПланКвартиры.Image")));
            this.ПолеПланКвартиры.Location = new System.Drawing.Point(6, 182);
            this.ПолеПланКвартиры.Name = "ПолеПланКвартиры";
            this.ПолеПланКвартиры.Size = new System.Drawing.Size(297, 110);
            this.ПолеПланКвартиры.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ПолеПланКвартиры.TabIndex = 21;
            this.ПолеПланКвартиры.TabStop = false;
            this.ПолеПланКвартиры.Click += new System.EventHandler(this.ПолеПланКвартиры_Click);
            // 
            // ТипБалкона
            // 
            this.ТипБалкона.AutoSize = true;
            this.ТипБалкона.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ТипБалкона.Location = new System.Drawing.Point(193, 111);
            this.ТипБалкона.Name = "ТипБалкона";
            this.ТипБалкона.Size = new System.Drawing.Size(99, 18);
            this.ТипБалкона.TabIndex = 19;
            this.ТипБалкона.Text = "Тип балкона:";
            // 
            // ТипДвери
            // 
            this.ТипДвери.AutoSize = true;
            this.ТипДвери.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ТипДвери.Location = new System.Drawing.Point(83, 63);
            this.ТипДвери.Name = "ТипДвери";
            this.ТипДвери.Size = new System.Drawing.Size(171, 18);
            this.ТипДвери.TabIndex = 14;
            this.ТипДвери.Text = "Тип квартирной двери:";
            // 
            // НаличиеБалкона
            // 
            this.НаличиеБалкона.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.НаличиеБалкона.Location = new System.Drawing.Point(6, 110);
            this.НаличиеБалкона.Name = "НаличиеБалкона";
            this.НаличиеБалкона.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.НаличиеБалкона.Size = new System.Drawing.Size(178, 48);
            this.НаличиеБалкона.TabIndex = 18;
            this.НаличиеБалкона.Text = "Наличие балкона";
            this.НаличиеБалкона.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.НаличиеБалкона.UseVisualStyleBackColor = true;
            this.НаличиеБалкона.CheckedChanged += new System.EventHandler(this.НаличиеБалкона_CheckedChanged);
            // 
            // ЭтажКвартиры
            // 
            this.ЭтажКвартиры.AutoSize = true;
            this.ЭтажКвартиры.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ЭтажКвартиры.Location = new System.Drawing.Point(9, 62);
            this.ЭтажКвартиры.Name = "ЭтажКвартиры";
            this.ЭтажКвартиры.Size = new System.Drawing.Size(50, 18);
            this.ЭтажКвартиры.TabIndex = 10;
            this.ЭтажКвартиры.Text = "Этаж:";
            // 
            // ПолеАдресКвартиры
            // 
            this.ПолеАдресКвартиры.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ПолеАдресКвартиры.Location = new System.Drawing.Point(6, 32);
            this.ПолеАдресКвартиры.MaxLength = 60;
            this.ПолеАдресКвартиры.Name = "ПолеАдресКвартиры";
            this.ПолеАдресКвартиры.Size = new System.Drawing.Size(297, 26);
            this.ПолеАдресКвартиры.TabIndex = 13;
            this.ПолеАдресКвартиры.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ПолеАдресКвартиры_KeyPress);
            // 
            // ПолеЭтажКвартиры
            // 
            this.ПолеЭтажКвартиры.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ПолеЭтажКвартиры.Location = new System.Drawing.Point(6, 82);
            this.ПолеЭтажКвартиры.MaxLength = 2;
            this.ПолеЭтажКвартиры.Name = "ПолеЭтажКвартиры";
            this.ПолеЭтажКвартиры.Size = new System.Drawing.Size(60, 26);
            this.ПолеЭтажКвартиры.TabIndex = 11;
            this.ПолеЭтажКвартиры.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ПолеЭтажКвартиры_KeyPress);
            // 
            // АдресКвартиры
            // 
            this.АдресКвартиры.AutoSize = true;
            this.АдресКвартиры.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.АдресКвартиры.Location = new System.Drawing.Point(9, 12);
            this.АдресКвартиры.Name = "АдресКвартиры";
            this.АдресКвартиры.Size = new System.Drawing.Size(132, 18);
            this.АдресКвартиры.TabIndex = 12;
            this.АдресКвартиры.Text = "Адрес квартиры:";
            // 
            // Далее
            // 
            this.Далее.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Далее.Location = new System.Drawing.Point(202, 368);
            this.Далее.Name = "Далее";
            this.Далее.Size = new System.Drawing.Size(120, 37);
            this.Далее.TabIndex = 28;
            this.Далее.Text = "Далее";
            this.Далее.UseVisualStyleBackColor = true;
            this.Далее.Click += new System.EventHandler(this.Далее_Click);
            // 
            // Назад
            // 
            this.Назад.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Назад.Location = new System.Drawing.Point(12, 368);
            this.Назад.Name = "Назад";
            this.Назад.Size = new System.Drawing.Size(120, 37);
            this.Назад.TabIndex = 29;
            this.Назад.Text = "Назад";
            this.Назад.UseVisualStyleBackColor = true;
            this.Назад.Click += new System.EventHandler(this.Назад_Click);
            // 
            // ВставкаКартинки
            // 
            this.ВставкаКартинки.FileName = "openFileDialog1";
            // 
            // Выйти
            // 
            this.Выйти.Image = ((System.Drawing.Image)(resources.GetObject("Выйти.Image")));
            this.Выйти.Location = new System.Drawing.Point(310, 0);
            this.Выйти.Name = "Выйти";
            this.Выйти.Size = new System.Drawing.Size(24, 24);
            this.Выйти.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Выйти.TabIndex = 30;
            this.Выйти.TabStop = false;
            this.Выйти.Click += new System.EventHandler(this.Выйти_Click);
            // 
            // Надпись1
            // 
            this.Надпись1.AutoSize = true;
            this.Надпись1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Надпись1.Location = new System.Drawing.Point(12, 31);
            this.Надпись1.Name = "Надпись1";
            this.Надпись1.Size = new System.Drawing.Size(0, 18);
            this.Надпись1.TabIndex = 31;
            // 
            // Договор
            // 
            this.Договор.Controls.Add(this.ПолеДатаОкончание);
            this.Договор.Controls.Add(this.ПолеДатаНачала);
            this.Договор.Controls.Add(this.ТаблицаДом);
            this.Договор.Controls.Add(this.ПолеПлата);
            this.Договор.Controls.Add(this.Плата);
            this.Договор.Controls.Add(this.ДатаНачало);
            this.Договор.Controls.Add(this.ДатаОкончания);
            this.Договор.Location = new System.Drawing.Point(684, 62);
            this.Договор.Name = "Договор";
            this.Договор.Size = new System.Drawing.Size(310, 300);
            this.Договор.TabIndex = 29;
            this.Договор.TabStop = false;
            // 
            // ТаблицаДом
            // 
            this.ТаблицаДом.AllowUserToAddRows = false;
            this.ТаблицаДом.AllowUserToDeleteRows = false;
            this.ТаблицаДом.AutoGenerateColumns = false;
            this.ТаблицаДом.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ТаблицаДом.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.houseIDDataGridViewTextBoxColumn,
            this.floorsDataGridViewTextBoxColumn,
            this.keyDataGridViewCheckBoxColumn,
            this.typeHouseDataGridViewTextBoxColumn});
            this.ТаблицаДом.DataSource = this.houseBindingSource;
            this.ТаблицаДом.Location = new System.Drawing.Point(6, 184);
            this.ТаблицаДом.Name = "ТаблицаДом";
            this.ТаблицаДом.ReadOnly = true;
            this.ТаблицаДом.RowHeadersWidth = 51;
            this.ТаблицаДом.Size = new System.Drawing.Size(240, 150);
            this.ТаблицаДом.TabIndex = 33;
            this.ТаблицаДом.Visible = false;
            // 
            // houseIDDataGridViewTextBoxColumn
            // 
            this.houseIDDataGridViewTextBoxColumn.DataPropertyName = "HouseID";
            this.houseIDDataGridViewTextBoxColumn.HeaderText = "HouseID";
            this.houseIDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.houseIDDataGridViewTextBoxColumn.Name = "houseIDDataGridViewTextBoxColumn";
            this.houseIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.houseIDDataGridViewTextBoxColumn.Width = 125;
            // 
            // floorsDataGridViewTextBoxColumn
            // 
            this.floorsDataGridViewTextBoxColumn.DataPropertyName = "Floors";
            this.floorsDataGridViewTextBoxColumn.HeaderText = "Floors";
            this.floorsDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.floorsDataGridViewTextBoxColumn.Name = "floorsDataGridViewTextBoxColumn";
            this.floorsDataGridViewTextBoxColumn.ReadOnly = true;
            this.floorsDataGridViewTextBoxColumn.Width = 125;
            // 
            // keyDataGridViewCheckBoxColumn
            // 
            this.keyDataGridViewCheckBoxColumn.DataPropertyName = "Key";
            this.keyDataGridViewCheckBoxColumn.HeaderText = "Key";
            this.keyDataGridViewCheckBoxColumn.MinimumWidth = 6;
            this.keyDataGridViewCheckBoxColumn.Name = "keyDataGridViewCheckBoxColumn";
            this.keyDataGridViewCheckBoxColumn.ReadOnly = true;
            this.keyDataGridViewCheckBoxColumn.Width = 125;
            // 
            // typeHouseDataGridViewTextBoxColumn
            // 
            this.typeHouseDataGridViewTextBoxColumn.DataPropertyName = "TypeHouse";
            this.typeHouseDataGridViewTextBoxColumn.HeaderText = "TypeHouse";
            this.typeHouseDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.typeHouseDataGridViewTextBoxColumn.Name = "typeHouseDataGridViewTextBoxColumn";
            this.typeHouseDataGridViewTextBoxColumn.ReadOnly = true;
            this.typeHouseDataGridViewTextBoxColumn.Width = 125;
            // 
            // houseBindingSource
            // 
            this.houseBindingSource.DataMember = "House";
            this.houseBindingSource.DataSource = this.уП_ПМ_01_Неверов_ДСDataSet;
            // 
            // ПолеПлата
            // 
            this.ПолеПлата.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ПолеПлата.Location = new System.Drawing.Point(6, 152);
            this.ПолеПлата.MaxLength = 15;
            this.ПолеПлата.Name = "ПолеПлата";
            this.ПолеПлата.ReadOnly = true;
            this.ПолеПлата.Size = new System.Drawing.Size(131, 26);
            this.ПолеПлата.TabIndex = 28;
            this.ПолеПлата.TabStop = false;
            this.ПолеПлата.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ПолеПлата_KeyPress);
            // 
            // Плата
            // 
            this.Плата.AutoSize = true;
            this.Плата.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Плата.Location = new System.Drawing.Point(6, 131);
            this.Плата.Name = "Плата";
            this.Плата.Size = new System.Drawing.Size(240, 18);
            this.Плата.TabIndex = 25;
            this.Плата.Text = "Стоимость ежемесячная плата:";
            // 
            // ДатаНачало
            // 
            this.ДатаНачало.AutoSize = true;
            this.ДатаНачало.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ДатаНачало.Location = new System.Drawing.Point(6, 12);
            this.ДатаНачало.Name = "ДатаНачало";
            this.ДатаНачало.Size = new System.Drawing.Size(247, 18);
            this.ДатаНачало.TabIndex = 19;
            this.ДатаНачало.Text = "Дата начало действия договора:";
            // 
            // ДатаОкончания
            // 
            this.ДатаОкончания.AutoSize = true;
            this.ДатаОкончания.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ДатаОкончания.Location = new System.Drawing.Point(6, 70);
            this.ДатаОкончания.Name = "ДатаОкончания";
            this.ДатаОкончания.Size = new System.Drawing.Size(271, 18);
            this.ДатаОкончания.TabIndex = 21;
            this.ДатаОкончания.Text = "Дата окончание действия договора:";
            // 
            // flatTableAdapter
            // 
            this.flatTableAdapter.ClearBeforeFill = true;
            // 
            // houseTableAdapter
            // 
            this.houseTableAdapter.ClearBeforeFill = true;
            // 
            // settlementTableAdapter
            // 
            this.settlementTableAdapter.ClearBeforeFill = true;
            // 
            // ТаблицаДоговор
            // 
            this.ТаблицаДоговор.AllowUserToAddRows = false;
            this.ТаблицаДоговор.AllowUserToDeleteRows = false;
            this.ТаблицаДоговор.AutoGenerateColumns = false;
            this.ТаблицаДоговор.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ТаблицаДоговор.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.treatyIDDataGridViewTextBoxColumn,
            this.settlementIDDataGridViewTextBoxColumn1,
            this.dateStartDataGridViewTextBoxColumn,
            this.stopDateDataGridViewTextBoxColumn,
            this.costDataGridViewTextBoxColumn});
            this.ТаблицаДоговор.DataSource = this.contractBindingSource;
            this.ТаблицаДоговор.Location = new System.Drawing.Point(617, 0);
            this.ТаблицаДоговор.Name = "ТаблицаДоговор";
            this.ТаблицаДоговор.ReadOnly = true;
            this.ТаблицаДоговор.RowHeadersWidth = 51;
            this.ТаблицаДоговор.Size = new System.Drawing.Size(240, 61);
            this.ТаблицаДоговор.TabIndex = 34;
            this.ТаблицаДоговор.Visible = false;
            // 
            // treatyIDDataGridViewTextBoxColumn
            // 
            this.treatyIDDataGridViewTextBoxColumn.DataPropertyName = "TreatyID";
            this.treatyIDDataGridViewTextBoxColumn.HeaderText = "TreatyID";
            this.treatyIDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.treatyIDDataGridViewTextBoxColumn.Name = "treatyIDDataGridViewTextBoxColumn";
            this.treatyIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.treatyIDDataGridViewTextBoxColumn.Width = 125;
            // 
            // settlementIDDataGridViewTextBoxColumn1
            // 
            this.settlementIDDataGridViewTextBoxColumn1.DataPropertyName = "SettlementID";
            this.settlementIDDataGridViewTextBoxColumn1.HeaderText = "SettlementID";
            this.settlementIDDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.settlementIDDataGridViewTextBoxColumn1.Name = "settlementIDDataGridViewTextBoxColumn1";
            this.settlementIDDataGridViewTextBoxColumn1.ReadOnly = true;
            this.settlementIDDataGridViewTextBoxColumn1.Width = 125;
            // 
            // dateStartDataGridViewTextBoxColumn
            // 
            this.dateStartDataGridViewTextBoxColumn.DataPropertyName = "DateStart";
            this.dateStartDataGridViewTextBoxColumn.HeaderText = "DateStart";
            this.dateStartDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.dateStartDataGridViewTextBoxColumn.Name = "dateStartDataGridViewTextBoxColumn";
            this.dateStartDataGridViewTextBoxColumn.ReadOnly = true;
            this.dateStartDataGridViewTextBoxColumn.Width = 125;
            // 
            // stopDateDataGridViewTextBoxColumn
            // 
            this.stopDateDataGridViewTextBoxColumn.DataPropertyName = "StopDate";
            this.stopDateDataGridViewTextBoxColumn.HeaderText = "StopDate";
            this.stopDateDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.stopDateDataGridViewTextBoxColumn.Name = "stopDateDataGridViewTextBoxColumn";
            this.stopDateDataGridViewTextBoxColumn.ReadOnly = true;
            this.stopDateDataGridViewTextBoxColumn.Width = 125;
            // 
            // costDataGridViewTextBoxColumn
            // 
            this.costDataGridViewTextBoxColumn.DataPropertyName = "Cost";
            this.costDataGridViewTextBoxColumn.HeaderText = "Cost";
            this.costDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.costDataGridViewTextBoxColumn.Name = "costDataGridViewTextBoxColumn";
            this.costDataGridViewTextBoxColumn.ReadOnly = true;
            this.costDataGridViewTextBoxColumn.Width = 125;
            // 
            // contractBindingSource
            // 
            this.contractBindingSource.DataMember = "Contract";
            this.contractBindingSource.DataSource = this.уП_ПМ_01_Неверов_ДСDataSet;
            // 
            // contractTableAdapter
            // 
            this.contractTableAdapter.ClearBeforeFill = true;
            // 
            // ТаблицаFlatHouse
            // 
            this.ТаблицаFlatHouse.AllowUserToAddRows = false;
            this.ТаблицаFlatHouse.AllowUserToDeleteRows = false;
            this.ТаблицаFlatHouse.AutoGenerateColumns = false;
            this.ТаблицаFlatHouse.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ТаблицаFlatHouse.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.flatHouseIDDataGridViewTextBoxColumn,
            this.flatIDDataGridViewTextBoxColumn1,
            this.houseIDDataGridViewTextBoxColumn1});
            this.ТаблицаFlatHouse.DataSource = this.flatHouseBindingSource;
            this.ТаблицаFlatHouse.Location = new System.Drawing.Point(368, 0);
            this.ТаблицаFlatHouse.Name = "ТаблицаFlatHouse";
            this.ТаблицаFlatHouse.ReadOnly = true;
            this.ТаблицаFlatHouse.RowHeadersWidth = 51;
            this.ТаблицаFlatHouse.Size = new System.Drawing.Size(240, 61);
            this.ТаблицаFlatHouse.TabIndex = 35;
            this.ТаблицаFlatHouse.Visible = false;
            // 
            // flatHouseIDDataGridViewTextBoxColumn
            // 
            this.flatHouseIDDataGridViewTextBoxColumn.DataPropertyName = "Flat-HouseID";
            this.flatHouseIDDataGridViewTextBoxColumn.HeaderText = "Flat-HouseID";
            this.flatHouseIDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.flatHouseIDDataGridViewTextBoxColumn.Name = "flatHouseIDDataGridViewTextBoxColumn";
            this.flatHouseIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.flatHouseIDDataGridViewTextBoxColumn.Width = 125;
            // 
            // flatIDDataGridViewTextBoxColumn1
            // 
            this.flatIDDataGridViewTextBoxColumn1.DataPropertyName = "FlatID";
            this.flatIDDataGridViewTextBoxColumn1.HeaderText = "FlatID";
            this.flatIDDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.flatIDDataGridViewTextBoxColumn1.Name = "flatIDDataGridViewTextBoxColumn1";
            this.flatIDDataGridViewTextBoxColumn1.ReadOnly = true;
            this.flatIDDataGridViewTextBoxColumn1.Width = 125;
            // 
            // houseIDDataGridViewTextBoxColumn1
            // 
            this.houseIDDataGridViewTextBoxColumn1.DataPropertyName = "HouseID";
            this.houseIDDataGridViewTextBoxColumn1.HeaderText = "HouseID";
            this.houseIDDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.houseIDDataGridViewTextBoxColumn1.Name = "houseIDDataGridViewTextBoxColumn1";
            this.houseIDDataGridViewTextBoxColumn1.ReadOnly = true;
            this.houseIDDataGridViewTextBoxColumn1.Width = 125;
            // 
            // flatHouseBindingSource
            // 
            this.flatHouseBindingSource.DataMember = "Flat-House";
            this.flatHouseBindingSource.DataSource = this.уП_ПМ_01_Неверов_ДСDataSet;
            // 
            // flat_HouseTableAdapter
            // 
            this.flat_HouseTableAdapter.ClearBeforeFill = true;
            // 
            // ПолеДатаНачала
            // 
            this.ПолеДатаНачала.Font = new System.Drawing.Font("Arial", 12F);
            this.ПолеДатаНачала.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.ПолеДатаНачала.Location = new System.Drawing.Point(7, 33);
            this.ПолеДатаНачала.Name = "ПолеДатаНачала";
            this.ПолеДатаНачала.Size = new System.Drawing.Size(130, 26);
            this.ПолеДатаНачала.TabIndex = 36;
            // 
            // ПолеДатаОкончание
            // 
            this.ПолеДатаОкончание.Font = new System.Drawing.Font("Arial", 12F);
            this.ПолеДатаОкончание.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.ПолеДатаОкончание.Location = new System.Drawing.Point(7, 91);
            this.ПолеДатаОкончание.Name = "ПолеДатаОкончание";
            this.ПолеДатаОкончание.Size = new System.Drawing.Size(130, 26);
            this.ПолеДатаОкончание.TabIndex = 37;
            // 
            // Регистрация_квартир
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(111)))), ((int)(((byte)(210)))), ((int)(((byte)(221)))));
            this.ClientSize = new System.Drawing.Size(1015, 436);
            this.Controls.Add(this.ТаблицаFlatHouse);
            this.Controls.Add(this.ТаблицаДоговор);
            this.Controls.Add(this.Договор);
            this.Controls.Add(this.Надпись1);
            this.Controls.Add(this.Выйти);
            this.Controls.Add(this.Назад);
            this.Controls.Add(this.Далее);
            this.Controls.Add(this.Квартира);
            this.Controls.Add(this.Дом);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Регистрация_квартир";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Регистрация_квартир";
            this.Load += new System.EventHandler(this.Регистрация_квартир_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Регистрация_квартир_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Регистрация_квартир_MouseMove);
            this.Дом.ResumeLayout(false);
            this.Дом.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ТаблицаКвартира)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.flatBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.уП_ПМ_01_Неверов_ДСDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ТаблицаSettlement)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.settlementBindingSource)).EndInit();
            this.Квартира.ResumeLayout(false);
            this.Квартира.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ПолеПланКвартиры)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Выйти)).EndInit();
            this.Договор.ResumeLayout(false);
            this.Договор.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ТаблицаДом)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.houseBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ТаблицаДоговор)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.contractBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ТаблицаFlatHouse)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.flatHouseBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox Дом;
        private System.Windows.Forms.CheckBox КодовыйЗамок;
        private System.Windows.Forms.Label ТипДома;
        private System.Windows.Forms.TextBox ПолеЭтажейВДоме;
        private System.Windows.Forms.Label ЭтажейВДоме;
        private System.Windows.Forms.GroupBox Квартира;
        private System.Windows.Forms.ComboBox ПолеТипБалкона;
        private System.Windows.Forms.Label ПланКвартиры;
        private System.Windows.Forms.PictureBox ПолеПланКвартиры;
        private System.Windows.Forms.Label ТипБалкона;
        private System.Windows.Forms.CheckBox НаличиеБалкона;
        private System.Windows.Forms.Label ТипДвери;
        private System.Windows.Forms.TextBox ПолеАдресКвартиры;
        private System.Windows.Forms.Label АдресКвартиры;
        private System.Windows.Forms.TextBox ПолеЭтажКвартиры;
        private System.Windows.Forms.Label ЭтажКвартиры;
        private System.Windows.Forms.ComboBox ПолеТипКвартирнойДвери;
        private System.Windows.Forms.Button Далее;
        private System.Windows.Forms.Button Назад;
        private System.Windows.Forms.OpenFileDialog ВставкаКартинки;
        private System.Windows.Forms.ComboBox ПолеТипДома;
        private System.Windows.Forms.PictureBox Выйти;
        private System.Windows.Forms.Label Надпись1;
        private System.Windows.Forms.GroupBox Договор;
        private System.Windows.Forms.TextBox ПолеПлата;
        private System.Windows.Forms.Label Плата;
        private System.Windows.Forms.Label ДатаНачало;
        private System.Windows.Forms.Label ДатаОкончания;
        private System.Windows.Forms.Label Надпись2;
        private System.Windows.Forms.DataGridView ТаблицаКвартира;
        private УП_ПМ_01_Неверов_ДСDataSet уП_ПМ_01_Неверов_ДСDataSet;
        private System.Windows.Forms.BindingSource flatBindingSource;
        private УП_ПМ_01_Неверов_ДСDataSetTableAdapters.FlatTableAdapter flatTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn flatIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn addressFlatDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn floorDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn typeDoorDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn balconyDataGridViewCheckBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn typeBalconyDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn flatPlanDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridView ТаблицаДом;
        private System.Windows.Forms.BindingSource houseBindingSource;
        private УП_ПМ_01_Неверов_ДСDataSetTableAdapters.HouseTableAdapter houseTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn houseIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn floorsDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn keyDataGridViewCheckBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn typeHouseDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridView ТаблицаSettlement;
        private System.Windows.Forms.BindingSource settlementBindingSource;
        private УП_ПМ_01_Неверов_ДСDataSetTableAdapters.SettlementTableAdapter settlementTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn settlementIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn flatIDDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn registrDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridView ТаблицаДоговор;
        private System.Windows.Forms.BindingSource contractBindingSource;
        private УП_ПМ_01_Неверов_ДСDataSetTableAdapters.ContractTableAdapter contractTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn treatyIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn settlementIDDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dateStartDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn stopDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn costDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridView ТаблицаFlatHouse;
        private System.Windows.Forms.BindingSource flatHouseBindingSource;
        private УП_ПМ_01_Неверов_ДСDataSetTableAdapters.Flat_HouseTableAdapter flat_HouseTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn flatHouseIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn flatIDDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn houseIDDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DateTimePicker ПолеДатаНачала;
        private System.Windows.Forms.DateTimePicker ПолеДатаОкончание;
    }
}