﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics.Contracts;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Охрана_квартир
{
    public partial class Продление : Form
    {
        public Продление()
        {
            InitializeComponent();
        }
        Point mouse;
        int index,n;
        string regist;
        private void Продление_MouseMove(object sender, MouseEventArgs e)
        {
            //передвигает форму по тому как движется мышка по экрану
            if (e.Button == MouseButtons.Left)
            {
                Left += e.X - mouse.X;
                Top += e.Y - mouse.Y;
            }
        }
        public void Id(string id)
        {
            //Метод для передачи данных
            regist = id;
        }
        private void Продление_MouseDown(object sender, MouseEventArgs e)
        {
            //отпеделяет точку где была эажата клавиша мыши на форме
            mouse = new Point(e.X, e.Y);
        }

        private void Продление_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet._Адрес_договор". При необходимости она может быть перемещена или удалена.
            this.адрес_договорTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet._Адрес_договор);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet.Client". При необходимости она может быть перемещена или удалена.
            this.clientTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet.Client);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "уП_ПМ_01_Неверов_ДСDataSet.Prolonging". При необходимости она может быть перемещена или удалена.
            this.prolongingTableAdapter.Fill(this.уП_ПМ_01_Неверов_ДСDataSet.Prolonging);
            this.Size = new Size(296, 400) ;
            for (int j = 0; j < ТаблицаДоговор.RowCount; j++)
            {
                if (ТаблицаДоговор.Rows[j].Cells[0].Value.ToString().Contains(regist))
                {
                    ТаблицаДоговор.Rows[j].Selected = true;
                    ПолеАдрес.Text = ТаблицаДоговор.Rows[j].Cells[1].Value.ToString();
                    ПолеАдрес.Items.Add(ТаблицаДоговор.Rows[j].Cells[1].Value);
                    ПолеДатаНачала.Text = ТаблицаДоговор.Rows[j].Cells[3].Value.ToString();
                    ПолеДатаОкончание.Text = ТаблицаДоговор.Rows[j].Cells[4].Value.ToString();
                    index = int.Parse(ТаблицаДоговор[2, j].Value.ToString());
                }
            }        
            for (int i = 0; i < ТаблицаПродление.RowCount; i++)
            {
                n = int.Parse(ТаблицаПродление[0, i].Value.ToString());
            }
        }

        private void Выйти_Click(object sender, EventArgs e)
        {
            //выход из приложения
            this.Close();
        }

        private void Продлить_Click(object sender, EventArgs e)
        {
            if (ПолеДатаПродление.Text == "" || ПолеДатаНачала.Text == "" || ПолеДатаОкончание.Text == "")
            {
                MessageBox.Show("Введите все необходимые данные для продления договора!");
            }
            else
            {
                if (ПолеДатаОкончание.Value.Month >= ПолеДатаПродление.Value.Month)
                {
                    MessageBox.Show("Продлить договор минимально можно на месяц");
                }
                else
                {
                    n = n + 1;
                    using (SqlConnection sqlConnect = new SqlConnection("Data Source=sql;Initial Catalog = УП_ПМ_01_Неверов_ДС; Integrated Security = True"))
                    {
                        SqlDataAdapter info1 = new SqlDataAdapter($"INSERT INTO [Prolonging] (ProlongingID,TreatyID,Prolong,Comment)VALUES('{n}','{index}','{ПолеДатаПродление.Text}','{ПолеКоммент.Text}');", sqlConnect);
                        DataTable dt1 = new DataTable();
                        info1.Fill(dt1);
                        MessageBox.Show("Ваша заявка на продление договора была принята");
                        this.Close();
                    }
                }
            }  
        }
    }
}
