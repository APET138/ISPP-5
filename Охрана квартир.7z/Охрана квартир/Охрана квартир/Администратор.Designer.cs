﻿namespace Охрана_квартир
{
    partial class Администратор
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Администратор));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.Меню = new System.Windows.Forms.ToolStrip();
            this.Файл = new System.Windows.Forms.ToolStripDropDownButton();
            this.обновить = new System.Windows.Forms.ToolStripMenuItem();
            this.вернутьсяКАвторизации = new System.Windows.Forms.ToolStripMenuItem();
            this.выйтиИзПриложения = new System.Windows.Forms.ToolStripMenuItem();
            this.Формы = new System.Windows.Forms.ToolStripDropDownButton();
            this.формаГостя = new System.Windows.Forms.ToolStripMenuItem();
            this.формаКомандира = new System.Windows.Forms.ToolStripMenuItem();
            this.формаКП = new System.Windows.Forms.ToolStripMenuItem();
            this.Таблицы = new System.Windows.Forms.ToolStripDropDownButton();
            this.client = new System.Windows.Forms.ToolStripMenuItem();
            this.flat = new System.Windows.Forms.ToolStripMenuItem();
            this.house = new System.Windows.Forms.ToolStripMenuItem();
            this.flatHouse = new System.Windows.Forms.ToolStripMenuItem();
            this.settlement = new System.Windows.Forms.ToolStripMenuItem();
            this.contract = new System.Windows.Forms.ToolStripMenuItem();
            this.prolonging = new System.Windows.Forms.ToolStripMenuItem();
            this.capture = new System.Windows.Forms.ToolStripMenuItem();
            this.calling = new System.Windows.Forms.ToolStripMenuItem();
            this.user = new System.Windows.Forms.ToolStripMenuItem();
            this.ТаблицаАдминистратор = new System.Windows.Forms.DataGridView();
            this.уП_ПМ_01_Неверов_ДСDataSet = new Охрана_квартир.УП_ПМ_01_Неверов_ДСDataSet();
            this.Выход = new System.Windows.Forms.PictureBox();
            this.ДобавитьЗапись = new System.Windows.Forms.PictureBox();
            this.УдалитьЗапись = new System.Windows.Forms.PictureBox();
            this.СледующаяЗапись = new System.Windows.Forms.PictureBox();
            this.ПредыдущаяЗапись = new System.Windows.Forms.PictureBox();
            this.Надпись1 = new System.Windows.Forms.Label();
            this.Надпись2 = new System.Windows.Forms.Label();
            this.Надпись3 = new System.Windows.Forms.Label();
            this.Надпись4 = new System.Windows.Forms.Label();
            this.Надпись5 = new System.Windows.Forms.Label();
            this.Надпись6 = new System.Windows.Forms.Label();
            this.Поиск = new System.Windows.Forms.Label();
            this.ПолеПоиск = new System.Windows.Forms.TextBox();
            this.ПолеПланКвартиры = new System.Windows.Forms.PictureBox();
            this.PlanFlat = new System.Windows.Forms.Label();
            this.ПолеКодКлиента = new System.Windows.Forms.TextBox();
            this.clientBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.ПолеФамилия = new System.Windows.Forms.TextBox();
            this.ПолеИмя = new System.Windows.Forms.TextBox();
            this.ПолеОтчество = new System.Windows.Forms.TextBox();
            this.ПолеАдрес = new System.Windows.Forms.TextBox();
            this.ПолеТелефон = new System.Windows.Forms.MaskedTextBox();
            this.Клиент = new System.Windows.Forms.GroupBox();
            this.Квартира = new System.Windows.Forms.GroupBox();
            this.НадписьТипБалкона = new System.Windows.Forms.Label();
            this.flatBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.НадписьТипДвери = new System.Windows.Forms.Label();
            this.ПолеТипДвери = new System.Windows.Forms.ComboBox();
            this.ЕстьБалкон = new System.Windows.Forms.CheckBox();
            this.ПолеТипБалкона = new System.Windows.Forms.ComboBox();
            this.ПолеКодКвартиры = new System.Windows.Forms.TextBox();
            this.ПолеАдресКвартиры = new System.Windows.Forms.TextBox();
            this.ПолеЭтажКвартиры = new System.Windows.Forms.TextBox();
            this.houseBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.Дом = new System.Windows.Forms.GroupBox();
            this.НадписьТипДома = new System.Windows.Forms.Label();
            this.ПолеТипДома = new System.Windows.Forms.ComboBox();
            this.ЕстьЗамок = new System.Windows.Forms.CheckBox();
            this.ПолеКодДома = new System.Windows.Forms.TextBox();
            this.ПолеЭтажейВДоме = new System.Windows.Forms.TextBox();
            this.КвартираДом = new System.Windows.Forms.GroupBox();
            this.ПолеКодДома2 = new System.Windows.Forms.TextBox();
            this.flatHouseBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.ПолеКодКвартираДом = new System.Windows.Forms.TextBox();
            this.ПолеКодКвартиры2 = new System.Windows.Forms.TextBox();
            this.Заселение = new System.Windows.Forms.GroupBox();
            this.ПолеКодКлиента2 = new System.Windows.Forms.TextBox();
            this.settlementBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.ПолеКодЗаселения = new System.Windows.Forms.TextBox();
            this.ПолеКодКвартиры3 = new System.Windows.Forms.TextBox();
            this.Договор = new System.Windows.Forms.GroupBox();
            this.ПолеПлата = new System.Windows.Forms.TextBox();
            this.contractBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.ПолеДатаОкончание = new System.Windows.Forms.MaskedTextBox();
            this.ПолеДатаНачала = new System.Windows.Forms.MaskedTextBox();
            this.ПолеКодДоговора = new System.Windows.Forms.TextBox();
            this.ПолеКодЗаселения2 = new System.Windows.Forms.TextBox();
            this.ВставкаКартинки = new System.Windows.Forms.OpenFileDialog();
            this.ПолеКодДоговора2 = new System.Windows.Forms.TextBox();
            this.prolongingBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.ПолеКодПродление = new System.Windows.Forms.TextBox();
            this.ПолеКоммент = new System.Windows.Forms.TextBox();
            this.ПолеДатаПродление = new System.Windows.Forms.MaskedTextBox();
            this.Продление = new System.Windows.Forms.GroupBox();
            this.ГруппаЗаквата = new System.Windows.Forms.GroupBox();
            this.ПолеКодГруппыЗахвата = new System.Windows.Forms.TextBox();
            this.captureBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.ПолеНомерЭкипажа = new System.Windows.Forms.TextBox();
            this.ПолеДокумент = new System.Windows.Forms.TextBox();
            this.ПолеКомандирЭкипажа = new System.Windows.Forms.TextBox();
            this.ПолеАвтомобиль = new System.Windows.Forms.TextBox();
            this.ПолеКодГруппыЗахвата2 = new System.Windows.Forms.TextBox();
            this.callingBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.ПолеКодДоговора3 = new System.Windows.Forms.TextBox();
            this.ПолеКодВызова = new System.Windows.Forms.TextBox();
            this.ЛожныйВызов = new System.Windows.Forms.CheckBox();
            this.Вызов = new System.Windows.Forms.GroupBox();
            this.ПолеКомпенсация = new System.Windows.Forms.TextBox();
            this.ПолеШтраф = new System.Windows.Forms.TextBox();
            this.ПолеДатаВызова = new System.Windows.Forms.MaskedTextBox();
            this.Доступ = new System.Windows.Forms.Label();
            this.Пользователь = new System.Windows.Forms.GroupBox();
            this.НадписьПраваДоступа = new System.Windows.Forms.Label();
            this.userBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.ПолеПраваДоступа = new System.Windows.Forms.ComboBox();
            this.ПолеЛогин = new System.Windows.Forms.TextBox();
            this.ПолеПароль = new System.Windows.Forms.TextBox();
            this.ПолеКодКлиента3 = new System.Windows.Forms.TextBox();
            this.userBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.userTableAdapter1 = new Охрана_квартир.УП_НеверовDataSetTableAdapters.UserTableAdapter();
            this.ОбновлениеЗаписей = new System.Windows.Forms.PictureBox();
            this.Plan = new System.Windows.Forms.Label();
            this.ПоследняяЗапись = new System.Windows.Forms.PictureBox();
            this.ПерваяЗапись = new System.Windows.Forms.PictureBox();
            this.captureTableAdapter = new Охрана_квартир.УП_ПМ_01_Неверов_ДСDataSetTableAdapters.CaptureTableAdapter();
            this.clientTableAdapter = new Охрана_квартир.УП_ПМ_01_Неверов_ДСDataSetTableAdapters.ClientTableAdapter();
            this.contractTableAdapter = new Охрана_квартир.УП_ПМ_01_Неверов_ДСDataSetTableAdapters.ContractTableAdapter();
            this.callingTableAdapter = new Охрана_квартир.УП_ПМ_01_Неверов_ДСDataSetTableAdapters.CallingTableAdapter();
            this.flat_HouseTableAdapter = new Охрана_квартир.УП_ПМ_01_Неверов_ДСDataSetTableAdapters.Flat_HouseTableAdapter();
            this.houseTableAdapter = new Охрана_квартир.УП_ПМ_01_Неверов_ДСDataSetTableAdapters.HouseTableAdapter();
            this.prolongingTableAdapter = new Охрана_квартир.УП_ПМ_01_Неверов_ДСDataSetTableAdapters.ProlongingTableAdapter();
            this.userTableAdapter = new Охрана_квартир.УП_ПМ_01_Неверов_ДСDataSetTableAdapters.UserTableAdapter();
            this.settlementTableAdapter = new Охрана_квартир.УП_ПМ_01_Неверов_ДСDataSetTableAdapters.SettlementTableAdapter();
            this.flatTableAdapter = new Охрана_квартир.УП_ПМ_01_Неверов_ДСDataSetTableAdapters.FlatTableAdapter();
            this.Надпись7 = new System.Windows.Forms.Label();
            this.Меню.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ТаблицаАдминистратор)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.уП_ПМ_01_Неверов_ДСDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Выход)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ДобавитьЗапись)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.УдалитьЗапись)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.СледующаяЗапись)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ПредыдущаяЗапись)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ПолеПланКвартиры)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.clientBindingSource)).BeginInit();
            this.Клиент.SuspendLayout();
            this.Квартира.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.flatBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.houseBindingSource)).BeginInit();
            this.Дом.SuspendLayout();
            this.КвартираДом.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.flatHouseBindingSource)).BeginInit();
            this.Заселение.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.settlementBindingSource)).BeginInit();
            this.Договор.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.contractBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.prolongingBindingSource)).BeginInit();
            this.Продление.SuspendLayout();
            this.ГруппаЗаквата.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.captureBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.callingBindingSource)).BeginInit();
            this.Вызов.SuspendLayout();
            this.Пользователь.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.userBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.userBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ОбновлениеЗаписей)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ПоследняяЗапись)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ПерваяЗапись)).BeginInit();
            this.SuspendLayout();
            // 
            // Меню
            // 
            this.Меню.BackColor = System.Drawing.Color.White;
            this.Меню.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.Меню.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Файл,
            this.Формы,
            this.Таблицы});
            this.Меню.Location = new System.Drawing.Point(0, 0);
            this.Меню.Name = "Меню";
            this.Меню.Size = new System.Drawing.Size(1331, 31);
            this.Меню.TabIndex = 0;
            this.Меню.Text = "toolStrip1";
            // 
            // Файл
            // 
            this.Файл.BackColor = System.Drawing.Color.LightGray;
            this.Файл.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.Файл.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.обновить,
            this.вернутьсяКАвторизации,
            this.выйтиИзПриложения});
            this.Файл.Image = ((System.Drawing.Image)(resources.GetObject("Файл.Image")));
            this.Файл.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Файл.Name = "Файл";
            this.Файл.Size = new System.Drawing.Size(59, 28);
            this.Файл.Text = "Файл";
            // 
            // обновить
            // 
            this.обновить.Name = "обновить";
            this.обновить.Size = new System.Drawing.Size(269, 26);
            this.обновить.Text = "Обновить";
            this.обновить.Click += new System.EventHandler(this.обновить_Click);
            // 
            // вернутьсяКАвторизации
            // 
            this.вернутьсяКАвторизации.Name = "вернутьсяКАвторизации";
            this.вернутьсяКАвторизации.Size = new System.Drawing.Size(269, 26);
            this.вернутьсяКАвторизации.Text = "Вернуться к авторизации";
            this.вернутьсяКАвторизации.Click += new System.EventHandler(this.вернутьсяКАвторизации_Click);
            // 
            // выйтиИзПриложения
            // 
            this.выйтиИзПриложения.Name = "выйтиИзПриложения";
            this.выйтиИзПриложения.Size = new System.Drawing.Size(269, 26);
            this.выйтиИзПриложения.Text = "Выйти из приложения";
            this.выйтиИзПриложения.Click += new System.EventHandler(this.выйтиИзПриложения_Click_1);
            // 
            // Формы
            // 
            this.Формы.BackColor = System.Drawing.Color.LightGray;
            this.Формы.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.Формы.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.формаГостя,
            this.формаКомандира,
            this.формаКП});
            this.Формы.Image = ((System.Drawing.Image)(resources.GetObject("Формы.Image")));
            this.Формы.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Формы.Name = "Формы";
            this.Формы.Size = new System.Drawing.Size(74, 28);
            this.Формы.Text = "Формы";
            // 
            // формаГостя
            // 
            this.формаГостя.Name = "формаГостя";
            this.формаГостя.Size = new System.Drawing.Size(233, 26);
            this.формаГостя.Text = "Форма регистрации";
            this.формаГостя.Click += new System.EventHandler(this.формаГостя_Click);
            // 
            // формаКомандира
            // 
            this.формаКомандира.Name = "формаКомандира";
            this.формаКомандира.Size = new System.Drawing.Size(233, 26);
            this.формаКомандира.Text = "Форма Командира";
            this.формаКомандира.Click += new System.EventHandler(this.формаКомандира_Click);
            // 
            // формаКП
            // 
            this.формаКП.Name = "формаКП";
            this.формаКП.Size = new System.Drawing.Size(233, 26);
            this.формаКП.Text = "Форма КП";
            // 
            // Таблицы
            // 
            this.Таблицы.BackColor = System.Drawing.Color.LightGray;
            this.Таблицы.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.Таблицы.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.client,
            this.flat,
            this.house,
            this.flatHouse,
            this.settlement,
            this.contract,
            this.prolonging,
            this.capture,
            this.calling,
            this.user});
            this.Таблицы.Image = ((System.Drawing.Image)(resources.GetObject("Таблицы.Image")));
            this.Таблицы.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Таблицы.Name = "Таблицы";
            this.Таблицы.Size = new System.Drawing.Size(85, 28);
            this.Таблицы.Text = "Таблицы";
            // 
            // client
            // 
            this.client.Name = "client";
            this.client.Size = new System.Drawing.Size(224, 26);
            this.client.Text = "Client";
            this.client.Click += new System.EventHandler(this.client_Click);
            // 
            // flat
            // 
            this.flat.Name = "flat";
            this.flat.Size = new System.Drawing.Size(224, 26);
            this.flat.Text = "Flat";
            this.flat.Click += new System.EventHandler(this.flat_Click);
            // 
            // house
            // 
            this.house.Name = "house";
            this.house.Size = new System.Drawing.Size(224, 26);
            this.house.Text = "House";
            this.house.Click += new System.EventHandler(this.house_Click);
            // 
            // flatHouse
            // 
            this.flatHouse.Name = "flatHouse";
            this.flatHouse.Size = new System.Drawing.Size(224, 26);
            this.flatHouse.Text = "Flat-House";
            this.flatHouse.Click += new System.EventHandler(this.flatHouse_Click);
            // 
            // settlement
            // 
            this.settlement.Name = "settlement";
            this.settlement.Size = new System.Drawing.Size(224, 26);
            this.settlement.Text = "Settlement";
            this.settlement.Click += new System.EventHandler(this.settlement_Click);
            // 
            // contract
            // 
            this.contract.Name = "contract";
            this.contract.Size = new System.Drawing.Size(224, 26);
            this.contract.Text = "Contract";
            this.contract.Click += new System.EventHandler(this.contract_Click);
            // 
            // prolonging
            // 
            this.prolonging.Name = "prolonging";
            this.prolonging.Size = new System.Drawing.Size(224, 26);
            this.prolonging.Text = "Prolonging";
            this.prolonging.Click += new System.EventHandler(this.prolonging_Click);
            // 
            // capture
            // 
            this.capture.Name = "capture";
            this.capture.Size = new System.Drawing.Size(224, 26);
            this.capture.Text = "Capture";
            this.capture.Click += new System.EventHandler(this.capture_Click);
            // 
            // calling
            // 
            this.calling.Name = "calling";
            this.calling.Size = new System.Drawing.Size(224, 26);
            this.calling.Text = "Calling";
            this.calling.Click += new System.EventHandler(this.calling_Click);
            // 
            // user
            // 
            this.user.Name = "user";
            this.user.Size = new System.Drawing.Size(224, 26);
            this.user.Text = "User";
            this.user.Visible = false;
            this.user.Click += new System.EventHandler(this.user_Click);
            // 
            // ТаблицаАдминистратор
            // 
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.ТаблицаАдминистратор.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.ТаблицаАдминистратор.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.ТаблицаАдминистратор.DefaultCellStyle = dataGridViewCellStyle2;
            this.ТаблицаАдминистратор.Location = new System.Drawing.Point(0, 31);
            this.ТаблицаАдминистратор.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ТаблицаАдминистратор.Name = "ТаблицаАдминистратор";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.ТаблицаАдминистратор.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.ТаблицаАдминистратор.RowHeadersWidth = 51;
            this.ТаблицаАдминистратор.Size = new System.Drawing.Size(585, 327);
            this.ТаблицаАдминистратор.TabIndex = 4;
            this.ТаблицаАдминистратор.RowEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.ТаблицаАдминистратор_RowEnter);
            // 
            // уП_ПМ_01_Неверов_ДСDataSet
            // 
            this.уП_ПМ_01_Неверов_ДСDataSet.DataSetName = "УП_ПМ_01_Неверов_ДСDataSet";
            this.уП_ПМ_01_Неверов_ДСDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // Выход
            // 
            this.Выход.BackColor = System.Drawing.Color.White;
            this.Выход.Image = ((System.Drawing.Image)(resources.GetObject("Выход.Image")));
            this.Выход.Location = new System.Drawing.Point(885, -1);
            this.Выход.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Выход.Name = "Выход";
            this.Выход.Size = new System.Drawing.Size(32, 30);
            this.Выход.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Выход.TabIndex = 27;
            this.Выход.TabStop = false;
            this.Выход.Click += new System.EventHandler(this.Выход_Click);
            // 
            // ДобавитьЗапись
            // 
            this.ДобавитьЗапись.Image = ((System.Drawing.Image)(resources.GetObject("ДобавитьЗапись.Image")));
            this.ДобавитьЗапись.Location = new System.Drawing.Point(484, 366);
            this.ДобавитьЗапись.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ДобавитьЗапись.Name = "ДобавитьЗапись";
            this.ДобавитьЗапись.Size = new System.Drawing.Size(47, 43);
            this.ДобавитьЗапись.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ДобавитьЗапись.TabIndex = 29;
            this.ДобавитьЗапись.TabStop = false;
            this.ДобавитьЗапись.Click += new System.EventHandler(this.ДобавитьЗапись_Click);
            // 
            // УдалитьЗапись
            // 
            this.УдалитьЗапись.Image = ((System.Drawing.Image)(resources.GetObject("УдалитьЗапись.Image")));
            this.УдалитьЗапись.Location = new System.Drawing.Point(539, 366);
            this.УдалитьЗапись.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.УдалитьЗапись.Name = "УдалитьЗапись";
            this.УдалитьЗапись.Size = new System.Drawing.Size(47, 43);
            this.УдалитьЗапись.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.УдалитьЗапись.TabIndex = 30;
            this.УдалитьЗапись.TabStop = false;
            this.УдалитьЗапись.Click += new System.EventHandler(this.УдалитьЗапись_Click);
            // 
            // СледующаяЗапись
            // 
            this.СледующаяЗапись.Image = ((System.Drawing.Image)(resources.GetObject("СледующаяЗапись.Image")));
            this.СледующаяЗапись.Location = new System.Drawing.Point(285, 366);
            this.СледующаяЗапись.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.СледующаяЗапись.Name = "СледующаяЗапись";
            this.СледующаяЗапись.Size = new System.Drawing.Size(47, 43);
            this.СледующаяЗапись.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.СледующаяЗапись.TabIndex = 31;
            this.СледующаяЗапись.TabStop = false;
            this.СледующаяЗапись.Click += new System.EventHandler(this.СледующаяЗапись_Click);
            // 
            // ПредыдущаяЗапись
            // 
            this.ПредыдущаяЗапись.Image = ((System.Drawing.Image)(resources.GetObject("ПредыдущаяЗапись.Image")));
            this.ПредыдущаяЗапись.Location = new System.Drawing.Point(231, 366);
            this.ПредыдущаяЗапись.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ПредыдущаяЗапись.Name = "ПредыдущаяЗапись";
            this.ПредыдущаяЗапись.Size = new System.Drawing.Size(47, 43);
            this.ПредыдущаяЗапись.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ПредыдущаяЗапись.TabIndex = 32;
            this.ПредыдущаяЗапись.TabStop = false;
            this.ПредыдущаяЗапись.Click += new System.EventHandler(this.ПредыдущаяЗапись_Click);
            // 
            // Надпись1
            // 
            this.Надпись1.AutoSize = true;
            this.Надпись1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Надпись1.Location = new System.Drawing.Point(592, 50);
            this.Надпись1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Надпись1.Name = "Надпись1";
            this.Надпись1.Size = new System.Drawing.Size(0, 25);
            this.Надпись1.TabIndex = 36;
            // 
            // Надпись2
            // 
            this.Надпись2.AutoSize = true;
            this.Надпись2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Надпись2.Location = new System.Drawing.Point(592, 90);
            this.Надпись2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Надпись2.Name = "Надпись2";
            this.Надпись2.Size = new System.Drawing.Size(0, 25);
            this.Надпись2.TabIndex = 37;
            // 
            // Надпись3
            // 
            this.Надпись3.AutoSize = true;
            this.Надпись3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Надпись3.Location = new System.Drawing.Point(592, 129);
            this.Надпись3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Надпись3.Name = "Надпись3";
            this.Надпись3.Size = new System.Drawing.Size(0, 25);
            this.Надпись3.TabIndex = 39;
            // 
            // Надпись4
            // 
            this.Надпись4.AutoSize = true;
            this.Надпись4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Надпись4.Location = new System.Drawing.Point(592, 169);
            this.Надпись4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Надпись4.Name = "Надпись4";
            this.Надпись4.Size = new System.Drawing.Size(0, 25);
            this.Надпись4.TabIndex = 41;
            // 
            // Надпись5
            // 
            this.Надпись5.AutoSize = true;
            this.Надпись5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Надпись5.Location = new System.Drawing.Point(592, 208);
            this.Надпись5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Надпись5.Name = "Надпись5";
            this.Надпись5.Size = new System.Drawing.Size(0, 25);
            this.Надпись5.TabIndex = 43;
            // 
            // Надпись6
            // 
            this.Надпись6.AutoSize = true;
            this.Надпись6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Надпись6.Location = new System.Drawing.Point(592, 247);
            this.Надпись6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Надпись6.Name = "Надпись6";
            this.Надпись6.Size = new System.Drawing.Size(0, 25);
            this.Надпись6.TabIndex = 45;
            // 
            // Поиск
            // 
            this.Поиск.BackColor = System.Drawing.Color.LightGray;
            this.Поиск.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Поиск.Location = new System.Drawing.Point(537, 1);
            this.Поиск.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Поиск.Name = "Поиск";
            this.Поиск.Size = new System.Drawing.Size(67, 27);
            this.Поиск.TabIndex = 47;
            this.Поиск.Text = "Поиск:";
            // 
            // ПолеПоиск
            // 
            this.ПолеПоиск.BackColor = System.Drawing.Color.LightGray;
            this.ПолеПоиск.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.ПолеПоиск.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.ПолеПоиск.Location = new System.Drawing.Point(604, 1);
            this.ПолеПоиск.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ПолеПоиск.Multiline = true;
            this.ПолеПоиск.Name = "ПолеПоиск";
            this.ПолеПоиск.ShortcutsEnabled = false;
            this.ПолеПоиск.Size = new System.Drawing.Size(192, 27);
            this.ПолеПоиск.TabIndex = 46;
            this.ПолеПоиск.TextChanged += new System.EventHandler(this.ПолеПоиск_TextChanged);
            // 
            // ПолеПланКвартиры
            // 
            this.ПолеПланКвартиры.Image = ((System.Drawing.Image)(resources.GetObject("ПолеПланКвартиры.Image")));
            this.ПолеПланКвартиры.Location = new System.Drawing.Point(927, 86);
            this.ПолеПланКвартиры.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ПолеПланКвартиры.Name = "ПолеПланКвартиры";
            this.ПолеПланКвартиры.Size = new System.Drawing.Size(219, 190);
            this.ПолеПланКвартиры.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ПолеПланКвартиры.TabIndex = 48;
            this.ПолеПланКвартиры.TabStop = false;
            this.ПолеПланКвартиры.Click += new System.EventHandler(this.ПолеПланКвартиры_Click);
            // 
            // PlanFlat
            // 
            this.PlanFlat.AutoSize = true;
            this.PlanFlat.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.PlanFlat.Location = new System.Drawing.Point(921, 47);
            this.PlanFlat.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.PlanFlat.Name = "PlanFlat";
            this.PlanFlat.Size = new System.Drawing.Size(0, 25);
            this.PlanFlat.TabIndex = 50;
            // 
            // ПолеКодКлиента
            // 
            this.ПолеКодКлиента.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.clientBindingSource, "Registr", true));
            this.ПолеКодКлиента.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ПолеКодКлиента.Location = new System.Drawing.Point(8, 15);
            this.ПолеКодКлиента.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ПолеКодКлиента.Name = "ПолеКодКлиента";
            this.ПолеКодКлиента.ShortcutsEnabled = false;
            this.ПолеКодКлиента.Size = new System.Drawing.Size(132, 30);
            this.ПолеКодКлиента.TabIndex = 51;
            this.ПолеКодКлиента.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ПолеКодКлиента_KeyPress);
            // 
            // clientBindingSource
            // 
            this.clientBindingSource.DataMember = "Client";
            this.clientBindingSource.DataSource = this.уП_ПМ_01_Неверов_ДСDataSet;
            // 
            // ПолеФамилия
            // 
            this.ПолеФамилия.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.clientBindingSource, "SecondName", true));
            this.ПолеФамилия.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ПолеФамилия.Location = new System.Drawing.Point(8, 54);
            this.ПолеФамилия.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ПолеФамилия.MaxLength = 60;
            this.ПолеФамилия.Name = "ПолеФамилия";
            this.ПолеФамилия.ShortcutsEnabled = false;
            this.ПолеФамилия.Size = new System.Drawing.Size(132, 30);
            this.ПолеФамилия.TabIndex = 52;
            this.ПолеФамилия.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ПолеФамилия_KeyPress);
            // 
            // ПолеИмя
            // 
            this.ПолеИмя.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.clientBindingSource, "FirstName", true));
            this.ПолеИмя.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ПолеИмя.Location = new System.Drawing.Point(8, 94);
            this.ПолеИмя.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ПолеИмя.MaxLength = 60;
            this.ПолеИмя.Name = "ПолеИмя";
            this.ПолеИмя.ShortcutsEnabled = false;
            this.ПолеИмя.Size = new System.Drawing.Size(132, 30);
            this.ПолеИмя.TabIndex = 53;
            this.ПолеИмя.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ПолеИмя_KeyPress);
            // 
            // ПолеОтчество
            // 
            this.ПолеОтчество.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.clientBindingSource, "ThirdName", true));
            this.ПолеОтчество.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ПолеОтчество.Location = new System.Drawing.Point(8, 133);
            this.ПолеОтчество.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ПолеОтчество.MaxLength = 60;
            this.ПолеОтчество.Name = "ПолеОтчество";
            this.ПолеОтчество.ShortcutsEnabled = false;
            this.ПолеОтчество.Size = new System.Drawing.Size(132, 30);
            this.ПолеОтчество.TabIndex = 54;
            this.ПолеОтчество.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ПолеОтчество_KeyPress);
            // 
            // ПолеАдрес
            // 
            this.ПолеАдрес.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.clientBindingSource, "Address", true));
            this.ПолеАдрес.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ПолеАдрес.Location = new System.Drawing.Point(8, 172);
            this.ПолеАдрес.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ПолеАдрес.MaxLength = 60;
            this.ПолеАдрес.Name = "ПолеАдрес";
            this.ПолеАдрес.ShortcutsEnabled = false;
            this.ПолеАдрес.Size = new System.Drawing.Size(132, 30);
            this.ПолеАдрес.TabIndex = 55;
            this.ПолеАдрес.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ПолеАдрес_KeyPress);
            // 
            // ПолеТелефон
            // 
            this.ПолеТелефон.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ПолеТелефон.BackColor = System.Drawing.SystemColors.Window;
            this.ПолеТелефон.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.clientBindingSource, "Phone", true));
            this.ПолеТелефон.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.ПолеТелефон.Location = new System.Drawing.Point(8, 212);
            this.ПолеТелефон.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ПолеТелефон.Mask = "9990000000";
            this.ПолеТелефон.Name = "ПолеТелефон";
            this.ПолеТелефон.ShortcutsEnabled = false;
            this.ПолеТелефон.Size = new System.Drawing.Size(132, 30);
            this.ПолеТелефон.TabIndex = 56;
            // 
            // Клиент
            // 
            this.Клиент.Controls.Add(this.ПолеКодКлиента);
            this.Клиент.Controls.Add(this.ПолеТелефон);
            this.Клиент.Controls.Add(this.ПолеФамилия);
            this.Клиент.Controls.Add(this.ПолеАдрес);
            this.Клиент.Controls.Add(this.ПолеИмя);
            this.Клиент.Controls.Add(this.ПолеОтчество);
            this.Клиент.Location = new System.Drawing.Point(756, 32);
            this.Клиент.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Клиент.Name = "Клиент";
            this.Клиент.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Клиент.Size = new System.Drawing.Size(151, 250);
            this.Клиент.TabIndex = 57;
            this.Клиент.TabStop = false;
            // 
            // Квартира
            // 
            this.Квартира.Controls.Add(this.НадписьТипБалкона);
            this.Квартира.Controls.Add(this.НадписьТипДвери);
            this.Квартира.Controls.Add(this.ПолеТипДвери);
            this.Квартира.Controls.Add(this.ЕстьБалкон);
            this.Квартира.Controls.Add(this.ПолеТипБалкона);
            this.Квартира.Controls.Add(this.ПолеКодКвартиры);
            this.Квартира.Controls.Add(this.ПолеАдресКвартиры);
            this.Квартира.Controls.Add(this.ПолеЭтажКвартиры);
            this.Квартира.Location = new System.Drawing.Point(1157, 447);
            this.Квартира.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Квартира.Name = "Квартира";
            this.Квартира.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Квартира.Size = new System.Drawing.Size(151, 250);
            this.Квартира.TabIndex = 58;
            this.Квартира.TabStop = false;
            // 
            // НадписьТипБалкона
            // 
            this.НадписьТипБалкона.AutoSize = true;
            this.НадписьТипБалкона.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.flatBindingSource, "TypeBalcony", true));
            this.НадписьТипБалкона.Location = new System.Drawing.Point(23, 225);
            this.НадписьТипБалкона.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.НадписьТипБалкона.Name = "НадписьТипБалкона";
            this.НадписьТипБалкона.Size = new System.Drawing.Size(0, 16);
            this.НадписьТипБалкона.TabIndex = 62;
            this.НадписьТипБалкона.Visible = false;
            // 
            // flatBindingSource
            // 
            this.flatBindingSource.DataMember = "Flat";
            this.flatBindingSource.DataSource = this.уП_ПМ_01_Неверов_ДСDataSet;
            // 
            // НадписьТипДвери
            // 
            this.НадписьТипДвери.AutoSize = true;
            this.НадписьТипДвери.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.flatBindingSource, "TypeDoor", true));
            this.НадписьТипДвери.Location = new System.Drawing.Point(23, 144);
            this.НадписьТипДвери.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.НадписьТипДвери.Name = "НадписьТипДвери";
            this.НадписьТипДвери.Size = new System.Drawing.Size(0, 16);
            this.НадписьТипДвери.TabIndex = 61;
            this.НадписьТипДвери.Visible = false;
            // 
            // ПолеТипДвери
            // 
            this.ПолеТипДвери.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.ПолеТипДвери.FormattingEnabled = true;
            this.ПолеТипДвери.Items.AddRange(new object[] {
            "Металическая ",
            "Деревянная",
            "Две двери"});
            this.ПолеТипДвери.Location = new System.Drawing.Point(8, 134);
            this.ПолеТипДвери.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ПолеТипДвери.Name = "ПолеТипДвери";
            this.ПолеТипДвери.Size = new System.Drawing.Size(132, 33);
            this.ПолеТипДвери.TabIndex = 58;
            this.ПолеТипДвери.SelectedIndexChanged += new System.EventHandler(this.ПолеТипДвери_SelectedIndexChanged);
            // 
            // ЕстьБалкон
            // 
            this.ЕстьБалкон.AutoSize = true;
            this.ЕстьБалкон.DataBindings.Add(new System.Windows.Forms.Binding("CheckAlign", this.flatBindingSource, "Balcony", true));
            this.ЕстьБалкон.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.flatBindingSource, "Balcony", true));
            this.ЕстьБалкон.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.flatBindingSource, "Balcony", true));
            this.ЕстьБалкон.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ЕстьБалкон.Location = new System.Drawing.Point(3, 176);
            this.ЕстьБалкон.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ЕстьБалкон.Name = "ЕстьБалкон";
            this.ЕстьБалкон.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.ЕстьБалкон.Size = new System.Drawing.Size(128, 28);
            this.ЕстьБалкон.TabIndex = 57;
            this.ЕстьБалкон.Text = "Есть Балкон";
            this.ЕстьБалкон.UseVisualStyleBackColor = true;
            this.ЕстьБалкон.CheckedChanged += new System.EventHandler(this.ЕстьБалкон_CheckedChanged);
            // 
            // ПолеТипБалкона
            // 
            this.ПолеТипБалкона.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.ПолеТипБалкона.FormattingEnabled = true;
            this.ПолеТипБалкона.Items.AddRange(new object[] {
            "Отдельный ",
            "Совмещенный"});
            this.ПолеТипБалкона.Location = new System.Drawing.Point(8, 212);
            this.ПолеТипБалкона.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ПолеТипБалкона.Name = "ПолеТипБалкона";
            this.ПолеТипБалкона.Size = new System.Drawing.Size(132, 33);
            this.ПолеТипБалкона.TabIndex = 56;
            this.ПолеТипБалкона.SelectedIndexChanged += new System.EventHandler(this.ПолеТипБалкона_SelectedIndexChanged);
            // 
            // ПолеКодКвартиры
            // 
            this.ПолеКодКвартиры.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.flatBindingSource, "FlatID", true));
            this.ПолеКодКвартиры.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ПолеКодКвартиры.Location = new System.Drawing.Point(8, 16);
            this.ПолеКодКвартиры.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ПолеКодКвартиры.Name = "ПолеКодКвартиры";
            this.ПолеКодКвартиры.ShortcutsEnabled = false;
            this.ПолеКодКвартиры.Size = new System.Drawing.Size(132, 30);
            this.ПолеКодКвартиры.TabIndex = 51;
            this.ПолеКодКвартиры.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ПолеКодАдресКвартиры_KeyPress);
            // 
            // ПолеАдресКвартиры
            // 
            this.ПолеАдресКвартиры.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.flatBindingSource, "AddressFlat", true));
            this.ПолеАдресКвартиры.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ПолеАдресКвартиры.Location = new System.Drawing.Point(8, 55);
            this.ПолеАдресКвартиры.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ПолеАдресКвартиры.MaxLength = 60;
            this.ПолеАдресКвартиры.Name = "ПолеАдресКвартиры";
            this.ПолеАдресКвартиры.ShortcutsEnabled = false;
            this.ПолеАдресКвартиры.Size = new System.Drawing.Size(132, 30);
            this.ПолеАдресКвартиры.TabIndex = 52;
            this.ПолеАдресКвартиры.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ПолеАдресКвартиры_KeyPress);
            // 
            // ПолеЭтажКвартиры
            // 
            this.ПолеЭтажКвартиры.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.flatBindingSource, "Floor", true));
            this.ПолеЭтажКвартиры.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ПолеЭтажКвартиры.Location = new System.Drawing.Point(8, 95);
            this.ПолеЭтажКвартиры.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ПолеЭтажКвартиры.MaxLength = 2;
            this.ПолеЭтажКвартиры.Name = "ПолеЭтажКвартиры";
            this.ПолеЭтажКвартиры.ShortcutsEnabled = false;
            this.ПолеЭтажКвартиры.Size = new System.Drawing.Size(132, 30);
            this.ПолеЭтажКвартиры.TabIndex = 53;
            this.ПолеЭтажКвартиры.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ПолеЭтажКвартиры_KeyPress);
            // 
            // houseBindingSource
            // 
            this.houseBindingSource.DataMember = "House";
            this.houseBindingSource.DataSource = this.уП_ПМ_01_Неверов_ДСDataSet;
            // 
            // Дом
            // 
            this.Дом.Controls.Add(this.НадписьТипДома);
            this.Дом.Controls.Add(this.ПолеТипДома);
            this.Дом.Controls.Add(this.ЕстьЗамок);
            this.Дом.Controls.Add(this.ПолеКодДома);
            this.Дом.Controls.Add(this.ПолеЭтажейВДоме);
            this.Дом.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Дом.Location = new System.Drawing.Point(1157, 47);
            this.Дом.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Дом.Name = "Дом";
            this.Дом.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Дом.Size = new System.Drawing.Size(151, 250);
            this.Дом.TabIndex = 59;
            this.Дом.TabStop = false;
            // 
            // НадписьТипДома
            // 
            this.НадписьТипДома.AutoSize = true;
            this.НадписьТипДома.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.houseBindingSource, "TypeHouse", true));
            this.НадписьТипДома.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F);
            this.НадписьТипДома.Location = new System.Drawing.Point(8, 171);
            this.НадписьТипДома.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.НадписьТипДома.Name = "НадписьТипДома";
            this.НадписьТипДома.Size = new System.Drawing.Size(0, 16);
            this.НадписьТипДома.TabIndex = 60;
            this.НадписьТипДома.Visible = false;
            // 
            // ПолеТипДома
            // 
            this.ПолеТипДома.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.ПолеТипДома.FormattingEnabled = true;
            this.ПолеТипДома.Items.AddRange(new object[] {
            "Кирпичный",
            "Панельный"});
            this.ПолеТипДома.Location = new System.Drawing.Point(8, 133);
            this.ПолеТипДома.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ПолеТипДома.Name = "ПолеТипДома";
            this.ПолеТипДома.Size = new System.Drawing.Size(132, 33);
            this.ПолеТипДома.TabIndex = 58;
            this.ПолеТипДома.SelectedIndexChanged += new System.EventHandler(this.ПолеТипДома_SelectedIndexChanged);
            // 
            // ЕстьЗамок
            // 
            this.ЕстьЗамок.AutoSize = true;
            this.ЕстьЗамок.DataBindings.Add(new System.Windows.Forms.Binding("CheckAlign", this.houseBindingSource, "Key", true));
            this.ЕстьЗамок.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.houseBindingSource, "Key", true));
            this.ЕстьЗамок.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.houseBindingSource, "Key", true));
            this.ЕстьЗамок.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ЕстьЗамок.Location = new System.Drawing.Point(11, 96);
            this.ЕстьЗамок.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ЕстьЗамок.Name = "ЕстьЗамок";
            this.ЕстьЗамок.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.ЕстьЗамок.Size = new System.Drawing.Size(117, 28);
            this.ЕстьЗамок.TabIndex = 57;
            this.ЕстьЗамок.Text = "Есть замок";
            this.ЕстьЗамок.UseVisualStyleBackColor = true;
            this.ЕстьЗамок.CheckedChanged += new System.EventHandler(this.ЕстьЗамок_CheckedChanged);
            // 
            // ПолеКодДома
            // 
            this.ПолеКодДома.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.houseBindingSource, "HouseID", true));
            this.ПолеКодДома.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ПолеКодДома.Location = new System.Drawing.Point(8, 15);
            this.ПолеКодДома.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ПолеКодДома.Name = "ПолеКодДома";
            this.ПолеКодДома.ShortcutsEnabled = false;
            this.ПолеКодДома.Size = new System.Drawing.Size(132, 30);
            this.ПолеКодДома.TabIndex = 51;
            this.ПолеКодДома.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ПолеКодДома_KeyPress);
            // 
            // ПолеЭтажейВДоме
            // 
            this.ПолеЭтажейВДоме.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.houseBindingSource, "Floors", true));
            this.ПолеЭтажейВДоме.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ПолеЭтажейВДоме.Location = new System.Drawing.Point(8, 54);
            this.ПолеЭтажейВДоме.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ПолеЭтажейВДоме.MaxLength = 2;
            this.ПолеЭтажейВДоме.Name = "ПолеЭтажейВДоме";
            this.ПолеЭтажейВДоме.ShortcutsEnabled = false;
            this.ПолеЭтажейВДоме.Size = new System.Drawing.Size(132, 30);
            this.ПолеЭтажейВДоме.TabIndex = 52;
            this.ПолеЭтажейВДоме.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ПолеЭтажейВДоме_KeyPress);
            // 
            // КвартираДом
            // 
            this.КвартираДом.Controls.Add(this.ПолеКодДома2);
            this.КвартираДом.Controls.Add(this.ПолеКодКвартираДом);
            this.КвартираДом.Controls.Add(this.ПолеКодКвартиры2);
            this.КвартираДом.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.КвартираДом.Location = new System.Drawing.Point(8, 446);
            this.КвартираДом.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.КвартираДом.Name = "КвартираДом";
            this.КвартираДом.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.КвартираДом.Size = new System.Drawing.Size(151, 250);
            this.КвартираДом.TabIndex = 60;
            this.КвартираДом.TabStop = false;
            // 
            // ПолеКодДома2
            // 
            this.ПолеКодДома2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.flatHouseBindingSource, "HouseID", true));
            this.ПолеКодДома2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ПолеКодДома2.Location = new System.Drawing.Point(8, 94);
            this.ПолеКодДома2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ПолеКодДома2.Name = "ПолеКодДома2";
            this.ПолеКодДома2.ShortcutsEnabled = false;
            this.ПолеКодДома2.Size = new System.Drawing.Size(132, 30);
            this.ПолеКодДома2.TabIndex = 53;
            // 
            // flatHouseBindingSource
            // 
            this.flatHouseBindingSource.DataMember = "Flat-House";
            this.flatHouseBindingSource.DataSource = this.уП_ПМ_01_Неверов_ДСDataSet;
            // 
            // ПолеКодКвартираДом
            // 
            this.ПолеКодКвартираДом.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.flatHouseBindingSource, "Flat-HouseID", true));
            this.ПолеКодКвартираДом.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ПолеКодКвартираДом.Location = new System.Drawing.Point(8, 15);
            this.ПолеКодКвартираДом.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ПолеКодКвартираДом.Name = "ПолеКодКвартираДом";
            this.ПолеКодКвартираДом.ShortcutsEnabled = false;
            this.ПолеКодКвартираДом.Size = new System.Drawing.Size(132, 30);
            this.ПолеКодКвартираДом.TabIndex = 51;
            this.ПолеКодКвартираДом.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ПолеКодКвартираДом_KeyPress);
            // 
            // ПолеКодКвартиры2
            // 
            this.ПолеКодКвартиры2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.flatHouseBindingSource, "FlatID", true));
            this.ПолеКодКвартиры2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ПолеКодКвартиры2.Location = new System.Drawing.Point(8, 54);
            this.ПолеКодКвартиры2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ПолеКодКвартиры2.Name = "ПолеКодКвартиры2";
            this.ПолеКодКвартиры2.ShortcutsEnabled = false;
            this.ПолеКодКвартиры2.Size = new System.Drawing.Size(132, 30);
            this.ПолеКодКвартиры2.TabIndex = 52;
            this.ПолеКодКвартиры2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ПолеКодКвартиры2_KeyPress);
            // 
            // Заселение
            // 
            this.Заселение.Controls.Add(this.ПолеКодКлиента2);
            this.Заселение.Controls.Add(this.ПолеКодЗаселения);
            this.Заселение.Controls.Add(this.ПолеКодКвартиры3);
            this.Заселение.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Заселение.Location = new System.Drawing.Point(167, 446);
            this.Заселение.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Заселение.Name = "Заселение";
            this.Заселение.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Заселение.Size = new System.Drawing.Size(151, 250);
            this.Заселение.TabIndex = 61;
            this.Заселение.TabStop = false;
            // 
            // ПолеКодКлиента2
            // 
            this.ПолеКодКлиента2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.settlementBindingSource, "Registr", true));
            this.ПолеКодКлиента2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ПолеКодКлиента2.Location = new System.Drawing.Point(8, 94);
            this.ПолеКодКлиента2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ПолеКодКлиента2.Name = "ПолеКодКлиента2";
            this.ПолеКодКлиента2.ShortcutsEnabled = false;
            this.ПолеКодКлиента2.Size = new System.Drawing.Size(132, 30);
            this.ПолеКодКлиента2.TabIndex = 53;
            this.ПолеКодКлиента2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ПолеКодКлиента2_KeyPress);
            // 
            // settlementBindingSource
            // 
            this.settlementBindingSource.DataMember = "Settlement";
            this.settlementBindingSource.DataSource = this.уП_ПМ_01_Неверов_ДСDataSet;
            // 
            // ПолеКодЗаселения
            // 
            this.ПолеКодЗаселения.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.settlementBindingSource, "SettlementID", true));
            this.ПолеКодЗаселения.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ПолеКодЗаселения.Location = new System.Drawing.Point(8, 15);
            this.ПолеКодЗаселения.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ПолеКодЗаселения.Name = "ПолеКодЗаселения";
            this.ПолеКодЗаселения.ShortcutsEnabled = false;
            this.ПолеКодЗаселения.Size = new System.Drawing.Size(132, 30);
            this.ПолеКодЗаселения.TabIndex = 51;
            this.ПолеКодЗаселения.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ПолеКодЗаселения_KeyPress);
            // 
            // ПолеКодКвартиры3
            // 
            this.ПолеКодКвартиры3.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.settlementBindingSource, "FlatID", true));
            this.ПолеКодКвартиры3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ПолеКодКвартиры3.Location = new System.Drawing.Point(8, 54);
            this.ПолеКодКвартиры3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ПолеКодКвартиры3.Name = "ПолеКодКвартиры3";
            this.ПолеКодКвартиры3.ShortcutsEnabled = false;
            this.ПолеКодКвартиры3.Size = new System.Drawing.Size(132, 30);
            this.ПолеКодКвартиры3.TabIndex = 52;
            this.ПолеКодКвартиры3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ПолеКодКвартиры3_KeyPress);
            // 
            // Договор
            // 
            this.Договор.Controls.Add(this.ПолеПлата);
            this.Договор.Controls.Add(this.ПолеДатаОкончание);
            this.Договор.Controls.Add(this.ПолеДатаНачала);
            this.Договор.Controls.Add(this.ПолеКодДоговора);
            this.Договор.Controls.Add(this.ПолеКодЗаселения2);
            this.Договор.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Договор.Location = new System.Drawing.Point(325, 446);
            this.Договор.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Договор.Name = "Договор";
            this.Договор.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Договор.Size = new System.Drawing.Size(151, 250);
            this.Договор.TabIndex = 59;
            this.Договор.TabStop = false;
            // 
            // ПолеПлата
            // 
            this.ПолеПлата.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.contractBindingSource, "Cost", true));
            this.ПолеПлата.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ПолеПлата.Location = new System.Drawing.Point(8, 174);
            this.ПолеПлата.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ПолеПлата.MaxLength = 15;
            this.ПолеПлата.Name = "ПолеПлата";
            this.ПолеПлата.ShortcutsEnabled = false;
            this.ПолеПлата.Size = new System.Drawing.Size(132, 30);
            this.ПолеПлата.TabIndex = 55;
            // 
            // contractBindingSource
            // 
            this.contractBindingSource.DataMember = "Contract";
            this.contractBindingSource.DataSource = this.уП_ПМ_01_Неверов_ДСDataSet;
            // 
            // ПолеДатаОкончание
            // 
            this.ПолеДатаОкончание.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.contractBindingSource, "StopDate", true));
            this.ПолеДатаОкончание.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.ПолеДатаОкончание.Location = new System.Drawing.Point(8, 134);
            this.ПолеДатаОкончание.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ПолеДатаОкончание.Mask = "00/00/0000";
            this.ПолеДатаОкончание.Name = "ПолеДатаОкончание";
            this.ПолеДатаОкончание.ShortcutsEnabled = false;
            this.ПолеДатаОкончание.Size = new System.Drawing.Size(132, 30);
            this.ПолеДатаОкончание.TabIndex = 54;
            this.ПолеДатаОкончание.ValidatingType = typeof(System.DateTime);
            this.ПолеДатаОкончание.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ПолеДатаОкончание_KeyPress);
            // 
            // ПолеДатаНачала
            // 
            this.ПолеДатаНачала.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.contractBindingSource, "DateStart", true));
            this.ПолеДатаНачала.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.ПолеДатаНачала.Location = new System.Drawing.Point(8, 95);
            this.ПолеДатаНачала.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ПолеДатаНачала.Mask = "00/00/0000";
            this.ПолеДатаНачала.Name = "ПолеДатаНачала";
            this.ПолеДатаНачала.ShortcutsEnabled = false;
            this.ПолеДатаНачала.Size = new System.Drawing.Size(132, 30);
            this.ПолеДатаНачала.TabIndex = 53;
            this.ПолеДатаНачала.ValidatingType = typeof(System.DateTime);
            this.ПолеДатаНачала.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ПолеДатаНачала_KeyPress);
            // 
            // ПолеКодДоговора
            // 
            this.ПолеКодДоговора.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.contractBindingSource, "TreatyID", true));
            this.ПолеКодДоговора.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ПолеКодДоговора.Location = new System.Drawing.Point(8, 16);
            this.ПолеКодДоговора.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ПолеКодДоговора.Name = "ПолеКодДоговора";
            this.ПолеКодДоговора.ShortcutsEnabled = false;
            this.ПолеКодДоговора.Size = new System.Drawing.Size(132, 30);
            this.ПолеКодДоговора.TabIndex = 51;
            this.ПолеКодДоговора.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ПолеКодДоговора_KeyPress);
            // 
            // ПолеКодЗаселения2
            // 
            this.ПолеКодЗаселения2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.contractBindingSource, "SettlementID", true));
            this.ПолеКодЗаселения2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ПолеКодЗаселения2.Location = new System.Drawing.Point(8, 55);
            this.ПолеКодЗаселения2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ПолеКодЗаселения2.Name = "ПолеКодЗаселения2";
            this.ПолеКодЗаселения2.ShortcutsEnabled = false;
            this.ПолеКодЗаселения2.Size = new System.Drawing.Size(132, 30);
            this.ПолеКодЗаселения2.TabIndex = 52;
            this.ПолеКодЗаселения2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ПолеКодЗаселения2_KeyPress);
            // 
            // ВставкаКартинки
            // 
            this.ВставкаКартинки.FileName = "openFileDialog1";
            this.ВставкаКартинки.Filter = "Image files (*.BMP, *.JPG, *.GIF,*.PNG)|*.bmp;*.jpg;*.gif;*.png";
            // 
            // ПолеКодДоговора2
            // 
            this.ПолеКодДоговора2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.prolongingBindingSource, "TreatyID", true));
            this.ПолеКодДоговора2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ПолеКодДоговора2.Location = new System.Drawing.Point(8, 54);
            this.ПолеКодДоговора2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ПолеКодДоговора2.Name = "ПолеКодДоговора2";
            this.ПолеКодДоговора2.ShortcutsEnabled = false;
            this.ПолеКодДоговора2.Size = new System.Drawing.Size(132, 30);
            this.ПолеКодДоговора2.TabIndex = 52;
            this.ПолеКодДоговора2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ПолеКодДоговора2_KeyPress);
            // 
            // prolongingBindingSource
            // 
            this.prolongingBindingSource.DataMember = "Prolonging";
            this.prolongingBindingSource.DataSource = this.уП_ПМ_01_Неверов_ДСDataSet;
            // 
            // ПолеКодПродление
            // 
            this.ПолеКодПродление.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.prolongingBindingSource, "ProlongingID", true));
            this.ПолеКодПродление.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ПолеКодПродление.Location = new System.Drawing.Point(8, 15);
            this.ПолеКодПродление.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ПолеКодПродление.Name = "ПолеКодПродление";
            this.ПолеКодПродление.ShortcutsEnabled = false;
            this.ПолеКодПродление.Size = new System.Drawing.Size(132, 30);
            this.ПолеКодПродление.TabIndex = 51;
            this.ПолеКодПродление.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ПолеКодПродление_KeyPress);
            // 
            // ПолеКоммент
            // 
            this.ПолеКоммент.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.prolongingBindingSource, "Comment", true));
            this.ПолеКоммент.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ПолеКоммент.Location = new System.Drawing.Point(8, 133);
            this.ПолеКоммент.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ПолеКоммент.Multiline = true;
            this.ПолеКоммент.Name = "ПолеКоммент";
            this.ПолеКоммент.ShortcutsEnabled = false;
            this.ПолеКоммент.Size = new System.Drawing.Size(132, 109);
            this.ПолеКоммент.TabIndex = 54;
            // 
            // ПолеДатаПродление
            // 
            this.ПолеДатаПродление.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ПолеДатаПродление.BackColor = System.Drawing.SystemColors.Window;
            this.ПолеДатаПродление.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.prolongingBindingSource, "Prolong", true));
            this.ПолеДатаПродление.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.ПолеДатаПродление.Location = new System.Drawing.Point(8, 94);
            this.ПолеДатаПродление.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ПолеДатаПродление.Mask = "00/00/0000";
            this.ПолеДатаПродление.Name = "ПолеДатаПродление";
            this.ПолеДатаПродление.ShortcutsEnabled = false;
            this.ПолеДатаПродление.Size = new System.Drawing.Size(132, 30);
            this.ПолеДатаПродление.TabIndex = 57;
            this.ПолеДатаПродление.ValidatingType = typeof(System.DateTime);
            this.ПолеДатаПродление.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ПолеДатаПродление_KeyPress);
            // 
            // Продление
            // 
            this.Продление.Controls.Add(this.ПолеДатаПродление);
            this.Продление.Controls.Add(this.ПолеКоммент);
            this.Продление.Controls.Add(this.ПолеКодПродление);
            this.Продление.Controls.Add(this.ПолеКодДоговора2);
            this.Продление.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Продление.Location = new System.Drawing.Point(484, 446);
            this.Продление.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Продление.Name = "Продление";
            this.Продление.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Продление.Size = new System.Drawing.Size(151, 250);
            this.Продление.TabIndex = 62;
            this.Продление.TabStop = false;
            // 
            // ГруппаЗаквата
            // 
            this.ГруппаЗаквата.Controls.Add(this.ПолеКодГруппыЗахвата);
            this.ГруппаЗаквата.Controls.Add(this.ПолеНомерЭкипажа);
            this.ГруппаЗаквата.Controls.Add(this.ПолеДокумент);
            this.ГруппаЗаквата.Controls.Add(this.ПолеКомандирЭкипажа);
            this.ГруппаЗаквата.Controls.Add(this.ПолеАвтомобиль);
            this.ГруппаЗаквата.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ГруппаЗаквата.Location = new System.Drawing.Point(643, 446);
            this.ГруппаЗаквата.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ГруппаЗаквата.Name = "ГруппаЗаквата";
            this.ГруппаЗаквата.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ГруппаЗаквата.Size = new System.Drawing.Size(151, 250);
            this.ГруппаЗаквата.TabIndex = 58;
            this.ГруппаЗаквата.TabStop = false;
            // 
            // ПолеКодГруппыЗахвата
            // 
            this.ПолеКодГруппыЗахвата.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.captureBindingSource, "ActionID", true));
            this.ПолеКодГруппыЗахвата.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ПолеКодГруппыЗахвата.Location = new System.Drawing.Point(8, 15);
            this.ПолеКодГруппыЗахвата.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ПолеКодГруппыЗахвата.Name = "ПолеКодГруппыЗахвата";
            this.ПолеКодГруппыЗахвата.ShortcutsEnabled = false;
            this.ПолеКодГруппыЗахвата.Size = new System.Drawing.Size(132, 30);
            this.ПолеКодГруппыЗахвата.TabIndex = 51;
            this.ПолеКодГруппыЗахвата.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ПолеКодГруппыЗахвата_KeyPress);
            // 
            // captureBindingSource
            // 
            this.captureBindingSource.DataMember = "Capture";
            this.captureBindingSource.DataSource = this.уП_ПМ_01_Неверов_ДСDataSet;
            // 
            // ПолеНомерЭкипажа
            // 
            this.ПолеНомерЭкипажа.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.captureBindingSource, "PatrolID", true));
            this.ПолеНомерЭкипажа.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ПолеНомерЭкипажа.Location = new System.Drawing.Point(8, 54);
            this.ПолеНомерЭкипажа.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ПолеНомерЭкипажа.MaxLength = 4;
            this.ПолеНомерЭкипажа.Name = "ПолеНомерЭкипажа";
            this.ПолеНомерЭкипажа.ShortcutsEnabled = false;
            this.ПолеНомерЭкипажа.Size = new System.Drawing.Size(132, 30);
            this.ПолеНомерЭкипажа.TabIndex = 52;
            this.ПолеНомерЭкипажа.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ПолеНомерЭкипажа_KeyPress);
            // 
            // ПолеДокумент
            // 
            this.ПолеДокумент.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.captureBindingSource, "Document", true));
            this.ПолеДокумент.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ПолеДокумент.Location = new System.Drawing.Point(8, 172);
            this.ПолеДокумент.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ПолеДокумент.MaxLength = 40;
            this.ПолеДокумент.Name = "ПолеДокумент";
            this.ПолеДокумент.ShortcutsEnabled = false;
            this.ПолеДокумент.Size = new System.Drawing.Size(132, 30);
            this.ПолеДокумент.TabIndex = 55;
            // 
            // ПолеКомандирЭкипажа
            // 
            this.ПолеКомандирЭкипажа.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.captureBindingSource, "Chief", true));
            this.ПолеКомандирЭкипажа.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ПолеКомандирЭкипажа.Location = new System.Drawing.Point(8, 94);
            this.ПолеКомандирЭкипажа.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ПолеКомандирЭкипажа.MaxLength = 20;
            this.ПолеКомандирЭкипажа.Name = "ПолеКомандирЭкипажа";
            this.ПолеКомандирЭкипажа.ShortcutsEnabled = false;
            this.ПолеКомандирЭкипажа.Size = new System.Drawing.Size(132, 30);
            this.ПолеКомандирЭкипажа.TabIndex = 53;
            this.ПолеКомандирЭкипажа.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ПолеКомандирЭкипажа_KeyPress);
            // 
            // ПолеАвтомобиль
            // 
            this.ПолеАвтомобиль.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.captureBindingSource, "Brand", true));
            this.ПолеАвтомобиль.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ПолеАвтомобиль.Location = new System.Drawing.Point(8, 133);
            this.ПолеАвтомобиль.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ПолеАвтомобиль.MaxLength = 15;
            this.ПолеАвтомобиль.Name = "ПолеАвтомобиль";
            this.ПолеАвтомобиль.ShortcutsEnabled = false;
            this.ПолеАвтомобиль.Size = new System.Drawing.Size(132, 30);
            this.ПолеАвтомобиль.TabIndex = 54;
            this.ПолеАвтомобиль.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ПолеАвтомобиль_KeyPress);
            // 
            // ПолеКодГруппыЗахвата2
            // 
            this.ПолеКодГруппыЗахвата2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.callingBindingSource, "ActionID", true));
            this.ПолеКодГруппыЗахвата2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ПолеКодГруппыЗахвата2.Location = new System.Drawing.Point(8, 94);
            this.ПолеКодГруппыЗахвата2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ПолеКодГруппыЗахвата2.Name = "ПолеКодГруппыЗахвата2";
            this.ПолеКодГруппыЗахвата2.ShortcutsEnabled = false;
            this.ПолеКодГруппыЗахвата2.Size = new System.Drawing.Size(132, 30);
            this.ПолеКодГруппыЗахвата2.TabIndex = 53;
            this.ПолеКодГруппыЗахвата2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ПолеКодГруппыВызова_KeyPress);
            // 
            // callingBindingSource
            // 
            this.callingBindingSource.DataMember = "Calling";
            this.callingBindingSource.DataSource = this.уП_ПМ_01_Неверов_ДСDataSet;
            // 
            // ПолеКодДоговора3
            // 
            this.ПолеКодДоговора3.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.callingBindingSource, "TreatyID", true));
            this.ПолеКодДоговора3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ПолеКодДоговора3.Location = new System.Drawing.Point(8, 54);
            this.ПолеКодДоговора3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ПолеКодДоговора3.Name = "ПолеКодДоговора3";
            this.ПолеКодДоговора3.ShortcutsEnabled = false;
            this.ПолеКодДоговора3.Size = new System.Drawing.Size(132, 30);
            this.ПолеКодДоговора3.TabIndex = 52;
            this.ПолеКодДоговора3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ПолеКодДоговора3_KeyPress);
            // 
            // ПолеКодВызова
            // 
            this.ПолеКодВызова.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.callingBindingSource, "CallingID", true));
            this.ПолеКодВызова.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ПолеКодВызова.Location = new System.Drawing.Point(8, 15);
            this.ПолеКодВызова.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ПолеКодВызова.Name = "ПолеКодВызова";
            this.ПолеКодВызова.ShortcutsEnabled = false;
            this.ПолеКодВызова.Size = new System.Drawing.Size(132, 30);
            this.ПолеКодВызова.TabIndex = 51;
            this.ПолеКодВызова.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ПолеКодВызова_KeyPress);
            // 
            // ЛожныйВызов
            // 
            this.ЛожныйВызов.AutoSize = true;
            this.ЛожныйВызов.DataBindings.Add(new System.Windows.Forms.Binding("CheckAlign", this.callingBindingSource, "False", true));
            this.ЛожныйВызов.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.callingBindingSource, "False", true));
            this.ЛожныйВызов.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.callingBindingSource, "False", true));
            this.ЛожныйВызов.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ЛожныйВызов.Location = new System.Drawing.Point(24, 171);
            this.ЛожныйВызов.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ЛожныйВызов.Name = "ЛожныйВызов";
            this.ЛожныйВызов.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.ЛожныйВызов.Size = new System.Drawing.Size(102, 28);
            this.ЛожныйВызов.TabIndex = 57;
            this.ЛожныйВызов.Text = "?Ложный";
            this.ЛожныйВызов.UseVisualStyleBackColor = true;
            this.ЛожныйВызов.CheckedChanged += new System.EventHandler(this.ЛожныйВызов_CheckedChanged);
            // 
            // Вызов
            // 
            this.Вызов.Controls.Add(this.ПолеКомпенсация);
            this.Вызов.Controls.Add(this.ПолеШтраф);
            this.Вызов.Controls.Add(this.ПолеДатаВызова);
            this.Вызов.Controls.Add(this.ЛожныйВызов);
            this.Вызов.Controls.Add(this.ПолеКодВызова);
            this.Вызов.Controls.Add(this.ПолеКодДоговора3);
            this.Вызов.Controls.Add(this.ПолеКодГруппыЗахвата2);
            this.Вызов.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Вызов.Location = new System.Drawing.Point(801, 447);
            this.Вызов.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Вызов.Name = "Вызов";
            this.Вызов.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Вызов.Size = new System.Drawing.Size(151, 288);
            this.Вызов.TabIndex = 59;
            this.Вызов.TabStop = false;
            // 
            // ПолеКомпенсация
            // 
            this.ПолеКомпенсация.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.callingBindingSource, "Compensation", true));
            this.ПолеКомпенсация.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ПолеКомпенсация.Location = new System.Drawing.Point(8, 251);
            this.ПолеКомпенсация.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ПолеКомпенсация.MaxLength = 15;
            this.ПолеКомпенсация.Name = "ПолеКомпенсация";
            this.ПолеКомпенсация.ShortcutsEnabled = false;
            this.ПолеКомпенсация.Size = new System.Drawing.Size(132, 30);
            this.ПолеКомпенсация.TabIndex = 60;
            // 
            // ПолеШтраф
            // 
            this.ПолеШтраф.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.callingBindingSource, "Tax", true));
            this.ПолеШтраф.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ПолеШтраф.Location = new System.Drawing.Point(8, 210);
            this.ПолеШтраф.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ПолеШтраф.MaxLength = 15;
            this.ПолеШтраф.Name = "ПолеШтраф";
            this.ПолеШтраф.ShortcutsEnabled = false;
            this.ПолеШтраф.Size = new System.Drawing.Size(132, 30);
            this.ПолеШтраф.TabIndex = 59;
            this.ПолеШтраф.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ПолеШтраф_KeyPress);
            // 
            // ПолеДатаВызова
            // 
            this.ПолеДатаВызова.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ПолеДатаВызова.BackColor = System.Drawing.SystemColors.Window;
            this.ПолеДатаВызова.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.callingBindingSource, "DateTime", true));
            this.ПолеДатаВызова.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.ПолеДатаВызова.Location = new System.Drawing.Point(8, 133);
            this.ПолеДатаВызова.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ПолеДатаВызова.Mask = "00/00/0000";
            this.ПолеДатаВызова.Name = "ПолеДатаВызова";
            this.ПолеДатаВызова.ShortcutsEnabled = false;
            this.ПолеДатаВызова.Size = new System.Drawing.Size(132, 30);
            this.ПолеДатаВызова.TabIndex = 58;
            this.ПолеДатаВызова.ValidatingType = typeof(System.DateTime);
            // 
            // Доступ
            // 
            this.Доступ.AutoSize = true;
            this.Доступ.Location = new System.Drawing.Point(39, 318);
            this.Доступ.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Доступ.Name = "Доступ";
            this.Доступ.Size = new System.Drawing.Size(0, 16);
            this.Доступ.TabIndex = 63;
            this.Доступ.Visible = false;
            // 
            // Пользователь
            // 
            this.Пользователь.Controls.Add(this.НадписьПраваДоступа);
            this.Пользователь.Controls.Add(this.ПолеПраваДоступа);
            this.Пользователь.Controls.Add(this.ПолеЛогин);
            this.Пользователь.Controls.Add(this.ПолеПароль);
            this.Пользователь.Controls.Add(this.ПолеКодКлиента3);
            this.Пользователь.Location = new System.Drawing.Point(973, 447);
            this.Пользователь.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Пользователь.Name = "Пользователь";
            this.Пользователь.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Пользователь.Size = new System.Drawing.Size(151, 250);
            this.Пользователь.TabIndex = 59;
            this.Пользователь.TabStop = false;
            // 
            // НадписьПраваДоступа
            // 
            this.НадписьПраваДоступа.AutoSize = true;
            this.НадписьПраваДоступа.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.userBindingSource, "Права доступа", true));
            this.НадписьПраваДоступа.Location = new System.Drawing.Point(8, 176);
            this.НадписьПраваДоступа.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.НадписьПраваДоступа.Name = "НадписьПраваДоступа";
            this.НадписьПраваДоступа.Size = new System.Drawing.Size(0, 16);
            this.НадписьПраваДоступа.TabIndex = 59;
            this.НадписьПраваДоступа.Visible = false;
            // 
            // userBindingSource
            // 
            this.userBindingSource.DataMember = "User";
            this.userBindingSource.DataSource = this.уП_ПМ_01_Неверов_ДСDataSet;
            // 
            // ПолеПраваДоступа
            // 
            this.ПолеПраваДоступа.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.ПолеПраваДоступа.FormattingEnabled = true;
            this.ПолеПраваДоступа.Items.AddRange(new object[] {
            "Администратор",
            "Оператор",
            "Командир",
            "КП"});
            this.ПолеПраваДоступа.Location = new System.Drawing.Point(8, 95);
            this.ПолеПраваДоступа.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ПолеПраваДоступа.Name = "ПолеПраваДоступа";
            this.ПолеПраваДоступа.Size = new System.Drawing.Size(132, 33);
            this.ПолеПраваДоступа.TabIndex = 58;
            this.ПолеПраваДоступа.SelectedIndexChanged += new System.EventHandler(this.ПолеПраваДоступа_SelectedIndexChanged);
            this.ПолеПраваДоступа.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ПолеПраваДоступа_KeyPress);
            // 
            // ПолеЛогин
            // 
            this.ПолеЛогин.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.userBindingSource, "Логин", true));
            this.ПолеЛогин.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ПолеЛогин.Location = new System.Drawing.Point(8, 16);
            this.ПолеЛогин.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ПолеЛогин.MaxLength = 40;
            this.ПолеЛогин.Name = "ПолеЛогин";
            this.ПолеЛогин.ShortcutsEnabled = false;
            this.ПолеЛогин.Size = new System.Drawing.Size(132, 30);
            this.ПолеЛогин.TabIndex = 51;
            this.ПолеЛогин.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ПолеЛогин_KeyPress);
            // 
            // ПолеПароль
            // 
            this.ПолеПароль.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.userBindingSource, "Пароль", true));
            this.ПолеПароль.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ПолеПароль.Location = new System.Drawing.Point(8, 55);
            this.ПолеПароль.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ПолеПароль.MaxLength = 40;
            this.ПолеПароль.Name = "ПолеПароль";
            this.ПолеПароль.ShortcutsEnabled = false;
            this.ПолеПароль.Size = new System.Drawing.Size(132, 30);
            this.ПолеПароль.TabIndex = 52;
            this.ПолеПароль.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ПолеПароль_KeyPress);
            // 
            // ПолеКодКлиента3
            // 
            this.ПолеКодКлиента3.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.userBindingSource, "Registr", true));
            this.ПолеКодКлиента3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ПолеКодКлиента3.Location = new System.Drawing.Point(8, 137);
            this.ПолеКодКлиента3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ПолеКодКлиента3.Name = "ПолеКодКлиента3";
            this.ПолеКодКлиента3.ShortcutsEnabled = false;
            this.ПолеКодКлиента3.Size = new System.Drawing.Size(132, 30);
            this.ПолеКодКлиента3.TabIndex = 53;
            this.ПолеКодКлиента3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ПолеКодКлиента3_KeyPress);
            // 
            // userTableAdapter1
            // 
            this.userTableAdapter1.ClearBeforeFill = true;
            // 
            // ОбновлениеЗаписей
            // 
            this.ОбновлениеЗаписей.Image = ((System.Drawing.Image)(resources.GetObject("ОбновлениеЗаписей.Image")));
            this.ОбновлениеЗаписей.Location = new System.Drawing.Point(429, 366);
            this.ОбновлениеЗаписей.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ОбновлениеЗаписей.Name = "ОбновлениеЗаписей";
            this.ОбновлениеЗаписей.Size = new System.Drawing.Size(47, 43);
            this.ОбновлениеЗаписей.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ОбновлениеЗаписей.TabIndex = 64;
            this.ОбновлениеЗаписей.TabStop = false;
            this.ОбновлениеЗаписей.Click += new System.EventHandler(this.ОбновлениеЗаписей_Click);
            // 
            // Plan
            // 
            this.Plan.AutoSize = true;
            this.Plan.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.flatBindingSource, "FlatPlan", true));
            this.Plan.Location = new System.Drawing.Point(845, 11);
            this.Plan.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Plan.Name = "Plan";
            this.Plan.Size = new System.Drawing.Size(0, 16);
            this.Plan.TabIndex = 65;
            // 
            // ПоследняяЗапись
            // 
            this.ПоследняяЗапись.Image = ((System.Drawing.Image)(resources.GetObject("ПоследняяЗапись.Image")));
            this.ПоследняяЗапись.Location = new System.Drawing.Point(340, 366);
            this.ПоследняяЗапись.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ПоследняяЗапись.Name = "ПоследняяЗапись";
            this.ПоследняяЗапись.Size = new System.Drawing.Size(47, 43);
            this.ПоследняяЗапись.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ПоследняяЗапись.TabIndex = 66;
            this.ПоследняяЗапись.TabStop = false;
            this.ПоследняяЗапись.Click += new System.EventHandler(this.ПоследняяЗапись_Click);
            // 
            // ПерваяЗапись
            // 
            this.ПерваяЗапись.Image = ((System.Drawing.Image)(resources.GetObject("ПерваяЗапись.Image")));
            this.ПерваяЗапись.Location = new System.Drawing.Point(176, 366);
            this.ПерваяЗапись.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ПерваяЗапись.Name = "ПерваяЗапись";
            this.ПерваяЗапись.Size = new System.Drawing.Size(47, 43);
            this.ПерваяЗапись.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ПерваяЗапись.TabIndex = 67;
            this.ПерваяЗапись.TabStop = false;
            this.ПерваяЗапись.Click += new System.EventHandler(this.ПерваяЗапись_Click);
            // 
            // captureTableAdapter
            // 
            this.captureTableAdapter.ClearBeforeFill = true;
            // 
            // clientTableAdapter
            // 
            this.clientTableAdapter.ClearBeforeFill = true;
            // 
            // contractTableAdapter
            // 
            this.contractTableAdapter.ClearBeforeFill = true;
            // 
            // callingTableAdapter
            // 
            this.callingTableAdapter.ClearBeforeFill = true;
            // 
            // flat_HouseTableAdapter
            // 
            this.flat_HouseTableAdapter.ClearBeforeFill = true;
            // 
            // houseTableAdapter
            // 
            this.houseTableAdapter.ClearBeforeFill = true;
            // 
            // prolongingTableAdapter
            // 
            this.prolongingTableAdapter.ClearBeforeFill = true;
            // 
            // userTableAdapter
            // 
            this.userTableAdapter.ClearBeforeFill = true;
            // 
            // settlementTableAdapter
            // 
            this.settlementTableAdapter.ClearBeforeFill = true;
            // 
            // flatTableAdapter
            // 
            this.flatTableAdapter.ClearBeforeFill = true;
            // 
            // Надпись7
            // 
            this.Надпись7.AutoSize = true;
            this.Надпись7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Надпись7.Location = new System.Drawing.Point(587, 283);
            this.Надпись7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Надпись7.Name = "Надпись7";
            this.Надпись7.Size = new System.Drawing.Size(17, 25);
            this.Надпись7.TabIndex = 68;
            this.Надпись7.Text = " ";
            // 
            // Администратор
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(111)))), ((int)(((byte)(210)))), ((int)(((byte)(221)))));
            this.ClientSize = new System.Drawing.Size(1331, 719);
            this.Controls.Add(this.Надпись7);
            this.Controls.Add(this.ПерваяЗапись);
            this.Controls.Add(this.ПоследняяЗапись);
            this.Controls.Add(this.ОбновлениеЗаписей);
            this.Controls.Add(this.Пользователь);
            this.Controls.Add(this.Доступ);
            this.Controls.Add(this.ПолеПланКвартиры);
            this.Controls.Add(this.ГруппаЗаквата);
            this.Controls.Add(this.Продление);
            this.Controls.Add(this.Дом);
            this.Controls.Add(this.Заселение);
            this.Controls.Add(this.КвартираДом);
            this.Controls.Add(this.Квартира);
            this.Controls.Add(this.Клиент);
            this.Controls.Add(this.PlanFlat);
            this.Controls.Add(this.Поиск);
            this.Controls.Add(this.ПолеПоиск);
            this.Controls.Add(this.Надпись6);
            this.Controls.Add(this.Надпись5);
            this.Controls.Add(this.Надпись4);
            this.Controls.Add(this.Надпись3);
            this.Controls.Add(this.Надпись2);
            this.Controls.Add(this.Надпись1);
            this.Controls.Add(this.ПредыдущаяЗапись);
            this.Controls.Add(this.СледующаяЗапись);
            this.Controls.Add(this.УдалитьЗапись);
            this.Controls.Add(this.ДобавитьЗапись);
            this.Controls.Add(this.Выход);
            this.Controls.Add(this.ТаблицаАдминистратор);
            this.Controls.Add(this.Меню);
            this.Controls.Add(this.Plan);
            this.Controls.Add(this.Договор);
            this.Controls.Add(this.Вызов);
            this.Cursor = System.Windows.Forms.Cursors.Default;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Администратор";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Форма Администратора";
            this.Load += new System.EventHandler(this.Администратор_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Администратор_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Администратор_MouseMove);
            this.Меню.ResumeLayout(false);
            this.Меню.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ТаблицаАдминистратор)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.уП_ПМ_01_Неверов_ДСDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Выход)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ДобавитьЗапись)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.УдалитьЗапись)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.СледующаяЗапись)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ПредыдущаяЗапись)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ПолеПланКвартиры)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.clientBindingSource)).EndInit();
            this.Клиент.ResumeLayout(false);
            this.Клиент.PerformLayout();
            this.Квартира.ResumeLayout(false);
            this.Квартира.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.flatBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.houseBindingSource)).EndInit();
            this.Дом.ResumeLayout(false);
            this.Дом.PerformLayout();
            this.КвартираДом.ResumeLayout(false);
            this.КвартираДом.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.flatHouseBindingSource)).EndInit();
            this.Заселение.ResumeLayout(false);
            this.Заселение.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.settlementBindingSource)).EndInit();
            this.Договор.ResumeLayout(false);
            this.Договор.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.contractBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.prolongingBindingSource)).EndInit();
            this.Продление.ResumeLayout(false);
            this.Продление.PerformLayout();
            this.ГруппаЗаквата.ResumeLayout(false);
            this.ГруппаЗаквата.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.captureBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.callingBindingSource)).EndInit();
            this.Вызов.ResumeLayout(false);
            this.Вызов.PerformLayout();
            this.Пользователь.ResumeLayout(false);
            this.Пользователь.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.userBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.userBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ОбновлениеЗаписей)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ПоследняяЗапись)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ПерваяЗапись)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip Меню;
        private System.Windows.Forms.ToolStripDropDownButton Таблицы;
        private System.Windows.Forms.DataGridView ТаблицаАдминистратор;
        private System.Windows.Forms.ToolStripMenuItem client;
        private System.Windows.Forms.ToolStripMenuItem flat;
        private System.Windows.Forms.ToolStripMenuItem house;
        private System.Windows.Forms.ToolStripMenuItem flatHouse;
        private System.Windows.Forms.ToolStripMenuItem settlement;
        private System.Windows.Forms.ToolStripMenuItem contract;
        private System.Windows.Forms.ToolStripMenuItem prolonging;
        private System.Windows.Forms.ToolStripMenuItem capture;
        private System.Windows.Forms.ToolStripMenuItem user;
        private System.Windows.Forms.ToolStripDropDownButton Формы;
        private System.Windows.Forms.ToolStripMenuItem формаГостя;
        private System.Windows.Forms.ToolStripMenuItem формаКомандира;
        private System.Windows.Forms.PictureBox Выход;
        private System.Windows.Forms.ToolStripDropDownButton Файл;
        private System.Windows.Forms.ToolStripMenuItem обновить;
        private System.Windows.Forms.ToolStripMenuItem вернутьсяКАвторизации;
        private System.Windows.Forms.ToolStripMenuItem выйтиИзПриложения;
        private System.Windows.Forms.PictureBox ДобавитьЗапись;
        private System.Windows.Forms.PictureBox УдалитьЗапись;
        private System.Windows.Forms.PictureBox СледующаяЗапись;
        private System.Windows.Forms.PictureBox ПредыдущаяЗапись;
        private System.Windows.Forms.ToolStripMenuItem calling;
        private System.Windows.Forms.Label Надпись1;
        private System.Windows.Forms.Label Надпись2;
        private System.Windows.Forms.Label Надпись3;
        private System.Windows.Forms.Label Надпись4;
        private System.Windows.Forms.Label Надпись5;
        private System.Windows.Forms.Label Надпись6;
        private System.Windows.Forms.Label Поиск;
        private System.Windows.Forms.TextBox ПолеПоиск;
        private System.Windows.Forms.PictureBox ПолеПланКвартиры;
        private System.Windows.Forms.Label PlanFlat;
        private System.Windows.Forms.TextBox ПолеКодКлиента;
        private System.Windows.Forms.TextBox ПолеФамилия;
        private System.Windows.Forms.TextBox ПолеИмя;
        private System.Windows.Forms.TextBox ПолеОтчество;
        private System.Windows.Forms.TextBox ПолеАдрес;
        private System.Windows.Forms.MaskedTextBox ПолеТелефон;
        private System.Windows.Forms.GroupBox Клиент;
        private System.Windows.Forms.GroupBox Квартира;
        private System.Windows.Forms.TextBox ПолеКодКвартиры;
        private System.Windows.Forms.TextBox ПолеАдресКвартиры;
        private System.Windows.Forms.TextBox ПолеЭтажКвартиры;
        private System.Windows.Forms.ComboBox ПолеТипБалкона;
        private System.Windows.Forms.CheckBox ЕстьБалкон;
        private System.Windows.Forms.ComboBox ПолеТипДвери;
        private System.Windows.Forms.GroupBox Дом;
        private System.Windows.Forms.ComboBox ПолеТипДома;
        private System.Windows.Forms.CheckBox ЕстьЗамок;
        private System.Windows.Forms.TextBox ПолеКодДома;
        private System.Windows.Forms.TextBox ПолеЭтажейВДоме;
        private System.Windows.Forms.GroupBox КвартираДом;
        private System.Windows.Forms.TextBox ПолеКодКвартираДом;
        private System.Windows.Forms.TextBox ПолеКодКвартиры2;
        private System.Windows.Forms.TextBox ПолеКодДома2;
        private System.Windows.Forms.GroupBox Заселение;
        private System.Windows.Forms.TextBox ПолеКодКлиента2;
        private System.Windows.Forms.TextBox ПолеКодЗаселения;
        private System.Windows.Forms.TextBox ПолеКодКвартиры3;
        private System.Windows.Forms.GroupBox Договор;
        private System.Windows.Forms.TextBox ПолеКодДоговора;
        private System.Windows.Forms.TextBox ПолеКодЗаселения2;
        private System.Windows.Forms.TextBox ПолеПлата;
        private System.Windows.Forms.MaskedTextBox ПолеДатаОкончание;
        private System.Windows.Forms.MaskedTextBox ПолеДатаНачала;
        private System.Windows.Forms.OpenFileDialog ВставкаКартинки;
        private System.Windows.Forms.TextBox ПолеКодДоговора2;
        private System.Windows.Forms.TextBox ПолеКодПродление;
        private System.Windows.Forms.TextBox ПолеКоммент;
        private System.Windows.Forms.MaskedTextBox ПолеДатаПродление;
        private System.Windows.Forms.GroupBox Продление;
        private УП_ПМ_01_Неверов_ДСDataSet уП_ПМ_01_Неверов_ДСDataSet;
        private System.Windows.Forms.GroupBox ГруппаЗаквата;
        private System.Windows.Forms.TextBox ПолеКодГруппыЗахвата;
        private System.Windows.Forms.TextBox ПолеНомерЭкипажа;
        private System.Windows.Forms.TextBox ПолеДокумент;
        private System.Windows.Forms.TextBox ПолеКомандирЭкипажа;
        private System.Windows.Forms.TextBox ПолеАвтомобиль;
        private System.Windows.Forms.TextBox ПолеКодГруппыЗахвата2;
        private System.Windows.Forms.TextBox ПолеКодДоговора3;
        private System.Windows.Forms.TextBox ПолеКодВызова;
        private System.Windows.Forms.CheckBox ЛожныйВызов;
        private System.Windows.Forms.GroupBox Вызов;
        private System.Windows.Forms.TextBox ПолеКомпенсация;
        private System.Windows.Forms.TextBox ПолеШтраф;
        private System.Windows.Forms.MaskedTextBox ПолеДатаВызова;
        public System.Windows.Forms.Label Доступ;
        private System.Windows.Forms.GroupBox Пользователь;
        private System.Windows.Forms.ComboBox ПолеПраваДоступа;
        private System.Windows.Forms.TextBox ПолеЛогин;
        private System.Windows.Forms.TextBox ПолеПароль;
        private System.Windows.Forms.TextBox ПолеКодКлиента3;
        private System.Windows.Forms.BindingSource userBindingSource1;
        private УП_НеверовDataSetTableAdapters.UserTableAdapter userTableAdapter1;
        private System.Windows.Forms.PictureBox ОбновлениеЗаписей;
        private System.Windows.Forms.Label Plan;
        private System.Windows.Forms.PictureBox ПоследняяЗапись;
        private System.Windows.Forms.PictureBox ПерваяЗапись;
        private System.Windows.Forms.BindingSource captureBindingSource;
        private УП_ПМ_01_Неверов_ДСDataSetTableAdapters.CaptureTableAdapter captureTableAdapter;
        private System.Windows.Forms.BindingSource clientBindingSource;
        private УП_ПМ_01_Неверов_ДСDataSetTableAdapters.ClientTableAdapter clientTableAdapter;
        private System.Windows.Forms.BindingSource contractBindingSource;
        private УП_ПМ_01_Неверов_ДСDataSetTableAdapters.ContractTableAdapter contractTableAdapter;
        private System.Windows.Forms.BindingSource callingBindingSource;
        private УП_ПМ_01_Неверов_ДСDataSetTableAdapters.CallingTableAdapter callingTableAdapter;
        private System.Windows.Forms.BindingSource flatHouseBindingSource;
        private УП_ПМ_01_Неверов_ДСDataSetTableAdapters.Flat_HouseTableAdapter flat_HouseTableAdapter;
        private System.Windows.Forms.BindingSource houseBindingSource;
        private УП_ПМ_01_Неверов_ДСDataSetTableAdapters.HouseTableAdapter houseTableAdapter;
        private System.Windows.Forms.BindingSource prolongingBindingSource;
        private УП_ПМ_01_Неверов_ДСDataSetTableAdapters.ProlongingTableAdapter prolongingTableAdapter;
        private System.Windows.Forms.BindingSource userBindingSource;
        private УП_ПМ_01_Неверов_ДСDataSetTableAdapters.UserTableAdapter userTableAdapter;
        private System.Windows.Forms.BindingSource settlementBindingSource;
        private УП_ПМ_01_Неверов_ДСDataSetTableAdapters.SettlementTableAdapter settlementTableAdapter;
        private System.Windows.Forms.DataGridViewImageColumn planDataGridViewImageColumn;
        private System.Windows.Forms.BindingSource flatBindingSource;
        private УП_ПМ_01_Неверов_ДСDataSetTableAdapters.FlatTableAdapter flatTableAdapter;
        private System.Windows.Forms.ToolStripMenuItem формаКП;
        private System.Windows.Forms.Label Надпись7;
        private System.Windows.Forms.Label НадписьПраваДоступа;
        private System.Windows.Forms.Label НадписьТипДома;
        private System.Windows.Forms.Label НадписьТипБалкона;
        private System.Windows.Forms.Label НадписьТипДвери;
    }
}