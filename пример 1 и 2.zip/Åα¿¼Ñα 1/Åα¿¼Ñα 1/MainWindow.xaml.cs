﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Пример_1
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Brush color;
        int colorFlag = 1;
        public MainWindow()
        {
            InitializeComponent();
            color = Window.Background;
        }

        public void Btn1_Click(object sender, RoutedEventArgs e)
        {
            if (colorFlag==1)
            {
                Window.Background = Brushes.Purple;
                colorFlag = 0;
            }
            else
            {
                Window.Background = color;
                colorFlag = 1;
            }

        }

        private void Btn2_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
